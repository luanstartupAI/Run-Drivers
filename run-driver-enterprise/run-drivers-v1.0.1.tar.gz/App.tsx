import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StripeProvider } from '@stripe/stripe-react-native';
import { AppNavigator } from './src/navigation/AppNavigator';
import { notificationService } from './src/services/notificationService';
import { stripeService } from './src/services/stripeService';
import { biometricService } from './src/services/biometricService';
import { colors } from './src/constants/tokens';
import { getEnvironmentConfig } from './src/constants/keys';

const App = () => {
  useEffect(() => {
    setupMobileServices();
  }, []);

  const setupMobileServices = async () => {
    try {
      console.log('🚀 Inicializando serviços mobile...');
      
      // 1. Configurar notificações
      await setupNotifications();
      
      // 2. Inicializar Stripe
      await setupStripe();
      
      // 3. Inicializar biometria
      await setupBiometrics();
      
      // 4. Solicitar permissões
      await requestPermissions();
      
      console.log('✅ Todos os serviços mobile inicializados com sucesso!');
    } catch (error) {
      console.error('❌ Erro ao inicializar serviços mobile:', error);
    }
  };

  const setupNotifications = async () => {
    try {
      await notificationService.configure();
      console.log('✅ Notificações configuradas');
    } catch (error) {
      console.error('❌ Erro ao configurar notificações:', error);
    }
  };

  const setupStripe = async () => {
    try {
      await stripeService.initialize();
      console.log('✅ Stripe inicializado');
    } catch (error) {
      console.error('❌ Erro ao inicializar Stripe:', error);
    }
  };

  const setupBiometrics = async () => {
    try {
      const result = await biometricService.initialize();
      if (result.success) {
        console.log('✅ Biometria inicializada:', result.biometricType);
      } else {
        console.log('⚠️ Biometria não disponível:', result.error);
      }
    } catch (error) {
      console.error('❌ Erro ao inicializar biometria:', error);
    }
  };

  const requestPermissions = async () => {
    try {
      // Solicitar permissões de notificação
      await notificationService.requestPermission();
      
      console.log('✅ Permissões solicitadas');
    } catch (error) {
      console.error('❌ Erro ao solicitar permissões:', error);
    }
  };

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="dark-content" backgroundColor={colors.neutral[50]} />
      <StripeProvider
        publishableKey={getEnvironmentConfig().stripeKey} // Chave via ambiente
        merchantIdentifier={getEnvironmentConfig().stripeMerchantId || "merchant.com.run.driver"} // Para Apple Pay
      >
        <AppNavigator />
      </StripeProvider>
    </SafeAreaProvider>
  );
};

export default App;
