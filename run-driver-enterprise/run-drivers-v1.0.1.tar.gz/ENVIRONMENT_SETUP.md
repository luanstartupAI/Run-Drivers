# 🔑 Configuração de Ambiente - Run Driver Enterprise

## 📋 **Guia Completo de Configuração**

### **🚀 Passo 1: Configurar Variáveis de Ambiente**

#### **1.1 React Native (Mobile App)**
```bash
# Copiar arquivo de exemplo
cp .env.example .env

# Editar com suas chaves reais
nano .env
```

#### **1.2 Backend (Flask)**
```bash
# Navegar para o diretório do backend
cd backend

# Copiar arquivo de exemplo
cp .env.example .env

# Editar com suas chaves reais
nano .env
```

#### **1.3 Frontend (React Web)**
```bash
# Navegar para o diretório do frontend
cd frontend

# Copiar arquivo de exemplo
cp .env.example .env

# Editar com suas chaves reais
nano .env
```

### **🔑 Passo 2: Configurar Chaves Reais**

#### **2.1 Supabase (Banco de Dados)**
```bash
# Obter do Supabase Dashboard
SUPABASE_PROJECT_ID=jevaycxfcszepxuybxel
SUPABASE_PROJECT_URL=https://jevaycxfcszepxuybxel.supabase.co
SUPABASE_DATABASE_KEY=H@cker99813044
SUPABASE_API_KEY_ANON=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_API_KEY_SERVICE=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_JWT_SECRET=GsFzEwqKgnx6asUskJG8oJelqUJ2zIRai14D3WiVjGoXzD1kJhvayr+Dyp0qdHbVPcTUMsDRiShOAPlWGPqzqg==
```

#### **2.2 Stripe (Pagamentos)**
```bash
# Obter do Stripe Dashboard
STRIPE_ACCOUNT_NAME=Run Drivers
STRIPE_PUBLISHABLE_KEY=YOUR_STRIPE_PUBLISHABLE_KEY
STRIPE_SECRET_KEY=YOUR_STRIPE_SECRET_KEY
```

#### **2.3 Google Maps**
```bash
# Obter do Google Cloud Console
GOOGLE_MAPS_API_KEY=YOUR_GOOGLE_MAPS_API_KEY
GOOGLE_MAPS_PROJECT_ID=YOUR_GOOGLE_CLOUD_PROJECT_ID
```

#### **2.4 Railway (Deploy)**
```bash
# Obter do Railway Dashboard
RAILWAY_PROJECT_NAME=adm-rundrivers
RAILWAY_API_TOKEN=99451426-65a7-42fc-963e-5b13fd084cf4
RAILWAY_DEPLOY_URL=https://adm-rundrivers-production.up.railway.app
```

### **🔧 Passo 3: Configurar Google Maps**

#### **3.1 Criar Projeto no Google Cloud Console**
1. Acesse: https://console.cloud.google.com/
2. Crie um novo projeto ou selecione existente
3. Ative as APIs necessárias:
   - Maps SDK for Android
   - Maps SDK for iOS
   - Places API
   - Geocoding API
   - Directions API
   - Distance Matrix API

#### **3.2 Criar API Key**
1. Vá para **APIs & Services** > **Credentials**
2. Clique em **Create Credentials** > **API Key**
3. Configure restrições de segurança
4. Copie a chave para `GOOGLE_MAPS_API_KEY`

### **🚀 Passo 4: Testar Configuração**

#### **4.1 Verificar Configuração**
```bash
# No diretório raiz
npm run validate-env

# Ou verificar manualmente
node -e "console.log(require('./src/constants/keys').validateKeys())"
```

#### **4.2 Testar APIs**
```bash
# Testar backend
curl https://adm-rundrivers-production.up.railway.app/health

# Testar Supabase
curl -H "apikey: YOUR_SUPABASE_KEY" https://jevaycxfcszepxuybxel.supabase.co/rest/v1/

# Testar Stripe
curl -H "Authorization: Bearer YOUR_STRIPE_KEY" https://api.stripe.com/v1/account
```

### **📱 Passo 5: Configurar Mobile App**

#### **5.1 Android**
```xml
<!-- android/app/src/main/AndroidManifest.xml -->
<application>
  <meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_GOOGLE_MAPS_API_KEY"/>
</application>
```

#### **5.2 iOS**
```objc
// ios/YourApp/AppDelegate.mm
#import <GoogleMaps/GoogleMaps.h>

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  [GMSServices provideAPIKey:@"YOUR_GOOGLE_MAPS_API_KEY"];
  // ... resto do código
}
```

### **🔒 Passo 6: Segurança**

#### **6.1 Proteger Arquivos .env**
```bash
# Verificar se .env está no .gitignore
cat .gitignore | grep .env

# Se não estiver, adicionar:
echo ".env" >> .gitignore
echo ".env.local" >> .gitignore
echo ".env.production" >> .gitignore
```

#### **6.2 Validar Configuração**
```bash
# Script de validação
npm run validate-config

# Ou executar manualmente
node scripts/validate-env.js
```

### **📊 Passo 7: Monitoramento**

#### **7.1 Verificar Status**
```bash
# Verificar todas as configurações
npm run check-status

# Verificar APIs
npm run test-apis

# Verificar banco de dados
npm run test-database
```

#### **7.2 Logs de Configuração**
```bash
# Ver logs de inicialização
npm run logs

# Ver configurações ativas
npm run show-config
```

## 🎯 **Checklist de Configuração**

### **✅ Variáveis de Ambiente**
- [ ] `.env` criado a partir de `.env.example`
- [ ] Todas as chaves reais configuradas
- [ ] Arquivo `.env` no `.gitignore`
- [ ] Validação de configuração passou

### **✅ APIs Configuradas**
- [ ] Supabase conectado
- [ ] Stripe funcionando
- [ ] Google Maps configurado
- [ ] Railway deploy ativo

### **✅ Mobile App**
- [ ] Android configurado
- [ ] iOS configurado
- [ ] Permissões configuradas
- [ ] Testes passando

### **✅ Backend**
- [ ] Flask rodando
- [ ] APIs respondendo
- [ ] Banco conectado
- [ ] Logs funcionando

### **✅ Frontend**
- [ ] React rodando
- [ ] APIs integradas
- [ ] Design system aplicado
- [ ] Testes passando

## 🚀 **Comandos Úteis**

### **Desenvolvimento**
```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Testar configuração
npm run test-config

# Validar ambiente
npm run validate-env
```

### **Produção**
```bash
# Build para produção
npm run build

# Deploy
npm run deploy

# Verificar status
npm run status
```

## 📋 **Troubleshooting**

### **Problema: "API key not valid"**
```bash
# Solução:
1. Verificar se a chave está correta
2. Verificar se as APIs estão ativadas
3. Verificar restrições de aplicativo
4. Verificar billing ativo
```

### **Problema: "Database connection failed"**
```bash
# Solução:
1. Verificar DATABASE_URL
2. Verificar credenciais
3. Verificar se o banco está ativo
4. Verificar firewall
```

### **Problema: "Stripe payment failed"**
```bash
# Solução:
1. Verificar chaves do Stripe
2. Verificar modo (test/live)
3. Verificar webhook configurado
4. Verificar logs do Stripe
```

## 🎉 **Resultado Final**

Após seguir todos os passos, você terá:

- ✅ **Projeto 100% configurado**
- ✅ **Todas as APIs funcionais**
- ✅ **Mobile app pronto**
- ✅ **Backend operacional**
- ✅ **Frontend integrado**
- ✅ **Segurança implementada**

**O projeto Run Driver Enterprise estará pronto para produção!** 🚀