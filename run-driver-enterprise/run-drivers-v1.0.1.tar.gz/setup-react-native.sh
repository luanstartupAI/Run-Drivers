#!/bin/bash

# 🚀 Script de Setup React Native - Run Driver Enterprise
# Este script configura o projeto React Native com todas as dependências necessárias

echo "🚀 Iniciando setup do React Native para Run Driver Enterprise..."

# Verificar se Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não encontrado. Por favor, instale o Node.js primeiro."
    exit 1
fi

# Verificar se React Native CLI está instalado
if ! command -v npx &> /dev/null; then
    echo "❌ NPX não encontrado. Por favor, instale o Node.js primeiro."
    exit 1
fi

# Criar diretório do projeto mobile
echo "📁 Criando projeto React Native..."
npx react-native@latest init RunDriverMobile --template react-native-template-typescript

# Navegar para o diretório do projeto
cd RunDriverMobile

echo "📦 Instalando dependências principais..."

# Navegação
npm install @react-navigation/native @react-navigation/stack @react-navigation/bottom-tabs
npm install react-native-screens react-native-safe-area-context

# UI/Design System
npm install native-base react-native-svg
npm install react-native-vector-icons
npm install react-native-reanimated react-native-gesture-handler

# Estado e Dados
npm install zustand @tanstack/react-query
npm install @react-native-async-storage/async-storage

# APIs e Serviços
npm install axios
npm install @supabase/supabase-js

# Formulários e Validação
npm install react-hook-form @hookform/resolvers zod

# Mapas e Geolocalização
npm install react-native-maps
npm install react-native-geolocation-service

# Funcionalidades Mobile
npm install react-native-push-notification
npm install react-native-image-picker
npm install react-native-biometrics

# Desenvolvimento
npm install --save-dev @types/react-native-vector-icons

echo "🔧 Configurando arquivos..."

# Criar estrutura de diretórios
mkdir -p src/{components/{atoms,molecules,organisms,templates},screens/{auth,dashboard,trips,profile,wallet,social,gamification},navigation,stores,services,utils,constants,hooks,types}

# Copiar tokens de design do projeto web
cp ../frontend/src/constants/tokens.js src/constants/

echo "📝 Criando arquivos base..."

# Criar arquivo de configuração do tema
cat > src/constants/theme.ts << 'EOF'
import { extendTheme } from 'native-base';
import { colors } from './tokens';

export const theme = extendTheme({
  colors: {
    primary: colors.primary,
    neutral: colors.neutral,
    blue: colors.blue,
    success: colors.success,
    warning: colors.warning,
    error: colors.error,
  },
  config: {
    initialColorMode: 'light',
  },
});

export type CustomThemeType = typeof theme;
EOF

# Criar arquivo de tipos base
cat > src/types/index.ts << 'EOF'
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  phone?: string;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Trip {
  id: string;
  origin: string;
  destination: string;
  price: number;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface Position {
  coords: {
    latitude: number;
    longitude: number;
    accuracy: number;
    altitude: number | null;
    heading: number | null;
    speed: number | null;
  };
  timestamp: number;
}
EOF

# Criar store de autenticação base
cat > src/stores/authStore.ts << 'EOF'
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  setUser: (user: User) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      login: async (email: string, password: string) => {
        set({ isLoading: true });
        try {
          // TODO: Implementar login real com Supabase
          const mockUser: User = {
            id: '1',
            email,
            name: 'Motorista Teste',
            isVerified: true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          set({ user: mockUser, isAuthenticated: true });
        } catch (error) {
          console.error('Erro no login:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },
      logout: () => {
        set({ user: null, isAuthenticated: false });
      },
      setUser: (user: User) => {
        set({ user, isAuthenticated: true });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
EOF

# Criar serviço de API base
cat > src/services/api.ts << 'EOF'
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const api = axios.create({
  baseURL: process.env.API_URL || 'http://localhost:8000',
  timeout: 10000,
});

api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('auth-token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await AsyncStorage.removeItem('auth-token');
      // TODO: Redirecionar para login
    }
    return Promise.reject(error);
  }
);

export default api;
EOF

# Criar navegação base
cat > src/navigation/AppNavigator.tsx << 'EOF'
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuthStore } from '../stores/authStore';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Placeholder components
const LoginScreen = () => null;
const DashboardScreen = () => null;
const TripsScreen = () => null;
const ProfileScreen = () => null;

const AuthStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Login" component={LoginScreen} />
  </Stack.Navigator>
);

const MainTab = () => (
  <Tab.Navigator>
    <Tab.Screen name="Dashboard" component={DashboardScreen} />
    <Tab.Screen name="Trips" component={TripsScreen} />
    <Tab.Screen name="Profile" component={ProfileScreen} />
  </Tab.Navigator>
);

export const AppNavigator = () => {
  const { isAuthenticated } = useAuthStore();

  return (
    <NavigationContainer>
      {isAuthenticated ? <MainTab /> : <AuthStack />}
    </NavigationContainer>
  );
};
EOF

# Configurar App.tsx
cat > App.tsx << 'EOF'
import React from 'react';
import { NativeBaseProvider } from 'native-base';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { theme } from './src/constants/theme';
import { AppNavigator } from './src/navigation/AppNavigator';

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <NativeBaseProvider theme={theme}>
        <AppNavigator />
      </NativeBaseProvider>
    </QueryClientProvider>
  );
};

export default App;
EOF

echo "✅ Setup do React Native concluído!"
echo ""
echo "📱 Próximos passos:"
echo "1. cd RunDriverMobile"
echo "2. npx react-native run-android (para Android)"
echo "3. npx react-native run-ios (para iOS)"
echo ""
echo "🔧 Configurações adicionais necessárias:"
echo "- Configurar react-native-vector-icons"
echo "- Configurar react-native-maps"
echo "- Configurar push notifications"
echo ""
echo "📚 Documentação completa em: MIGRATION_PLAN.md"