# 🗺️ Configuração Completa do Google Maps

## 🚀 **Guia de Configuração para Run Driver Enterprise**

### **1. Criar Projeto no Google Cloud Console**

#### **Passo 1: Acessar Google Cloud Console**
1. Acesse: https://console.cloud.google.com/
2. Faça login com sua conta Google
3. Crie um novo projeto ou selecione um existente

#### **Passo 2: Ativar APIs Necessárias**
```bash
# APIs que precisam ser ativadas:
✅ Maps SDK for Android
✅ Maps SDK for iOS
✅ Places API
✅ Geocoding API
✅ Directions API
✅ Distance Matrix API
✅ Roads API (opcional)
```

#### **Passo 3: Configurar Credenciais**
1. Vá para **APIs & Services** > **Credentials**
2. Clique em **Create Credentials** > **API Key**
3. Copie a chave gerada

### **2. Configurar Chaves no Projeto**

#### **Passo 1: Atualizar arquivo de configuração**
```typescript
// src/constants/maps.ts
export const GOOGLE_MAPS_CONFIG = {
  API_KEY: 'SUA_CHAVE_AQUI', // Substitua pela sua chave real
  // ... resto da configuração
};
```

#### **Passo 2: Configurar Android**
```xml
<!-- android/app/src/main/AndroidManifest.xml -->
<application>
  <meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="SUA_CHAVE_AQUI"/>
</application>
```

#### **Passo 3: Configurar iOS**
```xml
<!-- ios/YourApp/AppDelegate.mm -->
#import <GoogleMaps/GoogleMaps.h>

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  [GMSServices provideAPIKey:@"SUA_CHAVE_AQUI"];
  // ... resto do código
}
```

### **3. Configurar Restrições de Segurança**

#### **Passo 1: Restringir por Aplicativo**
1. No Google Cloud Console, vá para **Credentials**
2. Clique na sua API Key
3. Em **Application restrictions**, selecione:
   - **Android apps** (para Android)
   - **iOS apps** (para iOS)

#### **Passo 2: Configurar SHA-1 para Android**
```bash
# Obter SHA-1 do projeto
cd android && ./gradlew signingReport
```

#### **Passo 3: Configurar Bundle ID para iOS**
```bash
# Bundle ID padrão do React Native
com.run.driver.enterprise
```

### **4. Configurar Quotas e Billing**

#### **Passo 1: Configurar Billing**
1. Vá para **Billing** no Google Cloud Console
2. Configure uma conta de faturamento
3. Ative o projeto para billing

#### **Passo 2: Configurar Quotas**
```bash
# Quotas recomendadas para desenvolvimento:
✅ 1000 requests/day - Geocoding API
✅ 1000 requests/day - Directions API
✅ 1000 requests/day - Places API
✅ 1000 requests/day - Distance Matrix API
```

### **5. Testar Configuração**

#### **Passo 1: Teste de Conectividade**
```typescript
// O serviço já inclui teste automático
import { googleMapsService } from './src/services/googleMapsService';

// Testar conexão
const isConnected = await googleMapsService.testConnection();
console.log('Google Maps conectado:', isConnected);
```

#### **Passo 2: Teste de Geocodificação**
```typescript
// Testar geocodificação
const results = await googleMapsService.geocode('São Paulo, Brasil');
console.log('Resultados:', results);
```

### **6. Configurações de Produção**

#### **Passo 1: Chaves de Produção**
```typescript
// Para produção, use variáveis de ambiente
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY || 'YOUR_KEY';
```

#### **Passo 2: Configurar .env**
```bash
# .env
GOOGLE_MAPS_API_KEY=sua_chave_de_producao_aqui
```

#### **Passo 3: Configurar Build**
```bash
# android/app/build.gradle
android {
  defaultConfig {
    manifestPlaceholders = [
      GOOGLE_MAPS_API_KEY: project.env.get("GOOGLE_MAPS_API_KEY")
    ]
  }
}
```

### **7. Funcionalidades Implementadas**

#### **✅ Geocodificação**
```typescript
// Endereço → Coordenadas
const results = await googleMapsService.geocode('Rua das Flores, 123');

// Coordenadas → Endereço
const address = await googleMapsService.reverseGeocode(-23.5505, -46.6333);
```

#### **✅ Direções**
```typescript
// Obter rota entre dois pontos
const directions = await googleMapsService.getDirections(
  'São Paulo, SP',
  'Rio de Janeiro, RJ',
  'driving'
);
```

#### **✅ Busca de Lugares**
```typescript
// Buscar lugares próximos
const places = await googleMapsService.searchNearbyPlaces(
  -23.5505, -46.6333, // São Paulo
  5000, // 5km de raio
  'restaurant' // tipo de lugar
);
```

#### **✅ Matriz de Distâncias**
```typescript
// Calcular distâncias entre múltiplos pontos
const matrix = await googleMapsService.getDistanceMatrix(
  [{ lat: -23.5505, lng: -46.6333 }], // origem
  [{ lat: -22.9068, lng: -43.1729 }], // destino
  'driving'
);
```

### **8. Monitoramento e Analytics**

#### **Passo 1: Configurar Google Analytics**
```typescript
// Integrar com Google Analytics para métricas de uso
import analytics from '@react-native-firebase/analytics';

// Evento de uso do mapa
await analytics.logEvent('map_interaction', {
  action: 'view_map',
  location: 'sao_paulo'
});
```

#### **Passo 2: Monitorar Uso da API**
1. No Google Cloud Console, vá para **APIs & Services** > **Dashboard**
2. Monitore o uso das APIs
3. Configure alertas para limites de quota

### **9. Troubleshooting**

#### **Problema: "API key not valid"**
```bash
# Solução:
1. Verificar se a chave está correta
2. Verificar se as APIs estão ativadas
3. Verificar restrições de aplicativo
4. Verificar billing ativo
```

#### **Problema: "Quota exceeded"**
```bash
# Solução:
1. Aumentar quotas no Google Cloud Console
2. Implementar cache local
3. Otimizar chamadas da API
4. Usar billing para aumentar limites
```

#### **Problema: "Network error"**
```bash
# Solução:
1. Verificar conectividade de internet
2. Verificar permissões de rede
3. Implementar retry logic
4. Usar fallback para dados offline
```

### **10. Otimizações de Performance**

#### **Cache Local**
```typescript
// Implementar cache para reduzir chamadas da API
const cacheKey = `geocode_${address}`;
const cached = await AsyncStorage.getItem(cacheKey);
if (cached) return JSON.parse(cached);
```

#### **Batch Requests**
```typescript
// Agrupar múltiplas requisições
const batchGeocode = async (addresses: string[]) => {
  const promises = addresses.map(addr => googleMapsService.geocode(addr));
  return Promise.all(promises);
};
```

#### **Offline Support**
```typescript
// Dados offline para funcionalidades básicas
const offlineData = {
  'São Paulo': { lat: -23.5505, lng: -46.6333 },
  'Rio de Janeiro': { lat: -22.9068, lng: -43.1729 },
  // ... mais cidades
};
```

## 🎯 **Próximos Passos**

1. **Configure sua API key** seguindo este guia
2. **Teste todas as funcionalidades** implementadas
3. **Monitore o uso** da API
4. **Otimize conforme necessário**

## ✅ **Status da Implementação**

- ✅ **Configuração completa** do Google Maps
- ✅ **Todas as APIs** necessárias implementadas
- ✅ **Serviços otimizados** para performance
- ✅ **Interface intuitiva** para usuários
- ✅ **Monitoramento** e analytics

**O projeto está pronto para usar Google Maps com todas as funcionalidades!** 🚀