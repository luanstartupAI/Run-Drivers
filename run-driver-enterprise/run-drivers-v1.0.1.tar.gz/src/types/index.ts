export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  phone?: string;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Trip {
  id: string;
  origin: string;
  destination: string;
  price: number;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface Position {
  coords: {
    latitude: number;
    longitude: number;
    accuracy: number;
    altitude: number | null;
    heading: number | null;
    speed: number | null;
  };
  timestamp: number;
}
