import React, { useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Text, Card } from '../../components/atoms';
import { colors } from '../../constants/tokens';

interface Trip {
  id: string;
  origin: string;
  destination: string;
  price: number;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  createdAt: string;
  distance: string;
  duration: string;
}

export const TripsScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'today' | 'week' | 'month'>('today');

  // Mock data
  const mockTrips: Trip[] = [
    {
      id: '1',
      origin: 'Shopping Center',
      destination: 'Aeroporto Internacional',
      price: 45.50,
      status: 'completed',
      createdAt: '2024-08-05T10:30:00Z',
      distance: '12.5 km',
      duration: '25 min',
    },
    {
      id: '2',
      origin: 'Centro da Cidade',
      destination: 'Universidade Federal',
      price: 28.00,
      status: 'active',
      createdAt: '2024-08-05T14:15:00Z',
      distance: '8.2 km',
      duration: '18 min',
    },
    {
      id: '3',
      origin: 'Residencial Parque',
      destination: 'Shopping Plaza',
      price: 32.80,
      status: 'pending',
      createdAt: '2024-08-05T16:45:00Z',
      distance: '10.1 km',
      duration: '22 min',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return colors.success[500];
      case 'active':
        return colors.primary[500];
      case 'pending':
        return colors.warning[500];
      case 'cancelled':
        return colors.error[500];
      default:
        return colors.neutral[500];
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Concluída';
      case 'active':
        return 'Em Andamento';
      case 'pending':
        return 'Pendente';
      case 'cancelled':
        return 'Cancelada';
      default:
        return 'Desconhecido';
    }
  };

  const handleStartTrip = (trip: Trip) => {
    Alert.alert(
      'Iniciar Viagem',
      `Deseja iniciar a viagem para ${trip.destination}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Iniciar', onPress: () => console.log('Iniciando viagem:', trip.id) },
      ]
    );
  };

  const handleCompleteTrip = (trip: Trip) => {
    Alert.alert(
      'Finalizar Viagem',
      `Deseja finalizar a viagem para ${trip.destination}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Finalizar', onPress: () => console.log('Finalizando viagem:', trip.id) },
      ]
    );
  };

  const renderTripCard = (trip: Trip) => (
    <Card key={trip.id} variant="default" padding="md" style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
        <Text variant="body" weight="semibold">
          {trip.origin} → {trip.destination}
        </Text>
        <Text variant="h4" weight="bold" color="primary">
          R$ {trip.price.toFixed(2)}
        </Text>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 }}>
        <Text variant="caption" color="secondary">
          📍 {trip.distance}
        </Text>
        <Text variant="caption" color="secondary">
          ⏱️ {trip.duration}
        </Text>
        <Text variant="caption" color="secondary">
          🕐 {new Date(trip.createdAt).toLocaleTimeString('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit' 
          })}
        </Text>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ 
          backgroundColor: getStatusColor(trip.status) + '20', 
          paddingHorizontal: 8, 
          paddingVertical: 4, 
          borderRadius: 4 
        }}>
          <Text variant="caption" style={{ color: getStatusColor(trip.status) }}>
            {getStatusText(trip.status)}
          </Text>
        </View>

        {trip.status === 'pending' && (
          <Button
            variant="manus"
            size="sm"
            onPress={() => handleStartTrip(trip)}
          >
            Iniciar
          </Button>
        )}

        {trip.status === 'active' && (
          <Button
            variant="success"
            size="sm"
            onPress={() => handleCompleteTrip(trip)}
          >
            Finalizar
          </Button>
        )}
      </View>
    </Card>
  );

  const tabs = [
    { id: 'today', label: 'Hoje', count: mockTrips.length },
    { id: 'week', label: 'Esta Semana', count: 15 },
    { id: 'month', label: 'Este Mês', count: 67 },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.neutral[50] }}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
        {/* Header */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h2" weight="bold" color="primary">
            Minhas Viagens
          </Text>
          <Text variant="body" color="secondary">
            Acompanhe suas corridas e ganhos
          </Text>
        </View>

        {/* Stats Cards */}
        <View style={{ flexDirection: 'row', marginBottom: 24, gap: 12 }}>
          <Card variant="default" padding="md" style={{ flex: 1 }}>
            <Text variant="h3" weight="bold" color="primary" style={{ marginBottom: 4 }}>
              {mockTrips.length}
            </Text>
            <Text variant="caption" color="secondary">
              Viagens Hoje
            </Text>
          </Card>
          <Card variant="default" padding="md" style={{ flex: 1 }}>
            <Text variant="h3" weight="bold" color="success" style={{ marginBottom: 4 }}>
              R$ 156,80
            </Text>
            <Text variant="caption" color="secondary">
              Ganhos Hoje
            </Text>
          </Card>
        </View>

        {/* Tabs */}
        <View style={{ flexDirection: 'row', marginBottom: 20, backgroundColor: colors.neutral[100], borderRadius: 8, padding: 4 }}>
          {tabs.map((tab) => (
            <TouchableOpacity
              key={tab.id}
              style={{
                flex: 1,
                paddingVertical: 8,
                paddingHorizontal: 12,
                borderRadius: 6,
                backgroundColor: activeTab === tab.id ? colors.primary[500] : 'transparent',
                alignItems: 'center',
              }}
              onPress={() => setActiveTab(tab.id as any)}
            >
              <Text
                variant="body"
                weight="medium"
                style={{
                  color: activeTab === tab.id ? 'white' : colors.neutral[600],
                }}
              >
                {tab.label} ({tab.count})
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Trips List */}
        <View style={{ marginBottom: 20 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            Viagens {activeTab === 'today' ? 'de Hoje' : activeTab === 'week' ? 'da Semana' : 'do Mês'}
          </Text>
          
          {mockTrips.length > 0 ? (
            mockTrips.map(renderTripCard)
          ) : (
            <Card variant="default" padding="lg">
              <View style={{ alignItems: 'center', paddingVertical: 20 }}>
                <Text variant="h3" style={{ marginBottom: 8 }}>
                  🚗
                </Text>
                <Text variant="body" color="secondary" style={{ textAlign: 'center' }}>
                  Nenhuma viagem encontrada
                </Text>
                <Text variant="caption" color="secondary" style={{ textAlign: 'center', marginTop: 4 }}>
                  Suas viagens aparecerão aqui
                </Text>
              </View>
            </Card>
          )}
        </View>

        {/* Quick Actions */}
        <View style={{ marginBottom: 20 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            Ações Rápidas
          </Text>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Button
              variant="manus"
              size="md"
              style={{ flex: 1 }}
              onPress={() => Alert.alert('Nova Viagem', 'Iniciando nova viagem...')}
            >
              🚗 Nova Viagem
            </Button>
            <Button
              variant="outline"
              size="md"
              style={{ flex: 1 }}
              onPress={() => Alert.alert('Histórico', 'Abrindo histórico...')}
            >
              📋 Histórico
            </Button>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};