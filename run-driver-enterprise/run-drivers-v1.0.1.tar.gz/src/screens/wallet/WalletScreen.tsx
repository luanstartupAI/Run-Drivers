import React, { useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Text, Card, Input } from '../../components/atoms';
import { colors } from '../../constants/tokens';

interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'withdrawal';
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

export const WalletScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'balance' | 'transactions' | 'withdraw'>('balance');
  const [withdrawAmount, setWithdrawAmount] = useState('');

  // Mock data
  const balance = 1256.80;
  const pendingBalance = 234.50;
  
  const transactions: Transaction[] = [
    {
      id: '1',
      type: 'income',
      amount: 45.50,
      description: 'Viagem - Shopping Center → Aeroporto',
      date: '2024-08-05T10:30:00Z',
      status: 'completed',
    },
    {
      id: '2',
      type: 'income',
      amount: 28.00,
      description: 'Viagem - Centro → Universidade',
      date: '2024-08-05T14:15:00Z',
      status: 'completed',
    },
    {
      id: '3',
      type: 'withdrawal',
      amount: -500.00,
      description: 'Saque para conta bancária',
      date: '2024-08-04T09:00:00Z',
      status: 'completed',
    },
    {
      id: '4',
      type: 'income',
      amount: 32.80,
      description: 'Viagem - Residencial → Shopping',
      date: '2024-08-05T16:45:00Z',
      status: 'pending',
    },
  ];

  const tabs = [
    { id: 'balance', label: 'Saldo', icon: '💰' },
    { id: 'transactions', label: 'Transações', icon: '📋' },
    { id: 'withdraw', label: 'Sacar', icon: '💳' },
  ];

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'income':
        return colors.success[500];
      case 'expense':
        return colors.error[500];
      case 'withdrawal':
        return colors.warning[500];
      default:
        return colors.neutral[500];
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'income':
        return '💰';
      case 'expense':
        return '💸';
      case 'withdrawal':
        return '💳';
      default:
        return '📄';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return colors.success[500];
      case 'pending':
        return colors.warning[500];
      case 'failed':
        return colors.error[500];
      default:
        return colors.neutral[500];
    }
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (!amount || amount <= 0) {
      Alert.alert('Erro', 'Digite um valor válido');
      return;
    }
    if (amount > balance) {
      Alert.alert('Erro', 'Saldo insuficiente');
      return;
    }

    Alert.alert(
      'Confirmar Saque',
      `Deseja sacar R$ ${amount.toFixed(2)}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Confirmar', onPress: () => {
          Alert.alert('Sucesso', 'Saque solicitado com sucesso!');
          setWithdrawAmount('');
        }},
      ]
    );
  };

  const renderBalanceCard = () => (
    <Card variant="elevated" padding="lg" style={{ marginBottom: 24 }}>
      <View style={{ alignItems: 'center' }}>
        <Text variant="h1" weight="bold" color="primary" style={{ marginBottom: 8 }}>
          R$ {balance.toFixed(2)}
        </Text>
        <Text variant="body" color="secondary" style={{ marginBottom: 16 }}>
          Saldo Disponível
        </Text>
        
        <View style={{ flexDirection: 'row', gap: 16 }}>
          <View style={{ alignItems: 'center' }}>
            <Text variant="h4" weight="bold" color="warning">
              R$ {pendingBalance.toFixed(2)}
            </Text>
            <Text variant="caption" color="secondary">
              Pendente
            </Text>
          </View>
          <View style={{ alignItems: 'center' }}>
            <Text variant="h4" weight="bold" color="success">
              R$ {(balance + pendingBalance).toFixed(2)}
            </Text>
            <Text variant="caption" color="secondary">
              Total
            </Text>
          </View>
        </View>
      </View>
    </Card>
  );

  const renderTransactions = () => (
    <View style={{ marginBottom: 24 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
        Transações Recentes
      </Text>
      <View style={{ gap: 8 }}>
        {transactions.map((transaction) => (
          <Card key={transaction.id} variant="default" padding="md">
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
              <Text variant="h3" style={{ marginRight: 12 }}>
                {getTransactionIcon(transaction.type)}
              </Text>
              <View style={{ flex: 1 }}>
                <Text variant="body" weight="semibold">
                  {transaction.description}
                </Text>
                <Text variant="caption" color="secondary">
                  {new Date(transaction.date).toLocaleDateString('pt-BR')}
                </Text>
              </View>
              <Text
                variant="h4"
                weight="bold"
                style={{ color: getTransactionColor(transaction.type) }}
              >
                {transaction.amount > 0 ? '+' : ''}R$ {transaction.amount.toFixed(2)}
              </Text>
            </View>
            
            <View style={{ 
              backgroundColor: getStatusColor(transaction.status) + '20',
              paddingHorizontal: 8,
              paddingVertical: 4,
              borderRadius: 4,
              alignSelf: 'flex-start'
            }}>
              <Text variant="caption" style={{ color: getStatusColor(transaction.status) }}>
                {transaction.status === 'completed' ? 'Concluída' : 
                 transaction.status === 'pending' ? 'Pendente' : 'Falhou'}
              </Text>
            </View>
          </Card>
        ))}
      </View>
    </View>
  );

  const renderWithdrawForm = () => (
    <View style={{ marginBottom: 24 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
        Sacar Dinheiro
      </Text>
      <Card variant="default" padding="lg">
        <Input
          label="Valor para sacar"
          placeholder="Digite o valor"
          value={withdrawAmount}
          onChangeText={setWithdrawAmount}
          keyboardType="numeric"
        />
        
        <View style={{ marginTop: 16 }}>
          <Text variant="body" color="secondary" style={{ marginBottom: 8 }}>
            Saldo disponível: R$ {balance.toFixed(2)}
          </Text>
          <Button
            variant="manus"
            size="lg"
            onPress={handleWithdraw}
            disabled={!withdrawAmount || parseFloat(withdrawAmount) <= 0}
          >
            Sacar Dinheiro
          </Button>
        </View>
      </Card>
    </View>
  );

  const renderQuickActions = () => (
    <View style={{ marginBottom: 24 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
        Ações Rápidas
      </Text>
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <Button
          variant="manus"
          size="md"
          style={{ flex: 1 }}
          onPress={() => Alert.alert('Histórico', 'Abrindo histórico completo...')}
        >
          📋 Histórico
        </Button>
        <Button
          variant="outline"
          size="md"
          style={{ flex: 1 }}
          onPress={() => Alert.alert('Relatórios', 'Abrindo relatórios...')}
        >
          📊 Relatórios
        </Button>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.neutral[50] }}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
        {/* Header */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h2" weight="bold" color="primary">
            Minha Carteira
          </Text>
          <Text variant="body" color="secondary">
            Gerencie seus ganhos e saques
          </Text>
        </View>

        {/* Tabs */}
        <View style={{ flexDirection: 'row', marginBottom: 20, backgroundColor: colors.neutral[100], borderRadius: 8, padding: 4 }}>
          {tabs.map((tab) => (
            <TouchableOpacity
              key={tab.id}
              style={{
                flex: 1,
                paddingVertical: 8,
                paddingHorizontal: 12,
                borderRadius: 6,
                backgroundColor: activeTab === tab.id ? colors.primary[500] : 'transparent',
                alignItems: 'center',
              }}
              onPress={() => setActiveTab(tab.id as any)}
            >
              <Text
                variant="body"
                weight="medium"
                style={{
                  color: activeTab === tab.id ? 'white' : colors.neutral[600],
                }}
              >
                {tab.icon} {tab.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Content based on active tab */}
        {activeTab === 'balance' && (
          <>
            {renderBalanceCard()}
            {renderQuickActions()}
          </>
        )}

        {activeTab === 'transactions' && (
          <>
            {renderTransactions()}
            {renderQuickActions()}
          </>
        )}

        {activeTab === 'withdraw' && (
          <>
            {renderWithdrawForm()}
            {renderQuickActions()}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};