import React from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Text, Card } from '../../components/atoms';
import { useAuthStore } from '../../stores/authStore';
import { colors } from '../../constants/tokens';

export const DashboardScreen: React.FC = () => {
  const { user, logout } = useAuthStore();

  const handleLogout = async () => {
    await logout();
  };

  const stats = [
    { label: 'Viagens Hoje', value: '12', color: colors.primary[500] },
    { label: 'Ganhos Hoje', value: 'R$ 156,80', color: colors.success[500] },
    { label: 'Avaliação', value: '4.8 ⭐', color: colors.warning[500] },
    { label: 'Nível', value: 'Bronze', color: colors.blue[500] },
  ];

  const quickActions = [
    { title: 'Nova Viagem', subtitle: 'Iniciar corrida', icon: '🚗' },
    { title: 'Histórico', subtitle: 'Ver viagens', icon: '📋' },
    { title: 'Ganhos', subtitle: 'Ver lucros', icon: '💰' },
    { title: 'Perfil', subtitle: 'Editar dados', icon: '👤' },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.neutral[50] }}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
        {/* Header */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h2" weight="bold" color="primary">
            Olá, {user?.name?.split(' ')[0]}! 👋
          </Text>
          <Text variant="body" color="secondary">
            Bem-vindo de volta ao Run Driver
          </Text>
        </View>

        {/* Stats Grid */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            Resumo de Hoje
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
            {stats.map((stat, index) => (
              <Card
                key={index}
                variant="default"
                padding="md"
                style={{
                  flex: 1,
                  minWidth: '45%',
                  alignItems: 'center',
                }}
              >
                <Text variant="h3" weight="bold" style={{ color: stat.color, marginBottom: 4 }}>
                  {stat.value}
                </Text>
                <Text variant="caption" color="secondary" style={{ textAlign: 'center' }}>
                  {stat.label}
                </Text>
              </Card>
            ))}
          </View>
        </View>

        {/* Quick Actions */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            Ações Rápidas
          </Text>
          <View style={{ gap: 12 }}>
            {quickActions.map((action, index) => (
              <TouchableOpacity key={index} activeOpacity={0.7}>
                <Card variant="default" padding="md">
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text variant="h3" style={{ marginRight: 12 }}>
                      {action.icon}
                    </Text>
                    <View style={{ flex: 1 }}>
                      <Text variant="body" weight="semibold">
                        {action.title}
                      </Text>
                      <Text variant="caption" color="secondary">
                        {action.subtitle}
                      </Text>
                    </View>
                  </View>
                </Card>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recent Trips */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            Viagens Recentes
          </Text>
          <Card variant="default" padding="md">
            <View style={{ alignItems: 'center', paddingVertical: 20 }}>
              <Text variant="h3" style={{ marginBottom: 8 }}>
                🚗
              </Text>
              <Text variant="body" color="secondary" style={{ textAlign: 'center' }}>
                Nenhuma viagem recente
              </Text>
              <Text variant="caption" color="secondary" style={{ textAlign: 'center', marginTop: 4 }}>
                Suas viagens aparecerão aqui
              </Text>
            </View>
          </Card>
        </View>

        {/* Logout Button */}
        <Button
          variant="outline"
          size="md"
          onPress={handleLogout}
          style={{ marginTop: 20 }}
        >
          Sair da Conta
        </Button>
      </ScrollView>
    </SafeAreaView>
  );
};