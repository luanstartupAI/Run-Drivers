import React, { useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Text, Card, Input } from '../../components/atoms';
import { useAuthStore } from '../../stores/authStore';
import { colors } from '../../constants/tokens';

interface ProfileSection {
  id: string;
  title: string;
  icon: string;
  onPress: () => void;
}

export const ProfileScreen: React.FC = () => {
  const { user, logout } = useAuthStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(user?.name || '');

  const profileSections: ProfileSection[] = [
    {
      id: 'personal',
      title: 'Dados Pessoais',
      icon: '👤',
      onPress: () => Alert.alert('Dados Pessoais', 'Abrindo dados pessoais...'),
    },
    {
      id: 'vehicle',
      title: 'Dados do Veículo',
      icon: '🚗',
      onPress: () => Alert.alert('Veículo', 'Abrindo dados do veículo...'),
    },
    {
      id: 'documents',
      title: 'Documentos',
      icon: '📄',
      onPress: () => Alert.alert('Documentos', 'Abrindo documentos...'),
    },
    {
      id: 'preferences',
      title: 'Preferências',
      icon: '⚙️',
      onPress: () => Alert.alert('Preferências', 'Abrindo preferências...'),
    },
    {
      id: 'security',
      title: 'Segurança',
      icon: '🔒',
      onPress: () => Alert.alert('Segurança', 'Abrindo configurações de segurança...'),
    },
    {
      id: 'support',
      title: 'Suporte',
      icon: '💬',
      onPress: () => Alert.alert('Suporte', 'Abrindo suporte...'),
    },
  ];

  const stats = [
    { label: 'Viagens', value: '156', icon: '🚗' },
    { label: 'Avaliação', value: '4.8', icon: '⭐' },
    { label: 'Nível', value: 'Bronze', icon: '🏆' },
    { label: 'Tempo', value: '2 anos', icon: '⏱️' },
  ];

  const handleSaveProfile = () => {
    Alert.alert('Sucesso', 'Perfil atualizado com sucesso!');
    setIsEditing(false);
  };

  const handleLogout = () => {
    Alert.alert(
      'Sair da Conta',
      'Tem certeza que deseja sair?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Sair', onPress: logout, style: 'destructive' },
      ]
    );
  };

  const renderProfileHeader = () => (
    <Card variant="elevated" padding="lg" style={{ marginBottom: 24 }}>
      <View style={{ alignItems: 'center' }}>
        {/* Avatar */}
        <View style={{
          width: 80,
          height: 80,
          borderRadius: 40,
          backgroundColor: colors.primary[100],
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 16,
        }}>
          <Text variant="h2">👤</Text>
        </View>

        {/* Name */}
        {isEditing ? (
          <Input
            value={editedName}
            onChangeText={setEditedName}
            style={{ marginBottom: 16, width: '100%' }}
          />
        ) : (
          <Text variant="h3" weight="bold" style={{ marginBottom: 8 }}>
            {user?.name || 'Motorista'}
          </Text>
        )}

        <Text variant="body" color="secondary" style={{ marginBottom: 16 }}>
          {user?.email || 'motorista@exemplo.com'}
        </Text>

        {/* Edit/Save Button */}
        {isEditing ? (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Button
              variant="manus"
              size="sm"
              onPress={handleSaveProfile}
            >
              Salvar
            </Button>
            <Button
              variant="outline"
              size="sm"
              onPress={() => setIsEditing(false)}
            >
              Cancelar
            </Button>
          </View>
        ) : (
          <Button
            variant="outline"
            size="sm"
            onPress={() => setIsEditing(true)}
          >
            Editar Perfil
          </Button>
        )}
      </View>
    </Card>
  );

  const renderStats = () => (
    <View style={{ marginBottom: 24 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
        Estatísticas
      </Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
        {stats.map((stat, index) => (
          <Card key={index} variant="default" padding="md" style={{ flex: 1, minWidth: '45%' }}>
            <View style={{ alignItems: 'center' }}>
              <Text variant="h3" style={{ marginBottom: 4 }}>
                {stat.icon}
              </Text>
              <Text variant="h4" weight="bold" color="primary" style={{ marginBottom: 4 }}>
                {stat.value}
              </Text>
              <Text variant="caption" color="secondary">
                {stat.label}
              </Text>
            </View>
          </Card>
        ))}
      </View>
    </View>
  );

  const renderProfileSections = () => (
    <View style={{ marginBottom: 24 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
        Configurações
      </Text>
      <View style={{ gap: 8 }}>
        {profileSections.map((section) => (
          <TouchableOpacity key={section.id} activeOpacity={0.7} onPress={section.onPress}>
            <Card variant="default" padding="md">
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text variant="h3" style={{ marginRight: 12 }}>
                  {section.icon}
                </Text>
                <View style={{ flex: 1 }}>
                  <Text variant="body" weight="semibold">
                    {section.title}
                  </Text>
                </View>
                <Text variant="body" color="secondary">
                  ›
                </Text>
              </View>
            </Card>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.neutral[50] }}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
        {/* Header */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h2" weight="bold" color="primary">
            Meu Perfil
          </Text>
          <Text variant="body" color="secondary">
            Gerencie suas informações e configurações
          </Text>
        </View>

        {/* Profile Header */}
        {renderProfileHeader()}

        {/* Stats */}
        {renderStats()}

        {/* Profile Sections */}
        {renderProfileSections()}

        {/* Logout Button */}
        <Button
          variant="error"
          size="lg"
          onPress={handleLogout}
          style={{ marginTop: 20 }}
        >
          Sair da Conta
        </Button>
      </ScrollView>
    </SafeAreaView>
  );
};