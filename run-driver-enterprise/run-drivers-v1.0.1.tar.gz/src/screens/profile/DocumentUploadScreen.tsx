import React, { useState } from 'react';
import {
  View,
  ScrollView,
  Alert,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Text, Card } from '../../components/atoms';
import { cameraService, ImageAsset } from '../../services/cameraService';
import { locationService, Position } from '../../services/locationService';
import { notificationService } from '../../services/notificationService';
import { colors } from '../../constants/tokens';

export const DocumentUploadScreen: React.FC = () => {
  const [currentLocation, setCurrentLocation] = useState<Position | null>(null);
  const [uploadedImage, setUploadedImage] = useState<ImageAsset | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [isLoadingCamera, setIsLoadingCamera] = useState(false);

  const handleTakePhoto = async () => {
    setIsLoadingCamera(true);
    try {
      const photo = await cameraService.takePhoto();
      if (photo) {
        setUploadedImage(photo);
        Alert.alert('Sucesso', 'Foto tirada com sucesso!');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro ao tirar foto');
    } finally {
      setIsLoadingCamera(false);
    }
  };

  const handlePickImage = async () => {
    setIsLoadingCamera(true);
    try {
      const image = await cameraService.pickImage();
      if (image) {
        setUploadedImage(image);
        Alert.alert('Sucesso', 'Imagem selecionada com sucesso!');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro ao selecionar imagem');
    } finally {
      setIsLoadingCamera(false);
    }
  };

  const handleGetLocation = async () => {
    setIsLoadingLocation(true);
    try {
      const permission = await locationService.requestLocationPermission();
      if (!permission.granted) {
        Alert.alert('Permissão Negada', permission.message);
        return;
      }

      const location = await locationService.getCurrentLocation();
      setCurrentLocation(location);
      Alert.alert('Sucesso', 'Localização obtida com sucesso!');
    } catch (error) {
      Alert.alert('Erro', 'Erro ao obter localização');
    } finally {
      setIsLoadingLocation(false);
    }
  };

  const handleTestNotification = () => {
    notificationService.sendLocalNotification({
      id: 'test_notification',
      title: 'Teste de Notificação! 🎉',
      message: 'Esta é uma notificação de teste do Run Driver',
      data: { type: 'test' },
    });
    Alert.alert('Notificação Enviada', 'Verifique a notificação no topo da tela');
  };

  const handleScheduleNotification = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(10, 0, 0, 0); // 10:00 AM amanhã

    notificationService.scheduleLocalNotification({
      id: 'scheduled_test',
      title: 'Lembrete Agendado! ⏰',
      message: 'Esta notificação foi agendada para amanhã às 10:00',
      date: tomorrow,
      data: { type: 'scheduled_test' },
    });
    Alert.alert('Notificação Agendada', 'Notificação agendada para amanhã às 10:00');
  };

  const renderLocationInfo = () => {
    if (!currentLocation) return null;

    return (
      <Card variant="default" padding="md" style={{ marginBottom: 16 }}>
        <Text variant="h4" weight="semibold" style={{ marginBottom: 12 }}>
          📍 Localização Atual
        </Text>
        <Text variant="body" style={{ marginBottom: 4 }}>
          Latitude: {currentLocation.coords.latitude.toFixed(6)}
        </Text>
        <Text variant="body" style={{ marginBottom: 4 }}>
          Longitude: {currentLocation.coords.longitude.toFixed(6)}
        </Text>
        <Text variant="body" style={{ marginBottom: 4 }}>
          Precisão: {currentLocation.coords.accuracy.toFixed(2)}m
        </Text>
        {currentLocation.coords.speed && (
          <Text variant="body">
            Velocidade: {locationService.formatSpeed(currentLocation.coords.speed)}
          </Text>
        )}
      </Card>
    );
  };

  const renderImageInfo = () => {
    if (!uploadedImage) return null;

    const validation = cameraService.validateImage(uploadedImage);

    return (
      <Card variant="default" padding="md" style={{ marginBottom: 16 }}>
        <Text variant="h4" weight="semibold" style={{ marginBottom: 12 }}>
          📸 Imagem Carregada
        </Text>
        <Text variant="body" style={{ marginBottom: 4 }}>
          Arquivo: {uploadedImage.fileName || 'Sem nome'}
        </Text>
        <Text variant="body" style={{ marginBottom: 4 }}>
          Tamanho: {uploadedImage.fileSize ? cameraService.formatFileSize(uploadedImage.fileSize) : 'Desconhecido'}
        </Text>
        <Text variant="body" style={{ marginBottom: 4 }}>
          Dimensões: {cameraService.getImageDimensions(uploadedImage)}
        </Text>
        <Text variant="body" style={{ marginBottom: 8 }}>
          Tipo: {uploadedImage.type || 'Desconhecido'}
        </Text>
        
        {validation.valid ? (
          <Text variant="body" color="success" weight="semibold">
            ✅ Imagem válida para upload
          </Text>
        ) : (
          <Text variant="body" color="error" weight="semibold">
            ❌ {validation.message}
          </Text>
        )}
      </Card>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.neutral[50] }}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
        {/* Header */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h2" weight="bold" color="primary">
            Funcionalidades Mobile
          </Text>
          <Text variant="body" color="secondary">
            Teste as funcionalidades específicas do mobile
          </Text>
        </View>

        {/* Camera Section */}
        <Card variant="elevated" padding="lg" style={{ marginBottom: 20 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            📸 Câmera
          </Text>
          <View style={{ gap: 12 }}>
            <Button
              variant="manus"
              size="md"
              onPress={handleTakePhoto}
              loading={isLoadingCamera}
            >
              Tirar Foto
            </Button>
            <Button
              variant="outline"
              size="md"
              onPress={handlePickImage}
              loading={isLoadingCamera}
            >
              Selecionar da Galeria
            </Button>
          </View>
        </Card>

        {/* Location Section */}
        <Card variant="elevated" padding="lg" style={{ marginBottom: 20 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            📍 Localização
          </Text>
          <Button
            variant="manus"
            size="md"
            onPress={handleGetLocation}
            loading={isLoadingLocation}
          >
            Obter Localização Atual
          </Button>
        </Card>

        {/* Notifications Section */}
        <Card variant="elevated" padding="lg" style={{ marginBottom: 20 }}>
          <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
            🔔 Notificações
          </Text>
          <View style={{ gap: 12 }}>
            <Button
              variant="manus"
              size="md"
              onPress={handleTestNotification}
            >
              Enviar Notificação de Teste
            </Button>
            <Button
              variant="outline"
              size="md"
              onPress={handleScheduleNotification}
            >
              Agendar Notificação
            </Button>
          </View>
        </Card>

        {/* Results */}
        {renderLocationInfo()}
        {renderImageInfo()}

        {/* Info */}
        <Card variant="default" padding="md">
          <Text variant="body" color="secondary" style={{ textAlign: 'center' }}>
            💡 Dica: Teste todas as funcionalidades para verificar se estão funcionando corretamente no seu dispositivo.
          </Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
};