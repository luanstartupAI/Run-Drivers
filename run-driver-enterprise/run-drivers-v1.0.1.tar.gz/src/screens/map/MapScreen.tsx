import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapViewComponent from '../../components/molecules/MapView';
import { Button, Text, Card } from '../../components/atoms';
import { colors } from '../../constants/tokens';
import { locationService, Position } from '../../services/locationService';

export const MapScreen: React.FC = () => {
  const [currentLocation, setCurrentLocation] = useState<Position | null>(null);
  const [useAppleMaps, setUseAppleMaps] = useState(false);
  const [markers, setMarkers] = useState<Array<{
    id: string;
    coordinate: {
      latitude: number;
      longitude: number;
    };
    title: string;
    description: string;
    color: string;
  }>>([]);

  useEffect(() => {
    loadMapData();
  }, []);

  const loadMapData = async () => {
    try {
      // Obter localização atual
      const hasPermission = await locationService.requestPermission();
      if (hasPermission) {
        const position = await locationService.getCurrentLocation();
        setCurrentLocation(position);
        
        // Adicionar marcador da localização atual
        setMarkers([
          {
            id: 'current-location',
            coordinate: {
              latitude: position.latitude,
              longitude: position.longitude,
            },
            title: 'Sua Localização',
            description: 'Você está aqui',
            color: colors.primary[500],
          },
          // Marcadores de exemplo
          {
            id: 'destination-1',
            coordinate: {
              latitude: position.latitude + 0.01,
              longitude: position.longitude + 0.01,
            },
            title: 'Destino 1',
            description: 'Rua das Flores, 123',
            color: colors.success[500],
          },
          {
            id: 'destination-2',
            coordinate: {
              latitude: position.latitude - 0.01,
              longitude: position.longitude - 0.01,
            },
            title: 'Destino 2',
            description: 'Avenida Principal, 456',
            color: colors.blue[500],
          },
        ]);
      }
    } catch (error) {
      console.error('Erro ao carregar dados do mapa:', error);
      Alert.alert('Erro', 'Não foi possível carregar os dados do mapa.');
    }
  };

  const handleMarkerPress = (markerId: string) => {
    const marker = markers.find(m => m.id === markerId);
    if (marker) {
      Alert.alert(
        marker.title,
        marker.description,
        [{ text: 'OK' }]
      );
    }
  };

  const addRandomMarker = () => {
    if (currentLocation) {
      const newMarker = {
        id: `marker-${Date.now()}`,
        coordinate: {
          latitude: currentLocation.latitude + (Math.random() - 0.5) * 0.02,
          longitude: currentLocation.longitude + (Math.random() - 0.5) * 0.02,
        },
        title: `Marcador ${markers.length + 1}`,
        description: 'Marcador adicionado dinamicamente',
        color: colors.warning[500],
      };
      
      setMarkers([...markers, newMarker]);
    }
  };

  const clearMarkers = () => {
    setMarkers([]);
  };

  const toggleMapProvider = () => {
    setUseAppleMaps(!useAppleMaps);
  };

  const getMapProviderName = () => {
    if (Platform.OS === 'ios') {
      return useAppleMaps ? 'Apple Maps' : 'Google Maps';
    } else {
      return 'Google Maps';
    }
  };

  const getMapProviderIcon = () => {
    if (Platform.OS === 'ios') {
      return useAppleMaps ? '🍎' : '🗺️';
    } else {
      return '🗺️';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text variant="h3" color="primary">
          🗺️ Mapa Interativo
        </Text>
        <Text variant="body" color="neutral">
          Visualize sua localização e destinos
        </Text>
      </View>

      <View style={styles.mapContainer}>
        <MapViewComponent
          markers={markers}
          onMarkerPress={handleMarkerPress}
          showUserLocation={true}
          useAppleMaps={useAppleMaps}
          style={styles.map}
        />
      </View>

      <View style={styles.controls}>
        <Card variant="elevated" style={styles.controlCard}>
          <Text variant="h4" color="primary" style={styles.cardTitle}>
            Controles do Mapa
          </Text>
          
          {/* Seletor de Provider (apenas iOS) */}
          {Platform.OS === 'ios' && (
            <View style={styles.providerSelector}>
              <Button
                variant={useAppleMaps ? "manus" : "outline"}
                size="sm"
                onPress={toggleMapProvider}
                style={styles.providerButton}
              >
                {getMapProviderIcon()} {getMapProviderName()}
              </Button>
              <Text variant="caption" color="neutral" style={styles.providerInfo}>
                {useAppleMaps 
                  ? 'Apple Maps: Gratuito e nativo' 
                  : 'Google Maps: Mais recursos'
                }
              </Text>
            </View>
          )}
          
          <View style={styles.buttonRow}>
            <Button
              variant="manus"
              size="sm"
              onPress={addRandomMarker}
              style={styles.button}
            >
              ➕ Adicionar Marcador
            </Button>
            
            <Button
              variant="destructive"
              size="sm"
              onPress={clearMarkers}
              style={styles.button}
            >
              🗑️ Limpar Marcadores
            </Button>
          </View>
          
          <View style={styles.buttonRow}>
            <Button
              variant="outline"
              size="sm"
              onPress={loadMapData}
              style={styles.button}
            >
              🔄 Recarregar
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onPress={() => {
                if (currentLocation) {
                  Alert.alert(
                    'Sua Localização',
                    `Latitude: ${currentLocation.latitude.toFixed(6)}\nLongitude: ${currentLocation.longitude.toFixed(6)}`
                  );
                }
              }}
              style={styles.button}
            >
              📍 Minha Localização
            </Button>
          </View>
        </Card>

        {/* Informações sobre os providers */}
        <Card variant="outlined" style={styles.infoCard}>
          <Text variant="h4" color="primary" style={styles.cardTitle}>
            ℹ️ Sobre os Mapas
          </Text>
          
          {Platform.OS === 'ios' ? (
            <>
              <Text variant="body" color="neutral" style={styles.infoText}>
                <Text variant="body" color="primary" weight="bold">🍎 Apple Maps:</Text>
                {' '}Gratuito, nativo do iOS, melhor performance
              </Text>
              <Text variant="body" color="neutral" style={styles.infoText}>
                <Text variant="body" color="primary" weight="bold">🗺️ Google Maps:</Text>
                {' '}Mais recursos, dados mais completos
              </Text>
            </>
          ) : (
            <Text variant="body" color="neutral" style={styles.infoText}>
              <Text variant="body" color="primary" weight="bold">Android:</Text>
              {' '}Sempre usa Google Maps para melhor compatibilidade
            </Text>
          )}
        </Card>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral[50],
  },
  header: {
    padding: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral[200],
  },
  mapContainer: {
    flex: 1,
    margin: 16,
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: colors.neutral[900],
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  map: {
    flex: 1,
  },
  controls: {
    padding: 16,
  },
  controlCard: {
    padding: 16,
    marginBottom: 16,
  },
  cardTitle: {
    marginBottom: 12,
    textAlign: 'center',
  },
  providerSelector: {
    marginBottom: 16,
    alignItems: 'center',
  },
  providerButton: {
    marginBottom: 8,
  },
  providerInfo: {
    textAlign: 'center',
    fontStyle: 'italic',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  button: {
    flex: 1,
    marginHorizontal: 4,
  },
  infoCard: {
    padding: 16,
  },
  infoText: {
    marginBottom: 8,
    lineHeight: 20,
  },
});

export default MapScreen;