import React, { useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Text, Card, Input } from '../../components/atoms';
import { colors } from '../../constants/tokens';

interface Post {
  id: string;
  author: {
    name: string;
    avatar: string;
    level: string;
  };
  content: string;
  image?: string;
  likes: number;
  comments: number;
  createdAt: string;
  isLiked: boolean;
}

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  attendees: number;
  maxAttendees: number;
}

export const SocialScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'feed' | 'events' | 'groups'>('feed');
  const [newPost, setNewPost] = useState('');

  // Mock data
  const posts: Post[] = [
    {
      id: '1',
      author: {
        name: 'João Silva',
        avatar: '👨‍💼',
        level: 'Ouro',
      },
      content: 'Acabei de completar 50 viagens hoje! 🚗💪 Obrigado a todos os passageiros que confiaram em mim. #RunDriver #Sucesso',
      likes: 24,
      comments: 8,
      createdAt: '2024-08-05T15:30:00Z',
      isLiked: false,
    },
    {
      id: '2',
      author: {
        name: 'Maria Santos',
        avatar: '👩‍💼',
        level: 'Prata',
      },
      content: 'Dica do dia: Sempre mantenha o carro limpo e com água para os passageiros. Faz toda diferença na avaliação! 🧹💧',
      likes: 18,
      comments: 12,
      createdAt: '2024-08-05T14:15:00Z',
      isLiked: true,
    },
    {
      id: '3',
      author: {
        name: 'Carlos Oliveira',
        avatar: '👨‍💼',
        level: 'Bronze',
      },
      content: 'Primeira semana como motorista Run Driver! Já estou amando a experiência e conhecendo pessoas incríveis. 🚗❤️',
      likes: 31,
      comments: 15,
      createdAt: '2024-08-05T12:45:00Z',
      isLiked: false,
    },
  ];

  const events: Event[] = [
    {
      id: '1',
      title: 'Encontro de Motoristas',
      description: 'Venha conhecer outros motoristas e trocar experiências!',
      date: '2024-08-15T19:00:00Z',
      location: 'Shopping Center - 3º andar',
      attendees: 45,
      maxAttendees: 100,
    },
    {
      id: '2',
      title: 'Workshop de Segurança',
      description: 'Aprenda técnicas avançadas de direção defensiva',
      date: '2024-08-20T14:00:00Z',
      location: 'Centro de Treinamento',
      attendees: 28,
      maxAttendees: 50,
    },
  ];

  const tabs = [
    { id: 'feed', label: 'Feed', icon: '📱' },
    { id: 'events', label: 'Eventos', icon: '📅' },
    { id: 'groups', label: 'Grupos', icon: '👥' },
  ];

  const handleLike = (postId: string) => {
    Alert.alert('Curtir', 'Post curtido!');
  };

  const handleComment = (postId: string) => {
    Alert.alert('Comentar', 'Abrindo comentários...');
  };

  const handleShare = (postId: string) => {
    Alert.alert('Compartilhar', 'Compartilhando post...');
  };

  const handleCreatePost = () => {
    if (!newPost.trim()) {
      Alert.alert('Erro', 'Digite algo para postar');
      return;
    }
    Alert.alert('Sucesso', 'Post criado com sucesso!');
    setNewPost('');
  };

  const handleJoinEvent = (eventId: string) => {
    Alert.alert('Evento', 'Você foi inscrito no evento!');
  };

  const renderCreatePost = () => (
    <Card variant="default" padding="md" style={{ marginBottom: 20 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 12 }}>
        Criar Post
      </Text>
      <Input
        placeholder="Compartilhe sua experiência..."
        value={newPost}
        onChangeText={setNewPost}
        multiline
        numberOfLines={3}
        style={{ marginBottom: 12 }}
      />
      <Button
        variant="manus"
        size="sm"
        onPress={handleCreatePost}
        disabled={!newPost.trim()}
      >
        Publicar
      </Button>
    </Card>
  );

  const renderPost = (post: Post) => (
    <Card key={post.id} variant="default" padding="md" style={{ marginBottom: 16 }}>
      {/* Post Header */}
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
        <Text variant="h3" style={{ marginRight: 8 }}>
          {post.author.avatar}
        </Text>
        <View style={{ flex: 1 }}>
          <Text variant="body" weight="semibold">
            {post.author.name}
          </Text>
          <Text variant="caption" color="secondary">
            {post.author.level} • {new Date(post.createdAt).toLocaleDateString('pt-BR')}
          </Text>
        </View>
      </View>

      {/* Post Content */}
      <Text variant="body" style={{ marginBottom: 12 }}>
        {post.content}
      </Text>

      {/* Post Actions */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flexDirection: 'row', gap: 16 }}>
          <TouchableOpacity onPress={() => handleLike(post.id)}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text variant="body" style={{ marginRight: 4 }}>
                {post.isLiked ? '❤️' : '🤍'}
              </Text>
              <Text variant="caption" color="secondary">
                {post.likes}
              </Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => handleComment(post.id)}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text variant="body" style={{ marginRight: 4 }}>
                💬
              </Text>
              <Text variant="caption" color="secondary">
                {post.comments}
              </Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => handleShare(post.id)}>
            <Text variant="body">📤</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Card>
  );

  const renderEvent = (event: Event) => (
    <Card key={event.id} variant="default" padding="md" style={{ marginBottom: 16 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 8 }}>
        {event.title}
      </Text>
      <Text variant="body" color="secondary" style={{ marginBottom: 12 }}>
        {event.description}
      </Text>
      
      <View style={{ marginBottom: 12 }}>
        <Text variant="caption" color="secondary">
          📅 {new Date(event.date).toLocaleDateString('pt-BR')}
        </Text>
        <Text variant="caption" color="secondary">
          📍 {event.location}
        </Text>
        <Text variant="caption" color="secondary">
          👥 {event.attendees}/{event.maxAttendees} participantes
        </Text>
      </View>

      <Button
        variant="outline"
        size="sm"
        onPress={() => handleJoinEvent(event.id)}
      >
        Participar
      </Button>
    </Card>
  );

  const renderGroups = () => (
    <View style={{ marginBottom: 20 }}>
      <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
        Grupos da Comunidade
      </Text>
      
      <View style={{ gap: 12 }}>
        <Card variant="default" padding="md">
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text variant="h3" style={{ marginRight: 12 }}>
              🚗
            </Text>
            <View style={{ flex: 1 }}>
              <Text variant="body" weight="semibold">
                Motoristas da Zona Sul
              </Text>
              <Text variant="caption" color="secondary">
                156 membros • 12 posts hoje
              </Text>
            </View>
            <Button variant="manus" size="sm">
              Entrar
            </Button>
          </View>
        </Card>

        <Card variant="default" padding="md">
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text variant="h3" style={{ marginRight: 12 }}>
              💰
            </Text>
            <View style={{ flex: 1 }}>
              <Text variant="body" weight="semibold">
                Dicas de Lucro
              </Text>
              <Text variant="caption" color="secondary">
                89 membros • 5 posts hoje
              </Text>
            </View>
            <Button variant="manus" size="sm">
              Entrar
            </Button>
          </View>
        </Card>

        <Card variant="default" padding="md">
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text variant="h3" style={{ marginRight: 12 }}>
              🏆
            </Text>
            <View style={{ flex: 1 }}>
              <Text variant="body" weight="semibold">
                Motoristas Premium
              </Text>
              <Text variant="caption" color="secondary">
                45 membros • 3 posts hoje
              </Text>
            </View>
            <Button variant="outline" size="sm">
              Ver
            </Button>
          </View>
        </Card>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.neutral[50] }}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
        {/* Header */}
        <View style={{ marginBottom: 24 }}>
          <Text variant="h2" weight="bold" color="primary">
            Comunidade
          </Text>
          <Text variant="body" color="secondary">
            Conecte-se com outros motoristas
          </Text>
        </View>

        {/* Tabs */}
        <View style={{ flexDirection: 'row', marginBottom: 20, backgroundColor: colors.neutral[100], borderRadius: 8, padding: 4 }}>
          {tabs.map((tab) => (
            <TouchableOpacity
              key={tab.id}
              style={{
                flex: 1,
                paddingVertical: 8,
                paddingHorizontal: 12,
                borderRadius: 6,
                backgroundColor: activeTab === tab.id ? colors.primary[500] : 'transparent',
                alignItems: 'center',
              }}
              onPress={() => setActiveTab(tab.id as any)}
            >
              <Text
                variant="body"
                weight="medium"
                style={{
                  color: activeTab === tab.id ? 'white' : colors.neutral[600],
                }}
              >
                {tab.icon} {tab.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Content based on active tab */}
        {activeTab === 'feed' && (
          <>
            {renderCreatePost()}
            {posts.map(renderPost)}
          </>
        )}

        {activeTab === 'events' && (
          <>
            <Text variant="h4" weight="semibold" style={{ marginBottom: 16 }}>
              Próximos Eventos
            </Text>
            {events.map(renderEvent)}
          </>
        )}

        {activeTab === 'groups' && (
          <>
            {renderGroups()}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};