import React, { useState, useEffect } from 'react';
import { View, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Input, Text, Card } from '../../components/atoms';
import { useAuthStore } from '../../stores/authStore';
import { biometricService } from '../../services/biometricService';
import { colors } from '../../constants/tokens';

export const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);
  const [biometricType, setBiometricType] = useState<string | null>(null);
  const [isBiometricEnabled, setIsBiometricEnabled] = useState(false);

  const { login, loginWithBiometric, enableBiometric, isLoading, error, clearError } = useAuthStore();

  useEffect(() => {
    checkBiometricSupport();
    checkBiometricStatus();
  }, []);

  const checkBiometricSupport = async () => {
    try {
      const support = await biometricService.checkDeviceSupport();
      setIsBiometricSupported(support.isSupported);
      setBiometricType(support.biometricType);
    } catch (error) {
      console.error('Erro ao verificar suporte à biometria:', error);
    }
  };

  const checkBiometricStatus = async () => {
    try {
      const enabled = await biometricService.isBiometricLoginEnabled();
      setIsBiometricEnabled(enabled);
    } catch (error) {
      console.error('Erro ao verificar status da biometria:', error);
    }
  };

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos');
      return;
    }

    clearError();
    const result = await login(email, password);

    if (result.success) {
      Alert.alert('Sucesso', 'Login realizado com sucesso!');
    } else {
      Alert.alert('Erro', result.error || 'Erro ao fazer login');
    }
  };

  const handleBiometricLogin = async () => {
    clearError();
    const result = await loginWithBiometric();

    if (result.success) {
      Alert.alert('Sucesso', 'Login biométrico realizado com sucesso!');
    } else {
      Alert.alert('Erro', result.error || 'Erro no login biométrico');
    }
  };

  const handleEnableBiometric = async () => {
    if (!email || !password) {
      Alert.alert('Erro', 'Por favor, faça login primeiro para ativar a biometria');
      return;
    }

    const result = await enableBiometric(email, password);

    if (result.success) {
      setIsBiometricEnabled(true);
      Alert.alert('Sucesso', 'Login biométrico ativado com sucesso!');
    } else {
      Alert.alert('Erro', result.error || 'Erro ao ativar biometria');
    }
  };

  const getBiometricTypeName = (type: string | null): string => {
    if (!type) return 'Biometria';
    
    switch (type) {
      case 'TouchID':
        return 'Touch ID';
      case 'FaceID':
        return 'Face ID';
      case 'Biometrics':
        return 'Biometria';
      default:
        return 'Biometria';
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.neutral[50] }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={{
            flexGrow: 1,
            justifyContent: 'center',
            padding: 20,
          }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={{ alignItems: 'center', marginBottom: 40 }}>
            <Text variant="h1" color="primary" style={{ marginBottom: 8 }}>
              🚗 Run Driver
            </Text>
            <Text variant="body" color="neutral" style={{ textAlign: 'center' }}>
              Faça login para acessar sua conta
            </Text>
          </View>

          <Card variant="elevated" style={{ padding: 20, marginBottom: 20 }}>
            <Text variant="h3" color="primary" style={{ marginBottom: 20, textAlign: 'center' }}>
              Login
            </Text>

            <Input
              label="Email"
              placeholder="seu@email.com"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              style={{ marginBottom: 16 }}
            />

            <Input
              label="Senha"
              placeholder="Sua senha"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              style={{ marginBottom: 20 }}
            />

            {error && (
              <Text variant="caption" color="error" style={{ marginBottom: 16, textAlign: 'center' }}>
                {error}
              </Text>
            )}

            <Button
              variant="manus"
              size="lg"
              onPress={handleLogin}
              loading={isLoading}
              style={{ marginBottom: 12 }}
            >
              {isLoading ? 'Entrando...' : 'Entrar'}
            </Button>

            {/* Login Biométrico */}
            {isBiometricSupported && (
              <View style={{ marginTop: 16 }}>
                {isBiometricEnabled ? (
                  <Button
                    variant="outline"
                    size="md"
                    onPress={handleBiometricLogin}
                    style={{ marginBottom: 8 }}
                  >
                    🔐 Login com {getBiometricTypeName(biometricType)}
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    size="md"
                    onPress={handleEnableBiometric}
                    style={{ marginBottom: 8 }}
                  >
                    🔐 Ativar {getBiometricTypeName(biometricType)}
                  </Button>
                )}
              </View>
            )}
          </Card>

          {/* Informações de Demo */}
          <Card variant="outlined" style={{ padding: 16 }}>
            <Text variant="h4" color="primary" style={{ marginBottom: 8 }}>
              💡 Credenciais de Demo
            </Text>
            <Text variant="body" color="neutral" style={{ marginBottom: 4 }}>
              Email: motorista@exemplo.com
            </Text>
            <Text variant="body" color="neutral">
              Senha: 123456
            </Text>
          </Card>

          {/* Status da Biometria */}
          {isBiometricSupported && (
            <Card variant="outlined" style={{ padding: 16, marginTop: 16 }}>
              <Text variant="h4" color="primary" style={{ marginBottom: 8 }}>
                🔐 Status da Biometria
              </Text>
              <Text variant="body" color="neutral" style={{ marginBottom: 4 }}>
                Tipo: {getBiometricTypeName(biometricType)}
              </Text>
              <Text variant="body" color="neutral">
                Status: {isBiometricEnabled ? '✅ Ativado' : '❌ Desativado'}
              </Text>
            </Card>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default LoginScreen;