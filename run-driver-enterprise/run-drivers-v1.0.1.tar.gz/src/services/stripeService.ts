import { Alert } from 'react-native';
import { initStripe, createToken, createPaymentMethod } from '@stripe/stripe-react-native';
import { paymentService } from './apiService';
import { getEnvironmentConfig } from '../constants/keys';

// Configuração do Stripe com chaves reais
const config = getEnvironmentConfig();
const STRIPE_PUBLISHABLE_KEY = config.stripeKey; // Chave real do Stripe
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || 'YOUR_STRIPE_SECRET_KEY'; // Configure via .env

export interface PaymentMethod {
  id: string;
  type: 'card' | 'bank_account';
  card?: {
    brand: string;
    last4: string;
    expMonth: number;
    expYear: number;
  };
  bankAccount?: {
    bankName: string;
    last4: string;
    routingNumber: string;
  };
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'requires_payment_method' | 'requires_confirmation' | 'requires_action' | 'processing' | 'requires_capture' | 'canceled' | 'succeeded';
  clientSecret: string;
}

export interface PaymentResult {
  success: boolean;
  paymentIntentId?: string;
  error?: string;
}

class StripeService {
  private isInitialized = false;

  async initialize() {
    if (this.isInitialized) return;

    try {
      await initStripe({
        publishableKey: STRIPE_PUBLISHABLE_KEY,
        merchantIdentifier: 'merchant.com.run.driver', // Para Apple Pay
      });
      
      this.isInitialized = true;
      console.log('✅ Stripe inicializado com sucesso');
    } catch (error) {
      console.error('❌ Erro ao inicializar Stripe:', error);
      throw error;
    }
  }

  async createPaymentMethod(cardDetails: {
    number: string;
    expMonth: number;
    expYear: number;
    cvc: string;
    name?: string;
  }): Promise<PaymentMethod | null> {
    try {
      await this.initialize();

      const { paymentMethod, error } = await createPaymentMethod({
        type: 'Card',
        billingDetails: {
          name: cardDetails.name || 'Motorista',
        },
      });

      if (error) {
        console.error('Erro ao criar método de pagamento:', error);
        Alert.alert('Erro', 'Não foi possível adicionar o cartão. Verifique os dados.');
        return null;
      }

      return {
        id: paymentMethod.id,
        type: 'card',
        card: {
          brand: paymentMethod.card?.brand || 'unknown',
          last4: paymentMethod.card?.last4 || '',
          expMonth: paymentMethod.card?.expMonth || 0,
          expYear: paymentMethod.card?.expYear || 0,
        },
      };
    } catch (error) {
      console.error('Erro ao criar método de pagamento:', error);
      Alert.alert('Erro', 'Não foi possível processar o pagamento.');
      return null;
    }
  }

  async processPayment(amount: number, currency: string = 'brl'): Promise<PaymentResult> {
    try {
      await this.initialize();

      // Criar Payment Intent no backend
      const response = await paymentService.createPaymentIntent({
        amount,
        currency,
        payment_method_types: ['card'],
      });

      if (!response.success) {
        return {
          success: false,
          error: response.error || 'Erro ao processar pagamento',
        };
      }

      return {
        success: true,
        paymentIntentId: response.paymentIntentId,
      };
    } catch (error: any) {
      console.error('Erro ao processar pagamento:', error);
      return {
        success: false,
        error: error.message || 'Erro ao processar pagamento',
      };
    }
  }

  async confirmPayment(paymentIntentId: string, paymentMethodId: string): Promise<PaymentResult> {
    try {
      await this.initialize();

      // Confirmar pagamento no backend
      const response = await paymentService.confirmPayment(paymentIntentId, paymentMethodId);

      if (!response.success) {
        return {
          success: false,
          error: response.error || 'Erro ao confirmar pagamento',
        };
      }

      return {
        success: true,
        paymentIntentId,
      };
    } catch (error: any) {
      console.error('Erro ao confirmar pagamento:', error);
      return {
        success: false,
        error: error.message || 'Erro ao confirmar pagamento',
      };
    }
  }

  async getPaymentMethods(): Promise<PaymentMethod[]> {
    try {
      const response = await paymentService.getPaymentMethods();
      return response.map((method: any) => ({
        id: method.id,
        type: method.type,
        card: method.card,
        bankAccount: method.bank_account,
      }));
    } catch (error) {
      console.error('Erro ao obter métodos de pagamento:', error);
      return [];
    }
  }

  async addPaymentMethod(paymentMethod: PaymentMethod): Promise<boolean> {
    try {
      await paymentService.addPaymentMethod(paymentMethod);
      return true;
    } catch (error) {
      console.error('Erro ao adicionar método de pagamento:', error);
      return false;
    }
  }

  async removePaymentMethod(paymentMethodId: string): Promise<boolean> {
    try {
      await paymentService.removePaymentMethod(paymentMethodId);
      return true;
    } catch (error) {
      console.error('Erro ao remover método de pagamento:', error);
      return false;
    }
  }

  // Validação de cartão
  validateCard(cardNumber: string, expMonth: number, expYear: number, cvc: string): {
    isValid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];

    // Validar número do cartão (Luhn algorithm)
    if (!this.isValidCardNumber(cardNumber)) {
      errors.push('Número do cartão inválido');
    }

    // Validar data de expiração
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;

    if (expYear < currentYear || (expYear === currentYear && expMonth < currentMonth)) {
      errors.push('Cartão expirado');
    }

    // Validar CVC
    if (cvc.length < 3 || cvc.length > 4) {
      errors.push('CVC inválido');
    }

    return {
      isValid: errors.length === 0,
      errors,
    };
  }

  private isValidCardNumber(cardNumber: string): boolean {
    // Remover espaços e hífens
    const cleanNumber = cardNumber.replace(/\s+/g, '').replace(/-/g, '');
    
    // Verificar se tem pelo menos 13 dígitos
    if (cleanNumber.length < 13) return false;

    // Algoritmo de Luhn
    let sum = 0;
    let isEven = false;

    for (let i = cleanNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cleanNumber.charAt(i));

      if (isEven) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }

      sum += digit;
      isEven = !isEven;
    }

    return sum % 10 === 0;
  }

  // Formatação de valores
  formatCurrency(amount: number, currency: string = 'BRL'): string {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency,
    }).format(amount / 100); // Stripe trabalha em centavos
  }

  // Máscara para número do cartão
  formatCardNumber(cardNumber: string): string {
    const cleanNumber = cardNumber.replace(/\s+/g, '').replace(/-/g, '');
    const groups = cleanNumber.match(/.{1,4}/g);
    return groups ? groups.join(' ') : cleanNumber;
  }

  // Máscara para data de expiração
  formatExpiryDate(month: string, year: string): string {
    const cleanMonth = month.replace(/\D/g, '');
    const cleanYear = year.replace(/\D/g, '');
    
    let formattedMonth = cleanMonth;
    if (cleanMonth.length > 0) {
      const monthNum = parseInt(cleanMonth);
      if (monthNum > 12) {
        formattedMonth = '12';
      }
    }
    
    return `${formattedMonth}/${cleanYear}`;
  }
}

export const stripeService = new StripeService();
export default stripeService;