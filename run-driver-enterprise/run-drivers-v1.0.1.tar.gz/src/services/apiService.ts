import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getEnvironmentConfig } from '../constants/keys';

// Configuração base da API
const config = getEnvironmentConfig();
const API_BASE_URL = config.apiUrl; // Usa URL de produção ou local baseado no ambiente

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token de autenticação
api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('auth-token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor para tratar respostas e erros
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Token expirado ou inválido
      await AsyncStorage.removeItem('auth-token');
      await AsyncStorage.removeItem('user-data');
      // Aqui você pode implementar navegação para login
    }
    return Promise.reject(error);
  }
);

// Tipos TypeScript
export interface User {
  id: string;
  email: string;
  name: string;
  type: 'driver' | 'passenger';
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Trip {
  id: string;
  origin: string;
  destination: string;
  price: number;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  createdAt: string;
  distance: string;
  duration: string;
  driver_id?: string;
  passenger_id?: string;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'withdrawal';
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

export interface Post {
  id: string;
  author: {
    name: string;
    avatar: string;
    level: string;
  };
  content: string;
  image?: string;
  likes: number;
  comments: number;
  createdAt: string;
  isLiked: boolean;
}

// Serviços de Autenticação
export const authService = {
  async login(email: string, password: string): Promise<{ token: string; user: User }> {
    const response = await api.post('/api/auth/login', { email, password });
    return response.data;
  },

  async register(userData: any): Promise<{ token: string; user: User }> {
    const response = await api.post('/api/auth/register', userData);
    return response.data;
  },

  async logout(): Promise<void> {
    await api.post('/api/auth/logout');
  },

  async verifyToken(): Promise<{ user: User }> {
    const response = await api.post('/api/auth/verify-token');
    return response.data;
  },

  async refreshToken(): Promise<{ token: string }> {
    const response = await api.post('/api/auth/refresh-token');
    return response.data;
  }
};

// Serviços de Motorista
export const driverService = {
  async getProfile(): Promise<any> {
    const response = await api.get('/api/drivers/profile');
    return response.data;
  },

  async updateProfile(profileData: any): Promise<any> {
    const response = await api.put('/api/drivers/profile', profileData);
    return response.data;
  },

  async updateLocation(lat: number, lng: number): Promise<any> {
    const response = await api.put('/api/drivers/location', { lat, lng });
    return response.data;
  },

  async updateStatus(status: string): Promise<any> {
    const response = await api.put('/api/drivers/status', { status });
    return response.data;
  },

  async getDashboard(): Promise<any> {
    const response = await api.get('/api/drivers/dashboard');
    return response.data;
  },

  async getNearbyDrivers(lat: number, lng: number, radius: number = 10): Promise<any> {
    const response = await api.get('/api/drivers/nearby', {
      params: { lat, lng, radius }
    });
    return response.data;
  }
};

// Serviços de Viagens
export const tripService = {
  async getTrips(page: number = 1, perPage: number = 10, status?: string): Promise<{ trips: Trip[]; pagination: any }> {
    const params: any = { page, per_page: perPage };
    if (status) params.status = status;
    
    const response = await api.get('/api/trips', { params });
    return response.data;
  },

  async getTrip(tripId: string): Promise<Trip> {
    const response = await api.get(`/api/trips/${tripId}`);
    return response.data;
  },

  async createTrip(tripData: any): Promise<Trip> {
    const response = await api.post('/api/trips', tripData);
    return response.data;
  },

  async acceptTrip(tripId: string): Promise<any> {
    const response = await api.post(`/api/trips/${tripId}/accept`);
    return response.data;
  },

  async startTrip(tripId: string): Promise<any> {
    const response = await api.post(`/api/trips/${tripId}/start`);
    return response.data;
  },

  async completeTrip(tripId: string): Promise<any> {
    const response = await api.post(`/api/trips/${tripId}/complete`);
    return response.data;
  },

  async cancelTrip(tripId: string): Promise<any> {
    const response = await api.post(`/api/trips/${tripId}/cancel`);
    return response.data;
  },

  async rateTrip(tripId: string, rating: number, comment: string = ''): Promise<any> {
    const response = await api.post(`/api/trips/${tripId}/rate`, { rating, comment });
    return response.data;
  },

  async getAvailableTrips(radius: number = 10): Promise<Trip[]> {
    const response = await api.get('/api/trips/available', {
      params: { radius }
    });
    return response.data;
  }
};

// Serviços de Pagamentos
export const paymentService = {
  async getWallet(): Promise<any> {
    const response = await api.get('/api/payments/wallet');
    return response.data;
  },

  async requestWithdrawal(amount: number, paymentMethod: string): Promise<any> {
    const response = await api.post('/api/payments/withdraw', { amount, payment_method: paymentMethod });
    return response.data;
  },

  async getTransactions(page: number = 1, perPage: number = 20, type?: string): Promise<{ transactions: Transaction[]; pagination: any }> {
    const params: any = { page, per_page: perPage };
    if (type) params.type = type;
    
    const response = await api.get('/api/payments/transactions', { params });
    return response.data;
  },

  async getPaymentMethods(): Promise<any[]> {
    const response = await api.get('/api/payments/methods');
    return response.data;
  },

  async addPaymentMethod(methodData: any): Promise<any> {
    const response = await api.post('/api/payments/methods', methodData);
    return response.data;
  },

  async getEarningsSummary(): Promise<any> {
    const response = await api.get('/api/payments/earnings');
    return response.data;
  }
};

// Serviços de Social
export const socialService = {
  async getFeed(page: number = 1, perPage: number = 10): Promise<{ posts: Post[]; pagination: any }> {
    const response = await api.get('/api/social/feed', {
      params: { page, per_page: perPage }
    });
    return response.data;
  },

  async createPost(content: string, imageUrl?: string, location?: any): Promise<Post> {
    const postData: any = { content };
    if (imageUrl) postData.image_url = imageUrl;
    if (location) postData.location = location;
    
    const response = await api.post('/api/social/posts', postData);
    return response.data;
  },

  async likePost(postId: string): Promise<any> {
    const response = await api.post(`/api/social/posts/${postId}/like`);
    return response.data;
  },

  async getComments(postId: string): Promise<any[]> {
    const response = await api.get(`/api/social/posts/${postId}/comments`);
    return response.data;
  },

  async createComment(postId: string, content: string): Promise<any> {
    const response = await api.post(`/api/social/posts/${postId}/comments`, { content });
    return response.data;
  },

  async deletePost(postId: string): Promise<void> {
    await api.delete(`/api/social/posts/${postId}`);
  },

  async getTrending(): Promise<any[]> {
    const response = await api.get('/api/social/trending');
    return response.data;
  }
};

// Serviços de Documentos
export const documentService = {
  async getDocuments(): Promise<any[]> {
    const response = await api.get('/api/documents');
    return response.data;
  },

  async uploadDocument(type: string, file: any): Promise<any> {
    const formData = new FormData();
    formData.append('type', type);
    formData.append('file', file);
    
    const response = await api.post('/api/documents/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  async deleteDocument(documentId: string): Promise<void> {
    await api.delete(`/api/documents/${documentId}`);
  }
};

// Serviços de Gamificação
export const gamificationService = {
  async getAchievements(): Promise<any[]> {
    const response = await api.get('/api/gamification/achievements');
    return response.data;
  },

  async getLeaderboard(period: string = 'week', limit: number = 10): Promise<any[]> {
    const response = await api.get('/api/gamification/leaderboard', {
      params: { period, limit }
    });
    return response.data;
  },

  async getChallenges(): Promise<any[]> {
    const response = await api.get('/api/gamification/challenges');
    return response.data;
  }
};

// Serviços de IA
export const aiService = {
  async sendChatbotMessage(message: string): Promise<any> {
    const response = await api.post('/api/ai/chatbot', { message });
    return response.data;
  },

  async getRecommendations(): Promise<any> {
    const response = await api.get('/api/ai/recommendations');
    return response.data;
  },

  async optimizeTripMatching(tripId: string): Promise<any> {
    const response = await api.post(`/api/ai/optimize`, { trip_id: tripId });
    return response.data;
  },

  async predictDemand(lat: number, lng: number, hours: number = 2): Promise<any> {
    const response = await api.get('/api/ai/predict-demand', {
      params: { lat, lng, hours }
    });
    return response.data;
  }
};

// Utilitários
export const apiUtils = {
  async setAuthToken(token: string): Promise<void> {
    await AsyncStorage.setItem('auth-token', token);
  },

  async getAuthToken(): Promise<string | null> {
    return await AsyncStorage.getItem('auth-token');
  },

  async removeAuthToken(): Promise<void> {
    await AsyncStorage.removeItem('auth-token');
  },

  async setUserData(user: User): Promise<void> {
    await AsyncStorage.setItem('user-data', JSON.stringify(user));
  },

  async getUserData(): Promise<User | null> {
    const data = await AsyncStorage.getItem('user-data');
    return data ? JSON.parse(data) : null;
  },

  async removeUserData(): Promise<void> {
    await AsyncStorage.removeItem('user-data');
  }
};

// Exportar todos os serviços
export {
  authService,
  driverService,
  tripService,
  paymentService,
  socialService,
  documentService,
  gamificationService,
  aiService,
  apiUtils
};

export default {
  authService,
  driverService,
  tripService,
  paymentService,
  socialService,
  documentService,
  gamificationService,
  aiService,
  apiUtils
};