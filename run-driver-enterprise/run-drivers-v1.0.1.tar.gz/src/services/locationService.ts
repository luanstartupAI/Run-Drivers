import { Platform, PermissionsAndroid, Alert } from 'react-native';
import Geolocation from 'react-native-geolocation-service';

export interface Position {
  coords: {
    latitude: number;
    longitude: number;
    accuracy: number;
    altitude: number | null;
    heading: number | null;
    speed: number | null;
  };
  timestamp: number;
}

export interface LocationPermission {
  granted: boolean;
  message?: string;
}

class LocationService {
  private watchId: number | null = null;

  /**
   * Solicita permissão de localização
   */
  async requestLocationPermission(): Promise<LocationPermission> {
    try {
      if (Platform.OS === 'ios') {
        const auth = await Geolocation.requestAuthorization('whenInUse');
        return {
          granted: auth === 'granted',
          message: auth === 'granted' ? undefined : 'Permissão de localização negada',
        };
      }

      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Permissão de Localização',
            message: 'O Run Driver precisa acessar sua localização para funcionar corretamente.',
            buttonNeutral: 'Perguntar depois',
            buttonNegative: 'Cancelar',
            buttonPositive: 'OK',
          }
        );

        return {
          granted: granted === PermissionsAndroid.RESULTS.GRANTED,
          message: granted === PermissionsAndroid.RESULTS.GRANTED 
            ? undefined 
            : 'Permissão de localização negada',
        };
      }

      return { granted: false, message: 'Plataforma não suportada' };
    } catch (error) {
      console.error('Erro ao solicitar permissão de localização:', error);
      return { granted: false, message: 'Erro ao solicitar permissão' };
    }
  }

  /**
   * Obtém a localização atual
   */
  getCurrentLocation(): Promise<Position> {
    return new Promise((resolve, reject) => {
      Geolocation.getCurrentPosition(
        (position) => resolve(position),
        (error) => {
          console.error('Erro ao obter localização:', error);
          reject(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 10000,
        }
      );
    });
  }

  /**
   * Inicia o monitoramento de localização
   */
  startLocationTracking(
    onLocationUpdate: (position: Position) => void,
    onError?: (error: any) => void
  ): number {
    this.stopLocationTracking(); // Para qualquer tracking anterior

    this.watchId = Geolocation.watchPosition(
      onLocationUpdate,
      (error) => {
        console.error('Erro no tracking de localização:', error);
        onError?.(error);
      },
      {
        enableHighAccuracy: true,
        distanceFilter: 10, // Atualizar a cada 10 metros
        interval: 5000, // A cada 5 segundos
        fastestInterval: 2000, // Mínimo 2 segundos
      }
    );

    return this.watchId;
  }

  /**
   * Para o monitoramento de localização
   */
  stopLocationTracking(): void {
    if (this.watchId !== null) {
      Geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
  }

  /**
   * Calcula a distância entre duas coordenadas (fórmula de Haversine)
   */
  calculateDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number {
    const R = 6371; // Raio da Terra em km
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) *
        Math.cos(this.deg2rad(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distância em km
    return distance;
  }

  /**
   * Converte graus para radianos
   */
  private deg2rad(deg: number): number {
    return deg * (Math.PI / 180);
  }

  /**
   * Verifica se a localização está dentro de uma área específica
   */
  isLocationInArea(
    userLat: number,
    userLon: number,
    centerLat: number,
    centerLon: number,
    radiusKm: number
  ): boolean {
    const distance = this.calculateDistance(userLat, userLon, centerLat, centerLon);
    return distance <= radiusKm;
  }

  /**
   * Formata a distância para exibição
   */
  formatDistance(distanceKm: number): string {
    if (distanceKm < 1) {
      return `${Math.round(distanceKm * 1000)}m`;
    }
    return `${distanceKm.toFixed(1)}km`;
  }

  /**
   * Formata a velocidade para exibição
   */
  formatSpeed(speedMs: number): string {
    const speedKmh = speedMs * 3.6; // Converter m/s para km/h
    return `${Math.round(speedKmh)} km/h`;
  }
}

export const locationService = new LocationService();
export default locationService;