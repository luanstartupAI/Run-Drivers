import PushNotification from 'react-native-push-notification';
import { Platform, Alert } from 'react-native';

export interface NotificationData {
  id: string;
  title: string;
  message: string;
  data?: any;
  date?: Date;
}

export interface NotificationPermission {
  granted: boolean;
  message?: string;
}

class NotificationService {
  private isConfigured = false;

  /**
   * Configura o serviço de notificações
   */
  configure(): void {
    if (this.isConfigured) return;

    PushNotification.configure({
      onRegister: function (token) {
        console.log('TOKEN:', token);
        // Aqui você pode enviar o token para o servidor
      },

      onNotification: function (notification) {
        console.log('NOTIFICATION:', notification);
        
        // Processar a notificação recebida
        if (notification.userInteraction) {
          // Usuário tocou na notificação
          this.handleNotificationTap(notification);
        }
      },

      permissions: {
        alert: true,
        badge: true,
        sound: true,
      },

      popInitialNotification: true,
      requestPermissions: true,
    });

    // Configurar canais para Android
    if (Platform.OS === 'android') {
      this.createNotificationChannels();
    }

    this.isConfigured = true;
  }

  /**
   * Cria canais de notificação para Android
   */
  private createNotificationChannels(): void {
    // Canal para viagens
    PushNotification.createChannel(
      {
        channelId: 'trips',
        channelName: 'Viagens',
        channelDescription: 'Notificações sobre viagens',
        playSound: true,
        soundName: 'default',
        importance: 4, // IMPORTANCE_HIGH
        vibrate: true,
      },
      (created) => console.log(`Canal de viagens criado: ${created}`)
    );

    // Canal para pagamentos
    PushNotification.createChannel(
      {
        channelId: 'payments',
        channelName: 'Pagamentos',
        channelDescription: 'Notificações sobre pagamentos',
        playSound: true,
        soundName: 'default',
        importance: 3, // IMPORTANCE_DEFAULT
        vibrate: true,
      },
      (created) => console.log(`Canal de pagamentos criado: ${created}`)
    );

    // Canal para comunidade
    PushNotification.createChannel(
      {
        channelId: 'community',
        channelName: 'Comunidade',
        channelDescription: 'Notificações da comunidade',
        playSound: true,
        soundName: 'default',
        importance: 2, // IMPORTANCE_LOW
        vibrate: false,
      },
      (created) => console.log(`Canal da comunidade criado: ${created}`)
    );
  }

  /**
   * Solicita permissão para notificações
   */
  async requestPermission(): Promise<NotificationPermission> {
    try {
      const permissions = await PushNotification.requestPermissions();
      
      return {
        granted: permissions.alert || false,
        message: permissions.alert ? undefined : 'Permissão de notificação negada',
      };
    } catch (error) {
      console.error('Erro ao solicitar permissão de notificação:', error);
      return { granted: false, message: 'Erro ao solicitar permissão' };
    }
  }

  /**
   * Envia notificação local imediata
   */
  sendLocalNotification(notification: NotificationData): void {
    PushNotification.localNotification({
      channelId: 'trips', // Canal padrão
      title: notification.title,
      message: notification.message,
      playSound: true,
      soundName: 'default',
      importance: 'high',
      priority: 'high',
      vibrate: true,
      vibration: 300,
      data: notification.data,
    });
  }

  /**
   * Agenda uma notificação local
   */
  scheduleLocalNotification(notification: NotificationData): void {
    if (!notification.date) {
      console.error('Data é obrigatória para agendar notificação');
      return;
    }

    PushNotification.localNotificationSchedule({
      channelId: 'trips',
      title: notification.title,
      message: notification.message,
      date: notification.date,
      playSound: true,
      soundName: 'default',
      importance: 'high',
      priority: 'high',
      vibrate: true,
      vibration: 300,
      data: notification.data,
    });
  }

  /**
   * Notifica sobre nova viagem disponível
   */
  notifyNewTrip(tripData: any): void {
    this.sendLocalNotification({
      id: `trip_${tripData.id}`,
      title: 'Nova Viagem Disponível! 🚗',
      message: `Viagem para ${tripData.destination} - R$ ${tripData.price}`,
      data: tripData,
    });
  }

  /**
   * Notifica sobre pagamento recebido
   */
  notifyPaymentReceived(paymentData: any): void {
    this.sendLocalNotification({
      id: `payment_${paymentData.id}`,
      title: 'Pagamento Recebido! 💰',
      message: `Você recebeu R$ ${paymentData.amount} pela viagem`,
      data: paymentData,
    });
  }

  /**
   * Notifica sobre evento da comunidade
   */
  notifyCommunityEvent(eventData: any): void {
    this.sendLocalNotification({
      id: `event_${eventData.id}`,
      title: 'Novo Evento! 📅',
      message: `${eventData.title} - ${eventData.location}`,
      data: eventData,
    });
  }

  /**
   * Notifica sobre saque processado
   */
  notifyWithdrawalProcessed(withdrawalData: any): void {
    this.sendLocalNotification({
      id: `withdrawal_${withdrawalData.id}`,
      title: 'Saque Processado! 💳',
      message: `R$ ${withdrawalData.amount} foi enviado para sua conta`,
      data: withdrawalData,
    });
  }

  /**
   * Agenda lembretes de viagem
   */
  scheduleTripReminder(tripData: any, reminderTime: Date): void {
    this.scheduleLocalNotification({
      id: `reminder_${tripData.id}`,
      title: 'Lembrete de Viagem ⏰',
      message: `Sua viagem para ${tripData.destination} começa em 15 minutos`,
      date: reminderTime,
      data: tripData,
    });
  }

  /**
   * Agenda notificação de meta diária
   */
  scheduleDailyGoalReminder(): void {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(8, 0, 0, 0); // 8:00 AM

    this.scheduleLocalNotification({
      id: 'daily_goal_reminder',
      title: 'Meta Diária! 🎯',
      message: 'Que tal bater sua meta de hoje? Comece suas viagens!',
      date: tomorrow,
    });
  }

  /**
   * Cancela uma notificação específica
   */
  cancelNotification(notificationId: string): void {
    PushNotification.cancelLocalNotification(notificationId);
  }

  /**
   * Cancela todas as notificações
   */
  cancelAllNotifications(): void {
    PushNotification.cancelAllLocalNotifications();
  }

  /**
   * Obtém notificações agendadas
   */
  getScheduledNotifications(): Promise<any[]> {
    return new Promise((resolve) => {
      PushNotification.getScheduledLocalNotifications((notifications) => {
        resolve(notifications);
      });
    });
  }

  /**
   * Obtém notificações entregues
   */
  getDeliveredNotifications(): Promise<any[]> {
    return new Promise((resolve) => {
      PushNotification.getDeliveredNotifications((notifications) => {
        resolve(notifications);
      });
    });
  }

  /**
   * Remove notificações entregues
   */
  removeDeliveredNotifications(notificationIds?: string[]): void {
    if (notificationIds) {
      PushNotification.removeDeliveredNotifications(notificationIds);
    } else {
      PushNotification.removeAllDeliveredNotifications();
    }
  }

  /**
   * Processa toque em notificação
   */
  private handleNotificationTap(notification: any): void {
    // Aqui você pode implementar a navegação baseada no tipo de notificação
    const data = notification.data;
    
    if (data?.type === 'trip') {
      // Navegar para tela de viagens
      console.log('Navegando para viagem:', data);
    } else if (data?.type === 'payment') {
      // Navegar para tela de carteira
      console.log('Navegando para pagamento:', data);
    } else if (data?.type === 'event') {
      // Navegar para tela de comunidade
      console.log('Navegando para evento:', data);
    }
  }

  /**
   * Configura badge do app
   */
  setBadgeNumber(count: number): void {
    PushNotification.setApplicationIconBadgeNumber(count);
  }

  /**
   * Remove badge do app
   */
  clearBadge(): void {
    PushNotification.setApplicationIconBadgeNumber(0);
  }
}

export const notificationService = new NotificationService();
export default notificationService;