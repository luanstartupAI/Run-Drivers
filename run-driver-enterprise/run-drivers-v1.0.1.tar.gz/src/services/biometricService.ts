import { Alert } from 'react-native';
import ReactNativeBiometrics, { BiometryTypes } from 'react-native-biometrics';
import AsyncStorage from '@react-native-async-storage/async-storage';

const rnBiometrics = new ReactNativeBiometrics();

export interface BiometricResult {
  success: boolean;
  error?: string;
  biometricType?: string;
}

export interface BiometricConfig {
  allowDeviceCredentials: boolean;
  title: string;
  subtitle: string;
  cancelButtonText: string;
}

class BiometricService {
  private isAvailable = false;
  private biometricType: string | null = null;

  async initialize(): Promise<BiometricResult> {
    try {
      const { available, biometryType } = await rnBiometrics.isSensorAvailable();
      
      this.isAvailable = available;
      this.biometricType = biometryType;
      
      if (available) {
        console.log('✅ Biometria disponível:', biometryType);
        return {
          success: true,
          biometricType: biometryType,
        };
      } else {
        console.log('❌ Biometria não disponível');
        return {
          success: false,
          error: 'Biometria não disponível neste dispositivo',
        };
      }
    } catch (error) {
      console.error('❌ Erro ao inicializar biometria:', error);
      return {
        success: false,
        error: 'Erro ao inicializar biometria',
      };
    }
  }

  async isBiometricAvailable(): Promise<boolean> {
    if (!this.isAvailable) {
      await this.initialize();
    }
    return this.isAvailable;
  }

  async getBiometricType(): Promise<string | null> {
    if (!this.biometricType) {
      await this.initialize();
    }
    return this.biometricType;
  }

  async authenticate(config?: Partial<BiometricConfig>): Promise<BiometricResult> {
    try {
      const isAvailable = await this.isBiometricAvailable();
      
      if (!isAvailable) {
        return {
          success: false,
          error: 'Biometria não disponível',
        };
      }

      const defaultConfig: BiometricConfig = {
        allowDeviceCredentials: true,
        title: 'Autenticação Biométrica',
        subtitle: 'Use sua biometria para acessar o app',
        cancelButtonText: 'Cancelar',
      };

      const finalConfig = { ...defaultConfig, ...config };

      const { success, error } = await rnBiometrics.simplePrompt({
        promptMessage: finalConfig.title,
        cancelButtonText: finalConfig.cancelButtonText,
        fallbackPromptMessage: 'Use sua senha',
      });

      if (success) {
        console.log('✅ Autenticação biométrica bem-sucedida');
        return {
          success: true,
          biometricType: this.biometricType || 'unknown',
        };
      } else {
        console.log('❌ Autenticação biométrica falhou:', error);
        return {
          success: false,
          error: error || 'Autenticação cancelada',
        };
      }
    } catch (error: any) {
      console.error('❌ Erro na autenticação biométrica:', error);
      return {
        success: false,
        error: error.message || 'Erro na autenticação biométrica',
      };
    }
  }

  async loginWithBiometric(): Promise<BiometricResult> {
    const result = await this.authenticate({
      title: 'Login Biométrico',
      subtitle: 'Use sua biometria para fazer login',
      cancelButtonText: 'Usar Senha',
    });

    if (result.success) {
      // Buscar credenciais salvas
      const savedCredentials = await this.getSavedCredentials();
      if (savedCredentials) {
        // Aqui você pode integrar com o authStore para fazer login automático
        console.log('✅ Login biométrico bem-sucedido');
      }
    }

    return result;
  }

  async enableBiometricLogin(email: string, password: string): Promise<BiometricResult> {
    try {
      // Primeiro, autenticar com biometria para confirmar identidade
      const authResult = await this.authenticate({
        title: 'Ativar Login Biométrico',
        subtitle: 'Confirme sua identidade para ativar o login biométrico',
        cancelButtonText: 'Cancelar',
      });

      if (!authResult.success) {
        return authResult;
      }

      // Salvar credenciais de forma segura
      await this.saveCredentials(email, password);

      console.log('✅ Login biométrico ativado');
      return {
        success: true,
        biometricType: this.biometricType || 'unknown',
      };
    } catch (error: any) {
      console.error('❌ Erro ao ativar login biométrico:', error);
      return {
        success: false,
        error: error.message || 'Erro ao ativar login biométrico',
      };
    }
  }

  async disableBiometricLogin(): Promise<BiometricResult> {
    try {
      // Confirmar com biometria antes de desativar
      const authResult = await this.authenticate({
        title: 'Desativar Login Biométrico',
        subtitle: 'Confirme sua identidade para desativar o login biométrico',
        cancelButtonText: 'Cancelar',
      });

      if (!authResult.success) {
        return authResult;
      }

      // Remover credenciais salvas
      await this.removeSavedCredentials();

      console.log('✅ Login biométrico desativado');
      return {
        success: true,
        biometricType: this.biometricType || 'unknown',
      };
    } catch (error: any) {
      console.error('❌ Erro ao desativar login biométrico:', error);
      return {
        success: false,
        error: error.message || 'Erro ao desativar login biométrico',
      };
    }
  }

  async isBiometricLoginEnabled(): Promise<boolean> {
    try {
      const savedCredentials = await this.getSavedCredentials();
      return !!savedCredentials;
    } catch (error) {
      console.error('❌ Erro ao verificar login biométrico:', error);
      return false;
    }
  }

  private async saveCredentials(email: string, password: string): Promise<void> {
    try {
      // Em produção, você deve criptografar essas credenciais
      const credentials = {
        email,
        password,
        timestamp: Date.now(),
      };

      await AsyncStorage.setItem('biometric_credentials', JSON.stringify(credentials));
    } catch (error) {
      console.error('❌ Erro ao salvar credenciais:', error);
      throw error;
    }
  }

  private async getSavedCredentials(): Promise<{ email: string; password: string } | null> {
    try {
      const saved = await AsyncStorage.getItem('biometric_credentials');
      if (saved) {
        const credentials = JSON.parse(saved);
        
        // Verificar se as credenciais não expiraram (30 dias)
        const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
        if (credentials.timestamp < thirtyDaysAgo) {
          await this.removeSavedCredentials();
          return null;
        }
        
        return {
          email: credentials.email,
          password: credentials.password,
        };
      }
      return null;
    } catch (error) {
      console.error('❌ Erro ao obter credenciais salvas:', error);
      return null;
    }
  }

  private async removeSavedCredentials(): Promise<void> {
    try {
      await AsyncStorage.removeItem('biometric_credentials');
    } catch (error) {
      console.error('❌ Erro ao remover credenciais:', error);
      throw error;
    }
  }

  // Método para obter credenciais salvas (usado pelo authStore)
  async getCredentialsForLogin(): Promise<{ email: string; password: string } | null> {
    const isEnabled = await this.isBiometricLoginEnabled();
    
    if (!isEnabled) {
      return null;
    }

    const authResult = await this.authenticate({
      title: 'Login Biométrico',
      subtitle: 'Use sua biometria para fazer login',
      cancelButtonText: 'Usar Senha',
    });

    if (authResult.success) {
      return await this.getSavedCredentials();
    }

    return null;
  }

  // Verificar se o dispositivo suporta biometria
  async checkDeviceSupport(): Promise<{
    isSupported: boolean;
    biometricType: string | null;
    error?: string;
  }> {
    try {
      const { available, biometryType } = await rnBiometrics.isSensorAvailable();
      
      return {
        isSupported: available,
        biometricType: biometryType,
      };
    } catch (error: any) {
      return {
        isSupported: false,
        biometricType: null,
        error: error.message || 'Erro ao verificar suporte à biometria',
      };
    }
  }

  // Obter informações sobre o tipo de biometria
  getBiometricTypeName(type: string): string {
    switch (type) {
      case BiometryTypes.TouchID:
        return 'Touch ID';
      case BiometryTypes.FaceID:
        return 'Face ID';
      case BiometryTypes.Biometrics:
        return 'Biometria';
      default:
        return 'Biometria';
    }
  }
}

export const biometricService = new BiometricService();
export default biometricService;