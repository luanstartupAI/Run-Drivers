import { Platform, Alert, PermissionsAndroid } from 'react-native';
import { launchCamera, launchImageLibrary, ImagePickerResponse } from 'react-native-image-picker';

export interface ImageAsset {
  uri: string;
  type?: string;
  fileName?: string;
  fileSize?: number;
  width?: number;
  height?: number;
}

export interface CameraPermission {
  granted: boolean;
  message?: string;
}

class CameraService {
  /**
   * Solicita permissão de câmera
   */
  async requestCameraPermission(): Promise<CameraPermission> {
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA,
          {
            title: 'Permissão de Câmera',
            message: 'O Run Driver precisa acessar sua câmera para fotografar documentos.',
            buttonNeutral: 'Perguntar depois',
            buttonNegative: 'Cancelar',
            buttonPositive: 'OK',
          }
        );

        return {
          granted: granted === PermissionsAndroid.RESULTS.GRANTED,
          message: granted === PermissionsAndroid.RESULTS.GRANTED 
            ? undefined 
            : 'Permissão de câmera negada',
        };
      }

      // iOS não precisa de permissão explícita para câmera
      return { granted: true };
    } catch (error) {
      console.error('Erro ao solicitar permissão de câmera:', error);
      return { granted: false, message: 'Erro ao solicitar permissão' };
    }
  }

  /**
   * Tira uma foto usando a câmera
   */
  async takePhoto(): Promise<ImageAsset | null> {
    try {
      const permission = await this.requestCameraPermission();
      if (!permission.granted) {
        Alert.alert('Permissão Negada', permission.message || 'Permissão de câmera é necessária');
        return null;
      }

      const result: ImagePickerResponse = await launchCamera({
        mediaType: 'photo',
        quality: 0.8,
        includeBase64: false,
        saveToPhotos: false,
        cameraType: 'back',
        maxWidth: 1920,
        maxHeight: 1080,
      });

      if (result.didCancel) {
        return null;
      }

      if (result.errorCode) {
        Alert.alert('Erro', `Erro ao tirar foto: ${result.errorMessage}`);
        return null;
      }

      if (result.assets && result.assets.length > 0) {
        const asset = result.assets[0];
        return {
          uri: asset.uri || '',
          type: asset.type,
          fileName: asset.fileName,
          fileSize: asset.fileSize,
          width: asset.width,
          height: asset.height,
        };
      }

      return null;
    } catch (error) {
      console.error('Erro ao tirar foto:', error);
      Alert.alert('Erro', 'Erro ao acessar a câmera');
      return null;
    }
  }

  /**
   * Seleciona uma imagem da galeria
   */
  async pickImage(): Promise<ImageAsset | null> {
    try {
      const result: ImagePickerResponse = await launchImageLibrary({
        mediaType: 'photo',
        quality: 0.8,
        includeBase64: false,
        maxWidth: 1920,
        maxHeight: 1080,
      });

      if (result.didCancel) {
        return null;
      }

      if (result.errorCode) {
        Alert.alert('Erro', `Erro ao selecionar imagem: ${result.errorMessage}`);
        return null;
      }

      if (result.assets && result.assets.length > 0) {
        const asset = result.assets[0];
        return {
          uri: asset.uri || '',
          type: asset.type,
          fileName: asset.fileName,
          fileSize: asset.fileSize,
          width: asset.width,
          height: asset.height,
        };
      }

      return null;
    } catch (error) {
      console.error('Erro ao selecionar imagem:', error);
      Alert.alert('Erro', 'Erro ao acessar a galeria');
      return null;
    }
  }

  /**
   * Tira foto de um documento específico
   */
  async takeDocumentPhoto(documentType: 'cnh' | 'cpf' | 'vehicle'): Promise<ImageAsset | null> {
    try {
      const photo = await this.takePhoto();
      
      if (photo) {
        // Aqui você pode adicionar validações específicas para cada tipo de documento
        switch (documentType) {
          case 'cnh':
            if (photo.fileSize && photo.fileSize > 10 * 1024 * 1024) { // 10MB
              Alert.alert('Arquivo muito grande', 'A imagem deve ter menos de 10MB');
              return null;
            }
            break;
          case 'cpf':
            if (photo.fileSize && photo.fileSize > 5 * 1024 * 1024) { // 5MB
              Alert.alert('Arquivo muito grande', 'A imagem deve ter menos de 5MB');
              return null;
            }
            break;
          case 'vehicle':
            if (photo.fileSize && photo.fileSize > 15 * 1024 * 1024) { // 15MB
              Alert.alert('Arquivo muito grande', 'A imagem deve ter menos de 15MB');
              return null;
            }
            break;
        }

        return photo;
      }

      return null;
    } catch (error) {
      console.error('Erro ao tirar foto do documento:', error);
      return null;
    }
  }

  /**
   * Valida se a imagem é adequada para upload
   */
  validateImage(image: ImageAsset): { valid: boolean; message?: string } {
    if (!image.uri) {
      return { valid: false, message: 'URI da imagem não encontrada' };
    }

    if (image.fileSize && image.fileSize > 20 * 1024 * 1024) { // 20MB
      return { valid: false, message: 'Arquivo muito grande (máximo 20MB)' };
    }

    if (image.width && image.width < 200) {
      return { valid: false, message: 'Imagem muito pequena (mínimo 200px de largura)' };
    }

    if (image.height && image.height < 200) {
      return { valid: false, message: 'Imagem muito pequena (mínimo 200px de altura)' };
    }

    return { valid: true };
  }

  /**
   * Formata o tamanho do arquivo para exibição
   */
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Obtém as dimensões da imagem
   */
  getImageDimensions(image: ImageAsset): string {
    if (image.width && image.height) {
      return `${image.width}x${image.height}`;
    }
    return 'Dimensões desconhecidas';
  }
}

export const cameraService = new CameraService();
export default cameraService;