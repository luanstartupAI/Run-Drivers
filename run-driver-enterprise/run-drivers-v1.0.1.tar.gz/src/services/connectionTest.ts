import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

export const testBackendConnection = async () => {
  try {
    console.log('🔍 Testando conexão com backend...');
    
    // Teste 1: Health check
    const healthResponse = await axios.get(`${API_BASE_URL}/health`);
    console.log('✅ Health check:', healthResponse.data);
    
    // Teste 2: Root endpoint
    const rootResponse = await axios.get(`${API_BASE_URL}/`);
    console.log('✅ Root endpoint:', rootResponse.data);
    
    // Teste 3: Endpoints disponíveis
    const endpointsResponse = await axios.get(`${API_BASE_URL}/`);
    console.log('✅ Endpoints disponíveis:', endpointsResponse.data.endpoints);
    
    return {
      success: true,
      message: 'Backend conectado com sucesso!',
      data: {
        health: healthResponse.data,
        root: rootResponse.data,
        endpoints: endpointsResponse.data.endpoints
      }
    };
  } catch (error: any) {
    console.error('❌ Erro ao conectar com backend:', error.message);
    return {
      success: false,
      message: 'Erro ao conectar com backend',
      error: error.message
    };
  }
};

export const testAuthEndpoints = async () => {
  try {
    console.log('🔐 Testando endpoints de autenticação...');
    
    // Teste de registro (sem dados válidos, só para verificar se o endpoint responde)
    try {
      await axios.post(`${API_BASE_URL}/api/auth/register`, {
        email: 'test@example.com',
        password: 'test123',
        name: 'Test User',
        phone: '123456789',
        type: 'driver'
      });
    } catch (error: any) {
      if (error.response?.status === 409) {
        console.log('✅ Endpoint de registro responde (usuário já existe)');
      } else {
        console.log('✅ Endpoint de registro responde');
      }
    }
    
    return {
      success: true,
      message: 'Endpoints de autenticação funcionando!'
    };
  } catch (error: any) {
    console.error('❌ Erro nos endpoints de autenticação:', error.message);
    return {
      success: false,
      message: 'Erro nos endpoints de autenticação',
      error: error.message
    };
  }
};