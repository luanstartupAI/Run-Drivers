import { Alert } from 'react-native';
import { GOOGLE_MAPS_CONFIG, MapsUtils } from '../constants/maps';

// Interfaces TypeScript
export interface GeocodingResult {
  place_id: string;
  formatted_address: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  types: string[];
}

export interface DirectionsResult {
  routes: Array<{
    legs: Array<{
      distance: { text: string; value: number };
      duration: { text: string; value: number };
      start_address: string;
      end_address: string;
      steps: Array<{
        distance: { text: string; value: number };
        duration: { text: string; value: number };
        instruction: string;
        polyline: { points: string };
      }>;
    }>;
    overview_polyline: { points: string };
  }>;
  status: string;
}

export interface PlaceResult {
  place_id: string;
  name: string;
  formatted_address: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  types: string[];
  rating?: number;
  photos?: Array<{
    photo_reference: string;
    width: number;
    height: number;
  }>;
}

export interface TrafficInfo {
  level: 'FLUID' | 'SLOW' | 'HEAVY';
  color: string;
  description: string;
}

class GoogleMapsService {
  private apiKey: string;
  private baseUrl = 'https://maps.googleapis.com/maps/api';

  constructor() {
    this.apiKey = GOOGLE_MAPS_CONFIG.API_KEY;
  }

  // Configurar API key
  setApiKey(apiKey: string) {
    this.apiKey = apiKey;
  }

  // Geocodificação: Endereço → Coordenadas
  async geocode(address: string, region: string = 'BR'): Promise<GeocodingResult[]> {
    try {
      const url = `${this.baseUrl}/geocode/json?address=${encodeURIComponent(address)}&region=${region}&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data.results;
      } else {
        throw new Error(`Geocoding failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro na geocodificação:', error);
      throw error;
    }
  }

  // Geocodificação reversa: Coordenadas → Endereço
  async reverseGeocode(latitude: number, longitude: number): Promise<GeocodingResult[]> {
    try {
      const url = `${this.baseUrl}/geocode/json?latlng=${latitude},${longitude}&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data.results;
      } else {
        throw new Error(`Reverse geocoding failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro na geocodificação reversa:', error);
      throw error;
    }
  }

  // Obter direções entre dois pontos
  async getDirections(
    origin: string | { lat: number; lng: number },
    destination: string | { lat: number; lng: number },
    mode: string = 'driving',
    avoid: string[] = [],
    units: string = 'metric'
  ): Promise<DirectionsResult> {
    try {
      const originStr = typeof origin === 'string' ? origin : `${origin.lat},${origin.lng}`;
      const destStr = typeof destination === 'string' ? destination : `${destination.lat},${destination.lng}`;
      
      const avoidStr = avoid.length > 0 ? `&avoid=${avoid.join('|')}` : '';
      const url = `${this.baseUrl}/directions/json?origin=${encodeURIComponent(originStr)}&destination=${encodeURIComponent(destStr)}&mode=${mode}&units=${units}${avoidStr}&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data;
      } else {
        throw new Error(`Directions failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro ao obter direções:', error);
      throw error;
    }
  }

  // Buscar lugares próximos
  async searchNearbyPlaces(
    latitude: number,
    longitude: number,
    radius: number = 5000,
    type?: string,
    keyword?: string
  ): Promise<PlaceResult[]> {
    try {
      const typeParam = type ? `&type=${type}` : '';
      const keywordParam = keyword ? `&keyword=${encodeURIComponent(keyword)}` : '';
      
      const url = `${this.baseUrl}/place/nearbysearch/json?location=${latitude},${longitude}&radius=${radius}${typeParam}${keywordParam}&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data.results;
      } else {
        throw new Error(`Nearby search failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro na busca de lugares:', error);
      throw error;
    }
  }

  // Buscar lugares por texto
  async searchPlaces(
    query: string,
    location?: { lat: number; lng: number },
    radius?: number
  ): Promise<PlaceResult[]> {
    try {
      const locationParam = location ? `&location=${location.lat},${location.lng}` : '';
      const radiusParam = radius ? `&radius=${radius}` : '';
      
      const url = `${this.baseUrl}/place/textsearch/json?query=${encodeURIComponent(query)}${locationParam}${radiusParam}&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data.results;
      } else {
        throw new Error(`Place search failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro na busca de lugares:', error);
      throw error;
    }
  }

  // Obter detalhes de um lugar
  async getPlaceDetails(placeId: string): Promise<any> {
    try {
      const url = `${this.baseUrl}/place/details/json?place_id=${placeId}&fields=name,formatted_address,geometry,types,rating,photos,opening_hours,price_level,website,formatted_phone_number&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data.result;
      } else {
        throw new Error(`Place details failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro ao obter detalhes do lugar:', error);
      throw error;
    }
  }

  // Obter informações de tráfego (simulado - Google não fornece API pública)
  async getTrafficInfo(latitude: number, longitude: number): Promise<TrafficInfo> {
    try {
      // Simulação de dados de tráfego
      const trafficLevels = ['FLUID', 'SLOW', 'HEAVY'];
      const randomLevel = trafficLevels[Math.floor(Math.random() * trafficLevels.length)] as 'FLUID' | 'SLOW' | 'HEAVY';
      
      const trafficInfo: TrafficInfo = {
        level: randomLevel,
        color: GOOGLE_MAPS_CONFIG.TRAFFIC_CONFIG.COLORS[randomLevel],
        description: this.getTrafficDescription(randomLevel),
      };

      return trafficInfo;
    } catch (error) {
      console.error('Erro ao obter informações de tráfego:', error);
      throw error;
    }
  }

  // Obter rota otimizada para múltiplos destinos
  async getOptimizedRoute(
    origin: { lat: number; lng: number },
    destinations: Array<{ lat: number; lng: number }>,
    mode: string = 'driving'
  ): Promise<DirectionsResult> {
    try {
      const waypoints = destinations.map(dest => `${dest.lat},${dest.lng}`).join('|');
      const originStr = `${origin.lat},${origin.lng}`;
      const destinationStr = `${destinations[0].lat},${destinations[0].lng}`;
      
      const url = `${this.baseUrl}/directions/json?origin=${originStr}&destination=${destinationStr}&waypoints=optimize:true|${waypoints}&mode=${mode}&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data;
      } else {
        throw new Error(`Optimized route failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro ao obter rota otimizada:', error);
      throw error;
    }
  }

  // Calcular distância e duração entre pontos
  async getDistanceMatrix(
    origins: Array<{ lat: number; lng: number } | string>,
    destinations: Array<{ lat: number; lng: number } | string>,
    mode: string = 'driving'
  ): Promise<any> {
    try {
      const originsStr = origins.map(origin => 
        typeof origin === 'string' ? origin : `${origin.lat},${origin.lng}`
      ).join('|');
      
      const destinationsStr = destinations.map(dest => 
        typeof dest === 'string' ? dest : `${dest.lat},${dest.lng}`
      ).join('|');
      
      const url = `${this.baseUrl}/distancematrix/json?origins=${encodeURIComponent(originsStr)}&destinations=${encodeURIComponent(destinationsStr)}&mode=${mode}&key=${this.apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        return data;
      } else {
        throw new Error(`Distance matrix failed: ${data.status}`);
      }
    } catch (error) {
      console.error('Erro ao calcular matriz de distâncias:', error);
      throw error;
    }
  }

  // Utilitários
  private getTrafficDescription(level: string): string {
    switch (level) {
      case 'FLUID':
        return 'Tráfego fluido';
      case 'SLOW':
        return 'Tráfego lento';
      case 'HEAVY':
        return 'Tráfego pesado';
      default:
        return 'Informação não disponível';
    }
  }

  // Validar se a API key está configurada
  isApiKeyConfigured(): boolean {
    return this.apiKey !== 'YOUR_GOOGLE_MAPS_API_KEY' && this.apiKey.length > 0;
  }

  // Testar conectividade com Google Maps
  async testConnection(): Promise<boolean> {
    try {
      if (!this.isApiKeyConfigured()) {
        throw new Error('API key não configurada');
      }

      // Teste simples de geocodificação
      const results = await this.geocode('São Paulo, Brasil');
      return results.length > 0;
    } catch (error) {
      console.error('Erro no teste de conectividade:', error);
      return false;
    }
  }
}

export const googleMapsService = new GoogleMapsService();
export default googleMapsService;