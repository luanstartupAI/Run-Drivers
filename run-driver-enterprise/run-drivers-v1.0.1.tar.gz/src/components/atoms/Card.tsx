import React from 'react';
import { View, ViewStyle } from 'react-native';
import { colors } from '../../constants/tokens';

interface CardProps {
  children: React.ReactNode;
  variant?: 'default' | 'elevated' | 'outlined';
  padding?: 'sm' | 'md' | 'lg' | 'xl';
  style?: ViewStyle;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'default',
  padding = 'md',
  style,
}) => {
  const baseStyle: ViewStyle = {
    borderRadius: 12,
    backgroundColor: 'white',
  };

  const variantStyles = {
    default: {
      borderWidth: 1,
      borderColor: colors.neutral[200],
    },
    elevated: {
      shadowColor: colors.neutral[900],
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.1,
      shadowRadius: 8,
      elevation: 4,
    },
    outlined: {
      borderWidth: 2,
      borderColor: colors.primary[500],
    },
  };

  const paddingStyles = {
    sm: { padding: 12 },
    md: { padding: 16 },
    lg: { padding: 20 },
    xl: { padding: 24 },
  };

  return (
    <View
      style={[
        baseStyle,
        variantStyles[variant],
        paddingStyles[padding],
        style,
      ]}
    >
      {children}
    </View>
  );
};