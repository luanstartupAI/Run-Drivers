import React from 'react';
import { TouchableOpacity, Text, ActivityIndicator, ViewStyle, TextStyle } from 'react-native';
import { colors } from '../../constants/tokens';

interface ButtonProps {
  variant?: 'manus' | 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  loading?: boolean;
  disabled?: boolean;
  onPress?: () => void;
  children: React.ReactNode;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

const getButtonStyle = (variant: string, size: string, disabled: boolean): ViewStyle => {
  const baseStyle: ViewStyle = {
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    opacity: disabled ? 0.5 : 1,
  };

  // Size styles
  const sizeStyles = {
    sm: { paddingHorizontal: 12, paddingVertical: 6, minHeight: 32 },
    md: { paddingHorizontal: 16, paddingVertical: 8, minHeight: 40 },
    lg: { paddingHorizontal: 20, paddingVertical: 10, minHeight: 48 },
    xl: { paddingHorizontal: 24, paddingVertical: 12, minHeight: 56 },
  };

  // Variant styles
  const variantStyles = {
    manus: {
      backgroundColor: colors.primary[500],
      borderWidth: 0,
    },
    primary: {
      backgroundColor: colors.blue[500],
      borderWidth: 0,
    },
    secondary: {
      backgroundColor: colors.neutral[200],
      borderWidth: 0,
    },
    success: {
      backgroundColor: colors.success[500],
      borderWidth: 0,
    },
    warning: {
      backgroundColor: colors.warning[500],
      borderWidth: 0,
    },
    error: {
      backgroundColor: colors.error[500],
      borderWidth: 0,
    },
    outline: {
      backgroundColor: 'transparent',
      borderWidth: 1,
      borderColor: colors.primary[500],
    },
    ghost: {
      backgroundColor: 'transparent',
      borderWidth: 0,
    },
  };

  return {
    ...baseStyle,
    ...sizeStyles[size as keyof typeof sizeStyles],
    ...variantStyles[variant as keyof typeof variantStyles],
  };
};

const getTextStyle = (variant: string, size: string): TextStyle => {
  const baseTextStyle: TextStyle = {
    fontWeight: '600',
    textAlign: 'center',
  };

  // Size text styles
  const sizeTextStyles = {
    sm: { fontSize: 12 },
    md: { fontSize: 14 },
    lg: { fontSize: 16 },
    xl: { fontSize: 18 },
  };

  // Variant text styles
  const variantTextStyles = {
    manus: { color: 'white' },
    primary: { color: 'white' },
    secondary: { color: colors.neutral[800] },
    success: { color: 'white' },
    warning: { color: 'white' },
    error: { color: 'white' },
    outline: { color: colors.primary[500] },
    ghost: { color: colors.primary[500] },
  };

  return {
    ...baseTextStyle,
    ...sizeTextStyles[size as keyof typeof sizeTextStyles],
    ...variantTextStyles[variant as keyof typeof variantTextStyles],
  };
};

export const Button: React.FC<ButtonProps> = ({
  variant = 'manus',
  size = 'md',
  loading = false,
  disabled = false,
  onPress,
  children,
  style,
  textStyle,
}) => {
  const buttonStyle = getButtonStyle(variant, size, disabled);
  const textStyleFinal = getTextStyle(variant, size);

  return (
    <TouchableOpacity
      style={[buttonStyle, style]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading && (
        <ActivityIndicator
          size="small"
          color={variant === 'outline' || variant === 'ghost' ? colors.primary[500] : 'white'}
          style={{ marginRight: 8 }}
        />
      )}
      <Text style={[textStyleFinal, textStyle]}>{children}</Text>
    </TouchableOpacity>
  );
};