import React, { useState } from 'react';
import { View, TextInput, Text, ViewStyle, TextStyle } from 'react-native';
import { colors } from '../../constants/tokens';

interface InputProps {
  placeholder?: string;
  label?: string;
  error?: string;
  success?: string;
  disabled?: boolean;
  secureTextEntry?: boolean;
  value?: string;
  onChangeText?: (text: string) => void;
  style?: ViewStyle;
  inputStyle?: TextStyle;
  multiline?: boolean;
  numberOfLines?: number;
}

export const Input: React.FC<InputProps> = ({
  placeholder,
  label,
  error,
  success,
  disabled = false,
  secureTextEntry = false,
  value,
  onChangeText,
  style,
  inputStyle,
  multiline = false,
  numberOfLines = 1,
}) => {
  const [isFocused, setIsFocused] = useState(false);

  const containerStyle: ViewStyle = {
    marginBottom: 16,
  };

  const labelStyle: TextStyle = {
    fontSize: 14,
    fontWeight: '500',
    color: colors.neutral[700],
    marginBottom: 4,
  };

  const inputContainerStyle: ViewStyle = {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: disabled ? colors.neutral[100] : 'white',
    borderColor: error 
      ? colors.error[500] 
      : success 
      ? colors.success[500] 
      : isFocused 
      ? colors.primary[500] 
      : colors.neutral[300],
  };

  const inputTextStyle: TextStyle = {
    fontSize: 16,
    color: disabled ? colors.neutral[500] : colors.neutral[900],
    padding: 0,
    textAlignVertical: multiline ? 'top' : 'center',
  };

  const messageStyle: TextStyle = {
    fontSize: 12,
    marginTop: 4,
    fontWeight: '500',
  };

  const getMessageStyle = (): TextStyle => {
    if (error) {
      return { ...messageStyle, color: colors.error[500] };
    }
    if (success) {
      return { ...messageStyle, color: colors.success[500] };
    }
    return messageStyle;
  };

  return (
    <View style={[containerStyle, style]}>
      {label && <Text style={labelStyle}>{label}</Text>}
      
      <View style={inputContainerStyle}>
        <TextInput
          style={[inputTextStyle, inputStyle]}
          placeholder={placeholder}
          placeholderTextColor={colors.neutral[400]}
          value={value}
          onChangeText={onChangeText}
          secureTextEntry={secureTextEntry}
          editable={!disabled}
          multiline={multiline}
          numberOfLines={numberOfLines}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
        />
      </View>
      
      {(error || success) && (
        <Text style={getMessageStyle()}>
          {error || success}
        </Text>
      )}
    </View>
  );
};