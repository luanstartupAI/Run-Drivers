import React from 'react';
import { Text as RNText, TextStyle } from 'react-native';
import { colors } from '../../constants/tokens';

interface TextProps {
  variant?: 'h1' | 'h2' | 'h3' | 'h4' | 'body' | 'caption' | 'label';
  weight?: 'normal' | 'medium' | 'semibold' | 'bold';
  color?: 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'neutral';
  children: React.ReactNode;
  style?: TextStyle;
  numberOfLines?: number;
}

export const Text: React.FC<TextProps> = ({
  variant = 'body',
  weight = 'normal',
  color = 'neutral',
  children,
  style,
  numberOfLines,
}) => {
  const getVariantStyle = (): TextStyle => {
    const variantStyles = {
      h1: { fontSize: 32, lineHeight: 40 },
      h2: { fontSize: 28, lineHeight: 36 },
      h3: { fontSize: 24, lineHeight: 32 },
      h4: { fontSize: 20, lineHeight: 28 },
      body: { fontSize: 16, lineHeight: 24 },
      caption: { fontSize: 14, lineHeight: 20 },
      label: { fontSize: 12, lineHeight: 16 },
    };
    return variantStyles[variant];
  };

  const getWeightStyle = (): TextStyle => {
    const weightStyles = {
      normal: { fontWeight: '400' as const },
      medium: { fontWeight: '500' as const },
      semibold: { fontWeight: '600' as const },
      bold: { fontWeight: '700' as const },
    };
    return weightStyles[weight];
  };

  const getColorStyle = (): TextStyle => {
    const colorStyles = {
      primary: { color: colors.primary[500] },
      secondary: { color: colors.neutral[600] },
      success: { color: colors.success[500] },
      warning: { color: colors.warning[500] },
      error: { color: colors.error[500] },
      neutral: { color: colors.neutral[900] },
    };
    return colorStyles[color];
  };

  return (
    <RNText
      style={[
        getVariantStyle(),
        getWeightStyle(),
        getColorStyle(),
        style,
      ]}
      numberOfLines={numberOfLines}
    >
      {children}
    </RNText>
  );
};