import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, Alert, Platform } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE, Region, MapViewProps } from 'react-native-maps';
import { locationService, Position } from '../../services/locationService';
import { googleMapsService } from '../../services/googleMapsService';
import { GOOGLE_MAPS_CONFIG, MapsUtils } from '../../constants/maps';
import { colors } from '../../constants/tokens';
import { Text } from '../atoms';

interface MapViewComponentProps extends MapViewProps {
  initialRegion?: Region;
  markers?: Array<{
    id: string;
    coordinate: {
      latitude: number;
      longitude: number;
    };
    title?: string;
    description?: string;
    color?: string;
    type?: 'DRIVER' | 'PASSENGER' | 'DESTINATION' | 'PICKUP' | 'DROPOFF' | 'CURRENT_LOCATION';
  }>;
  polylines?: Array<{
    id: string;
    coordinates: Array<{
      latitude: number;
      longitude: number;
    }>;
    color?: string;
    width?: number;
    type?: 'ACTIVE_ROUTE' | 'ALTERNATIVE_ROUTE' | 'COMPLETED_ROUTE' | 'OPTIMIZED_ROUTE';
  }>;
  onMarkerPress?: (markerId: string) => void;
  onRegionChange?: (region: Region) => void;
  showUserLocation?: boolean;
  showTraffic?: boolean;
  mapStyle?: 'DEFAULT' | 'DARK' | 'MINIMAL';
  style?: any;
  enableDirections?: boolean;
  enableGeocoding?: boolean;
  enablePlaces?: boolean;
}

export const MapViewComponent: React.FC<MapViewComponentProps> = ({
  initialRegion,
  markers = [],
  polylines = [],
  onMarkerPress,
  onRegionChange,
  showUserLocation = true,
  showTraffic = false,
  mapStyle = 'DEFAULT',
  style,
  enableDirections = true,
  enableGeocoding = true,
  enablePlaces = true,
  ...mapViewProps
}) => {
  const [currentLocation, setCurrentLocation] = useState<Position | null>(null);
  const [region, setRegion] = useState<Region>(
    initialRegion || GOOGLE_MAPS_CONFIG.DEFAULT_REGION
  );
  const [isGoogleMapsConnected, setIsGoogleMapsConnected] = useState(false);
  const [trafficInfo, setTrafficInfo] = useState<any>(null);
  
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    initializeMap();
  }, []);

  useEffect(() => {
    if (showTraffic && currentLocation) {
      updateTrafficInfo();
    }
  }, [showTraffic, currentLocation]);

  const initializeMap = async () => {
    try {
      // Verificar conectividade com Google Maps
      const isConnected = await googleMapsService.testConnection();
      setIsGoogleMapsConnected(isConnected);
      
      if (!isConnected) {
        console.warn('⚠️ Google Maps API não configurada ou não conectada');
      }

      // Obter localização atual
      await getCurrentLocation();
    } catch (error) {
      console.error('Erro ao inicializar mapa:', error);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const hasPermission = await locationService.requestPermission();
      
      if (hasPermission) {
        const position = await locationService.getCurrentLocation();
        setCurrentLocation(position);
        
        // Atualizar região para a localização atual
        const newRegion: Region = {
          latitude: position.latitude,
          longitude: position.longitude,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        };
        
        setRegion(newRegion);
        
        // Animar para a localização atual
        mapRef.current?.animateToRegion(newRegion, 1000);
      } else {
        Alert.alert(
          'Permissão Negada',
          'É necessário permitir acesso à localização para usar o mapa.'
        );
      }
    } catch (error) {
      console.error('Erro ao obter localização:', error);
      Alert.alert('Erro', 'Não foi possível obter sua localização.');
    }
  };

  const updateTrafficInfo = async () => {
    if (!currentLocation) return;

    try {
      const traffic = await googleMapsService.getTrafficInfo(
        currentLocation.latitude,
        currentLocation.longitude
      );
      setTrafficInfo(traffic);
    } catch (error) {
      console.error('Erro ao obter informações de tráfego:', error);
    }
  };

  const handleMarkerPress = (markerId: string) => {
    if (onMarkerPress) {
      onMarkerPress(markerId);
    }
  };

  const handleRegionChange = (newRegion: Region) => {
    setRegion(newRegion);
    if (onRegionChange) {
      onRegionChange(newRegion);
    }
  };

  const animateToLocation = (coordinate: { latitude: number; longitude: number }) => {
    const newRegion: Region = {
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
      latitudeDelta: 0.0922,
      longitudeDelta: 0.0421,
    };
    
    mapRef.current?.animateToRegion(newRegion, 1000);
  };

  const animateToUserLocation = () => {
    if (currentLocation) {
      animateToLocation({
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
      });
    }
  };

  // Obter cor do marcador baseada no tipo
  const getMarkerColor = (marker: any): string => {
    if (marker.color) return marker.color;
    if (marker.type && GOOGLE_MAPS_CONFIG.MARKER_CONFIG.COLORS[marker.type]) {
      return GOOGLE_MAPS_CONFIG.MARKER_CONFIG.COLORS[marker.type];
    }
    return colors.primary[500];
  };

  // Obter cor da polyline baseada no tipo
  const getPolylineColor = (polyline: any): string => {
    if (polyline.color) return polyline.color;
    if (polyline.type && GOOGLE_MAPS_CONFIG.POLYLINE_CONFIG.COLORS[polyline.type]) {
      return GOOGLE_MAPS_CONFIG.POLYLINE_CONFIG.COLORS[polyline.type];
    }
    return colors.primary[500];
  };

  // Obter largura da polyline baseada no tipo
  const getPolylineWidth = (polyline: any): number => {
    if (polyline.width) return polyline.width;
    return GOOGLE_MAPS_CONFIG.POLYLINE_CONFIG.WIDTHS.NORMAL;
  };

  // Obter estilo do mapa
  const getMapStyle = () => {
    return GOOGLE_MAPS_CONFIG.MAP_STYLES[mapStyle] || [];
  };

  return (
    <View style={[styles.container, style]}>
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        region={region}
        onRegionChangeComplete={handleRegionChange}
        showsUserLocation={showUserLocation}
        showsMyLocationButton={true}
        showsCompass={true}
        showsScale={true}
        showsTraffic={showTraffic}
        showsBuildings={true}
        mapType="standard"
        loadingEnabled={true}
        loadingIndicatorColor={colors.primary[500]}
        loadingBackgroundColor={colors.neutral[50]}
        showsPointsOfInterest={true}
        showsIndoors={true}
        showsIndoorLevelPicker={Platform.OS === 'android'}
        customMapStyle={getMapStyle()}
        {...mapViewProps}
      >
        {/* Marcadores */}
        {markers.map((marker) => (
          <Marker
            key={marker.id}
            coordinate={marker.coordinate}
            title={marker.title}
            description={marker.description}
            pinColor={getMarkerColor(marker)}
            onPress={() => handleMarkerPress(marker.id)}
          />
        ))}
        
        {/* Linhas de rota */}
        {polylines.map((polyline) => (
          <Polyline
            key={polyline.id}
            coordinates={polyline.coordinates}
            strokeColor={getPolylineColor(polyline)}
            strokeWidth={getPolylineWidth(polyline)}
            lineDashPattern={[1]}
          />
        ))}
      </MapView>
      
      {/* Botão para centralizar na localização do usuário */}
      {currentLocation && (
        <View style={styles.centerButton}>
          <Text variant="caption" color="white">
            📍
          </Text>
        </View>
      )}

      {/* Indicador de status do Google Maps */}
      {!isGoogleMapsConnected && (
        <View style={styles.statusIndicator}>
          <Text variant="caption" color="warning">
            ⚠️ Google Maps não configurado
          </Text>
        </View>
      )}

      {/* Indicador de tráfego */}
      {showTraffic && trafficInfo && (
        <View style={[styles.trafficIndicator, { backgroundColor: trafficInfo.color }]}>
          <Text variant="caption" color="white">
            🚗 {trafficInfo.description}
          </Text>
        </View>
      )}

      {/* Controles de funcionalidades */}
      {(enableDirections || enableGeocoding || enablePlaces) && (
        <View style={styles.featureIndicator}>
          <Text variant="caption" color="neutral">
            {enableDirections && '🗺️'} {enableGeocoding && '📍'} {enablePlaces && '🏢'}
          </Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
  },
  map: {
    flex: 1,
  },
  centerButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: colors.primary[500],
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.neutral[900],
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  statusIndicator: {
    position: 'absolute',
    top: 20,
    left: 20,
    backgroundColor: colors.warning[100],
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.warning[500],
  },
  trafficIndicator: {
    position: 'absolute',
    top: 20,
    right: 20,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    shadowColor: colors.neutral[900],
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 3,
  },
  featureIndicator: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    backgroundColor: colors.white,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    shadowColor: colors.neutral[900],
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 3,
  },
});

export default MapViewComponent;