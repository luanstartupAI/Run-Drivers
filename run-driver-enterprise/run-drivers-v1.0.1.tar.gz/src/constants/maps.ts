// Configurações do Google Maps para React Native
export const GOOGLE_MAPS_CONFIG = {
  // Chave principal do Google Maps
  API_KEY: 'YOUR_GOOGLE_MAPS_API_KEY', // ⚠️ Configure sua chave do Google Maps no Google Cloud Console
  
  // Configurações de região padrão (Brasil)
  DEFAULT_REGION: {
    latitude: -23.5505, // São Paulo
    longitude: -46.6333,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  },
  
  // Configurações de zoom
  ZOOM_LEVELS: {
    CITY: 10,
    NEIGHBORHOOD: 15,
    STREET: 18,
    BUILDING: 20,
  },
  
  // Configurações de estilo do mapa
  MAP_STYLES: {
    // Estilo padrão (sem customização)
    DEFAULT: [],
    
    // Estilo escuro para modo noturno
    DARK: [
      {
        elementType: 'geometry',
        stylers: [{ color: '#242f3e' }],
      },
      {
        elementType: 'labels.text.stroke',
        stylers: [{ color: '#242f3e' }],
      },
      {
        elementType: 'labels.text.fill',
        stylers: [{ color: '#746855' }],
      },
      {
        featureType: 'administrative.locality',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#d59563' }],
      },
      {
        featureType: 'poi',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#d59563' }],
      },
      {
        featureType: 'poi.park',
        elementType: 'geometry',
        stylers: [{ color: '#263c3f' }],
      },
      {
        featureType: 'poi.park',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#6b9a76' }],
      },
      {
        featureType: 'road',
        elementType: 'geometry',
        stylers: [{ color: '#38414e' }],
      },
      {
        featureType: 'road',
        elementType: 'geometry.stroke',
        stylers: [{ color: '#212a37' }],
      },
      {
        featureType: 'road',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#9ca5b3' }],
      },
      {
        featureType: 'road.highway',
        elementType: 'geometry',
        stylers: [{ color: '#746855' }],
      },
      {
        featureType: 'road.highway',
        elementType: 'geometry.stroke',
        stylers: [{ color: '#1f2835' }],
      },
      {
        featureType: 'road.highway',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#f3d19c' }],
      },
      {
        featureType: 'transit',
        elementType: 'geometry',
        stylers: [{ color: '#2f3948' }],
      },
      {
        featureType: 'transit.station',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#d59563' }],
      },
      {
        featureType: 'water',
        elementType: 'geometry',
        stylers: [{ color: '#17263c' }],
      },
      {
        featureType: 'water',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#515c6d' }],
      },
      {
        featureType: 'water',
        elementType: 'labels.text.stroke',
        stylers: [{ color: '#17263c' }],
      },
    ],
    
    // Estilo minimalista para foco no conteúdo
    MINIMAL: [
      {
        featureType: 'administrative',
        elementType: 'geometry',
        stylers: [{ visibility: 'simplified' }],
      },
      {
        featureType: 'landscape',
        elementType: 'geometry',
        stylers: [{ visibility: 'simplified' }],
      },
      {
        featureType: 'poi',
        stylers: [{ visibility: 'off' }],
      },
      {
        featureType: 'road',
        elementType: 'geometry',
        stylers: [{ visibility: 'simplified' }],
      },
      {
        featureType: 'transit',
        stylers: [{ visibility: 'off' }],
      },
      {
        featureType: 'water',
        elementType: 'geometry',
        stylers: [{ visibility: 'simplified' }],
      },
    ],
  },
  
  // Configurações de marcadores
  MARKER_CONFIG: {
    // Cores dos marcadores por tipo
    COLORS: {
      DRIVER: '#7CB342', // Verde MANUS
      PASSENGER: '#3B82F6', // Azul
      DESTINATION: '#10B981', // Verde sucesso
      PICKUP: '#F59E0B', // Amarelo
      DROPOFF: '#EF4444', // Vermelho
      CURRENT_LOCATION: '#7CB342', // Verde MANUS
    },
    
    // Tamanhos dos marcadores
    SIZES: {
      SMALL: 20,
      MEDIUM: 30,
      LARGE: 40,
    },
  },
  
  // Configurações de polylines (rotas)
  POLYLINE_CONFIG: {
    // Cores das rotas por tipo
    COLORS: {
      ACTIVE_ROUTE: '#7CB342', // Verde MANUS
      ALTERNATIVE_ROUTE: '#3B82F6', // Azul
      COMPLETED_ROUTE: '#6B7280', // Cinza
      OPTIMIZED_ROUTE: '#10B981', // Verde sucesso
    },
    
    // Larguras das linhas
    WIDTHS: {
      THIN: 2,
      NORMAL: 4,
      THICK: 6,
    },
  },
  
  // Configurações de geocodificação
  GEOCODING_CONFIG: {
    // Região padrão para busca (Brasil)
    DEFAULT_REGION: 'BR',
    
    // Tipos de resultado preferidos
    PREFERRED_TYPES: [
      'street_address',
      'route',
      'establishment',
      'point_of_interest',
    ],
    
    // Limite de resultados
    MAX_RESULTS: 5,
  },
  
  // Configurações de direções
  DIRECTIONS_CONFIG: {
    // Modos de transporte
    TRAVEL_MODES: {
      DRIVING: 'driving',
      WALKING: 'walking',
      BICYCLING: 'bicycling',
      TRANSIT: 'transit',
    },
    
    // Unidades de medida
    UNITS: {
      METRIC: 'metric',
      IMPERIAL: 'imperial',
    },
    
    // Evitar tipos de vias
    AVOID: {
      TOLLS: 'tolls',
      HIGHWAYS: 'highways',
      FERRIES: 'ferries',
      INDOOR: 'indoor',
    },
  },
  
  // Configurações de lugares
  PLACES_CONFIG: {
    // Tipos de lugares
    TYPES: {
      RESTAURANT: 'restaurant',
      GAS_STATION: 'gas_station',
      HOSPITAL: 'hospital',
      BANK: 'bank',
      SHOPPING_MALL: 'shopping_mall',
      AIRPORT: 'airport',
      TRAIN_STATION: 'train_station',
      BUS_STATION: 'bus_station',
    },
    
    // Raio de busca padrão (metros)
    DEFAULT_RADIUS: 5000,
    
    // Limite de resultados
    MAX_RESULTS: 20,
  },
  
  // Configurações de tráfego
  TRAFFIC_CONFIG: {
    // Atualização do tráfego (milissegundos)
    UPDATE_INTERVAL: 30000, // 30 segundos
    
    // Cores do tráfego
    COLORS: {
      FLUID: '#10B981', // Verde
      SLOW: '#F59E0B', // Amarelo
      HEAVY: '#EF4444', // Vermelho
    },
  },
};

// Funções utilitárias para Google Maps
export const MapsUtils = {
  // Calcular distância entre dois pontos
  calculateDistance: (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Raio da Terra em km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  },
  
  // Formatar distância
  formatDistance: (distance: number): string => {
    if (distance < 1) {
      return `${Math.round(distance * 1000)}m`;
    } else {
      return `${distance.toFixed(1)}km`;
    }
  },
  
  // Formatar duração
  formatDuration: (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}min`;
    } else {
      return `${minutes}min`;
    }
  },
  
  // Gerar região baseada em coordenadas
  createRegion: (latitude: number, longitude: number, delta: number = 0.01): any => {
    return {
      latitude,
      longitude,
      latitudeDelta: delta,
      longitudeDelta: delta,
    };
  },
  
  // Validar coordenadas
  isValidCoordinate: (latitude: number, longitude: number): boolean => {
    return latitude >= -90 && latitude <= 90 && 
           longitude >= -180 && longitude <= 180;
  },
  
  // Obter região central de múltiplas coordenadas
  getCenterRegion: (coordinates: Array<{latitude: number, longitude: number}>): any => {
    if (coordinates.length === 0) {
      return GOOGLE_MAPS_CONFIG.DEFAULT_REGION;
    }
    
    const lats = coordinates.map(c => c.latitude);
    const lons = coordinates.map(c => c.longitude);
    
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLon = Math.min(...lons);
    const maxLon = Math.max(...lons);
    
    const centerLat = (minLat + maxLat) / 2;
    const centerLon = (minLon + maxLon) / 2;
    const deltaLat = (maxLat - minLat) * 1.2; // 20% de margem
    const deltaLon = (maxLon - minLon) * 1.2;
    
    return {
      latitude: centerLat,
      longitude: centerLon,
      latitudeDelta: Math.max(deltaLat, 0.01),
      longitudeDelta: Math.max(deltaLon, 0.01),
    };
  },
};

export default GOOGLE_MAPS_CONFIG;