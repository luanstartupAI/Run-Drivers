import { extendTheme } from 'native-base';
import { colors } from './tokens';

export const theme = extendTheme({
  colors: {
    primary: colors.primary,
    neutral: colors.neutral,
    blue: colors.blue,
    success: colors.success,
    warning: colors.warning,
    error: colors.error,
  },
  config: {
    initialColorMode: 'light',
  },
});

export type CustomThemeType = typeof theme;
