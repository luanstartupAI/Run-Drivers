// 🔑 Configuração de Chaves - Run Driver Enterprise
// ⚠️ IMPORTANTE: Para produção, configure as chaves reais em variáveis de ambiente

export const PROJECT_KEYS = {
  // 📊 Supabase Configuration
  SUPABASE: {
    PROJECT_ID: process.env.SUPABASE_PROJECT_ID || 'jevaycxfcszepxuybxel',
    PROJECT_URL: process.env.SUPABASE_PROJECT_URL || 'https://jevaycxfcszepxuybxel.supabase.co',
    DATABASE_KEY: process.env.SUPABASE_DATABASE_KEY || 'YOUR_DATABASE_KEY',
    API_KEY_ANON: process.env.SUPABASE_API_KEY_ANON || 'YOUR_ANON_KEY',
    API_KEY_SERVICE: process.env.SUPABASE_API_KEY_SERVICE || 'YOUR_SERVICE_KEY',
    JWT_SECRET: process.env.SUPABASE_JWT_SECRET || 'YOUR_JWT_SECRET',
    S3_ENDPOINT: process.env.SUPABASE_S3_ENDPOINT || 'https://jevaycxfcszepxuybxel.supabase.co/storage/v1/s3',
    S3_REGION: process.env.SUPABASE_S3_REGION || 'us-west-1',
  },

  // 🚂 Railway Configuration
  RAILWAY: {
    PROJECT_NAME: process.env.RAILWAY_PROJECT_NAME || 'adm-rundrivers',
    API_TOKEN: process.env.RAILWAY_API_TOKEN || 'YOUR_RAILWAY_TOKEN',
    DEPLOY_URL: process.env.RAILWAY_DEPLOY_URL || 'https://adm-rundrivers-production.up.railway.app',
  },

  // 💳 Stripe Configuration
  STRIPE: {
    ACCOUNT_NAME: process.env.STRIPE_ACCOUNT_NAME || 'Run Drivers',
    PUBLISHABLE_KEY: process.env.STRIPE_PUBLISHABLE_KEY || 'YOUR_STRIPE_PUBLISHABLE_KEY',
    SECRET_KEY: process.env.STRIPE_SECRET_KEY || 'YOUR_STRIPE_SECRET_KEY',
    SDK_LANGUAGE: process.env.STRIPE_SDK_LANGUAGE || 'Python',
    MERCHANT_ID: process.env.STRIPE_MERCHANT_ID || 'merchant.com.run.driver',
  },

  // 🗺️ Google Maps Configuration
  GOOGLE_MAPS: {
    API_KEY: process.env.GOOGLE_MAPS_API_KEY || 'YOUR_GOOGLE_MAPS_API_KEY',
    PROJECT_ID: process.env.GOOGLE_MAPS_PROJECT_ID || 'YOUR_GOOGLE_CLOUD_PROJECT_ID',
  },

  // 🔐 JWT Configuration
  JWT: {
    SECRET: process.env.JWT_SECRET || 'YOUR_JWT_SECRET',
    EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
    REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '30d',
  },

  // 🌐 API Configuration
  API: {
    BASE_URL: process.env.API_BASE_URL || 'https://adm-rundrivers-production.up.railway.app',
    LOCAL_URL: process.env.API_LOCAL_URL || 'http://localhost:8000',
    TIMEOUT: parseInt(process.env.API_TIMEOUT || '30000'),
    VERSION: process.env.API_VERSION || 'v1',
  },

  // 📱 App Configuration
  APP: {
    NAME: process.env.APP_NAME || 'Run Driver Enterprise',
    VERSION: process.env.APP_VERSION || '1.0.1',
    BUNDLE_ID: process.env.APP_BUNDLE_ID || 'com.run.driver.enterprise',
    PACKAGE_NAME: process.env.APP_PACKAGE_NAME || 'com.run.driver.enterprise',
    ENVIRONMENT: process.env.APP_ENVIRONMENT || 'development',
  },

  // 🔒 Security Configuration
  SECURITY: {
    SECRET_KEY: process.env.SECRET_KEY || 'YOUR_SECRET_KEY',
    CORS_ORIGINS: process.env.CORS_ORIGINS || 'http://localhost:3000,http://localhost:8000',
  },

  // 📊 Database Configuration
  DATABASE: {
    URL: process.env.DATABASE_URL || 'postgresql://postgres:password@localhost:5432/run_driver',
    HOST: process.env.DATABASE_HOST || 'localhost',
    PORT: parseInt(process.env.DATABASE_PORT || '5432'),
    NAME: process.env.DATABASE_NAME || 'run_driver',
    USER: process.env.DATABASE_USER || 'postgres',
    PASSWORD: process.env.DATABASE_PASSWORD || 'password',
  },

  // 🔔 Notification Configuration
  NOTIFICATIONS: {
    ENABLED: process.env.PUSH_NOTIFICATION_ENABLED === 'true',
    SERVER_KEY: process.env.PUSH_NOTIFICATION_SERVER_KEY || 'YOUR_FIREBASE_SERVER_KEY',
    SENDER_ID: process.env.PUSH_NOTIFICATION_SENDER_ID || 'YOUR_FIREBASE_SENDER_ID',
  },

  // 📸 Camera & Media Configuration
  MEDIA: {
    CAMERA_ENABLED: process.env.CAMERA_PERMISSION_ENABLED === 'true',
    GALLERY_ENABLED: process.env.GALLERY_PERMISSION_ENABLED === 'true',
    MAX_IMAGE_SIZE: parseInt(process.env.MAX_IMAGE_SIZE || '10485760'),
    ALLOWED_IMAGE_TYPES: process.env.ALLOWED_IMAGE_TYPES || 'jpg,jpeg,png,heic',
  },

  // 📍 Location Configuration
  LOCATION: {
    ENABLED: process.env.LOCATION_PERMISSION_ENABLED === 'true',
    ACCURACY: process.env.LOCATION_ACCURACY || 'high',
    TIMEOUT: parseInt(process.env.LOCATION_TIMEOUT || '10000'),
    MAX_AGE: parseInt(process.env.LOCATION_MAX_AGE || '60000'),
  },

  // 🔐 Biometric Configuration
  BIOMETRIC: {
    ENABLED: process.env.BIOMETRIC_ENABLED === 'true',
    FALLBACK_ENABLED: process.env.BIOMETRIC_FALLBACK_ENABLED === 'true',
    TIMEOUT: parseInt(process.env.BIOMETRIC_TIMEOUT || '30000'),
  },

  // 🎨 Design System Configuration
  DESIGN_SYSTEM: {
    THEME: process.env.DESIGN_SYSTEM_THEME || 'manus',
    PRIMARY_COLOR: process.env.DESIGN_SYSTEM_PRIMARY_COLOR || '#7CB342',
    SECONDARY_COLOR: process.env.DESIGN_SYSTEM_SECONDARY_COLOR || '#3B82F6',
    SUCCESS_COLOR: process.env.DESIGN_SYSTEM_SUCCESS_COLOR || '#10B981',
    WARNING_COLOR: process.env.DESIGN_SYSTEM_WARNING_COLOR || '#F59E0B',
    ERROR_COLOR: process.env.DESIGN_SYSTEM_ERROR_COLOR || '#EF4444',
  },

  // 📊 Analytics Configuration
  ANALYTICS: {
    ENABLED: process.env.ANALYTICS_ENABLED === 'true',
    TRACKING_ID: process.env.ANALYTICS_TRACKING_ID || 'YOUR_ANALYTICS_ID',
    DEBUG_MODE: process.env.ANALYTICS_DEBUG_MODE === 'true',
  },

  // 🧪 Testing Configuration
  TESTING: {
    ENABLED: process.env.TESTING_ENABLED === 'true',
    API_URL: process.env.TESTING_API_URL || 'http://localhost:8000',
    MOCK_DATA: process.env.TESTING_MOCK_DATA === 'true',
  },

  // 🚀 Deployment Configuration
  DEPLOYMENT: {
    ENVIRONMENT: process.env.DEPLOYMENT_ENVIRONMENT || 'development',
    REGION: process.env.DEPLOYMENT_REGION || 'us-east-1',
    VERSION: process.env.DEPLOYMENT_VERSION || '1.0.1',
    TIMESTAMP: process.env.DEPLOYMENT_TIMESTAMP || '2024-08-05T16:46:00Z',
  },
};

// 🔒 Função para obter chaves de forma segura
export const getProjectKey = (keyPath: string): string => {
  const keys = keyPath.split('.');
  let value: any = PROJECT_KEYS;
  
  for (const key of keys) {
    if (value && typeof value === 'object' && key in value) {
      value = value[key];
    } else {
      throw new Error(`Chave não encontrada: ${keyPath}`);
    }
  }
  
  return value;
};

// 🔍 Função para validar se todas as chaves estão configuradas
export const validateKeys = (): { isValid: boolean; missingKeys: string[]; warnings: string[] } => {
  const missingKeys: string[] = [];
  const warnings: string[] = [];
  
  // Verificar Supabase
  if (!PROJECT_KEYS.SUPABASE.PROJECT_ID || PROJECT_KEYS.SUPABASE.PROJECT_ID.includes('YOUR_')) {
    missingKeys.push('SUPABASE.PROJECT_ID');
  }
  if (!PROJECT_KEYS.SUPABASE.API_KEY_ANON || PROJECT_KEYS.SUPABASE.API_KEY_ANON.includes('YOUR_')) {
    missingKeys.push('SUPABASE.API_KEY_ANON');
  }
  
  // Verificar Railway
  if (!PROJECT_KEYS.RAILWAY.API_TOKEN || PROJECT_KEYS.RAILWAY.API_TOKEN.includes('YOUR_')) {
    missingKeys.push('RAILWAY.API_TOKEN');
  }
  
  // Verificar Stripe
  if (!PROJECT_KEYS.STRIPE.PUBLISHABLE_KEY || PROJECT_KEYS.STRIPE.PUBLISHABLE_KEY.includes('YOUR_')) {
    missingKeys.push('STRIPE.PUBLISHABLE_KEY');
  }
  if (!PROJECT_KEYS.STRIPE.SECRET_KEY || PROJECT_KEYS.STRIPE.SECRET_KEY.includes('YOUR_')) {
    missingKeys.push('STRIPE.SECRET_KEY');
  }
  
  // Verificar Google Maps
  if (!PROJECT_KEYS.GOOGLE_MAPS.API_KEY || PROJECT_KEYS.GOOGLE_MAPS.API_KEY.includes('YOUR_')) {
    warnings.push('⚠️ Google Maps API Key não configurada');
  }
  
  // Verificar JWT
  if (!PROJECT_KEYS.JWT.SECRET || PROJECT_KEYS.JWT.SECRET.includes('YOUR_')) {
    missingKeys.push('JWT.SECRET');
  }
  
  // Verificar Database
  if (!PROJECT_KEYS.DATABASE.URL || PROJECT_KEYS.DATABASE.URL.includes('localhost')) {
    warnings.push('⚠️ Database URL usando localhost - verifique para produção');
  }
  
  return {
    isValid: missingKeys.length === 0,
    missingKeys,
    warnings,
  };
};

// 📊 Função para obter configuração do ambiente
export const getEnvironmentConfig = () => {
  const isDevelopment = __DEV__;
  
  return {
    isDevelopment,
    isProduction: !isDevelopment,
    apiUrl: isDevelopment ? PROJECT_KEYS.API.LOCAL_URL : PROJECT_KEYS.API.BASE_URL,
    stripeKey: PROJECT_KEYS.STRIPE.PUBLISHABLE_KEY,
    stripeMerchantId: PROJECT_KEYS.STRIPE.MERCHANT_ID,
    supabaseUrl: PROJECT_KEYS.SUPABASE.PROJECT_URL,
    supabaseKey: PROJECT_KEYS.SUPABASE.API_KEY_ANON,
    googleMapsKey: PROJECT_KEYS.GOOGLE_MAPS.API_KEY,
    environment: PROJECT_KEYS.APP.ENVIRONMENT,
    version: PROJECT_KEYS.APP.VERSION,
  };
};

// 🔧 Função para obter configuração específica
export const getConfig = (section: keyof typeof PROJECT_KEYS) => {
  return PROJECT_KEYS[section];
};

// 📋 Função para listar todas as configurações
export const listAllConfigs = () => {
  return Object.keys(PROJECT_KEYS).map(section => ({
    section,
    config: PROJECT_KEYS[section as keyof typeof PROJECT_KEYS],
  }));
};

export default PROJECT_KEYS;