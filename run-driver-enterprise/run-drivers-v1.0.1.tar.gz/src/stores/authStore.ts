import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';
import { authService, apiUtils } from '../services/apiService';
import { biometricService } from '../services/biometricService';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  biometricEnabled: boolean;
  
  // Ações
  login: (email: string, password: string) => Promise<{ success: boolean; user?: User; error?: string }>;
  loginWithBiometric: () => Promise<{ success: boolean; user?: User; error?: string }>;
  register: (userData: any) => Promise<{ success: boolean; user?: User; error?: string }>;
  logout: () => Promise<void>;
  verifyToken: () => Promise<boolean>;
  refreshToken: () => Promise<boolean>;
  updateUser: (userData: Partial<User>) => void;
  clearError: () => void;
  enableBiometric: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  disableBiometric: () => Promise<{ success: boolean; error?: string }>;
  checkBiometricSupport: () => Promise<{ isSupported: boolean; biometricType?: string; error?: string }>;
  
  // Getters
  getUser: () => User | null;
  getToken: () => string | null;
  isDriver: () => boolean;
  isPassenger: () => boolean;
  isBiometricEnabled: () => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      // Estado
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      biometricEnabled: false,

      // Ações
      login: async (email, password) => {
        set({ isLoading: true, error: null });
        
        try {
          const response = await authService.login(email, password);
          
          const { token, user } = response;
          
          // Salvar token
          await apiUtils.setAuthToken(token);
          await apiUtils.setUserData(user);
          
          set({
            user,
            token,
            isAuthenticated: true,
            isLoading: false,
            error: null
          });
          
          return { success: true, user };
        } catch (error: any) {
          const errorMessage = error.response?.data?.error || error.message || 'Erro ao fazer login';
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: errorMessage
          });
          
          return { success: false, error: errorMessage };
        }
      },

      loginWithBiometric: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // Verificar se biometria está habilitada
          const isEnabled = await biometricService.isBiometricLoginEnabled();
          
          if (!isEnabled) {
            set({ isLoading: false, error: 'Login biométrico não está habilitado' });
            return { success: false, error: 'Login biométrico não está habilitado' };
          }

          // Obter credenciais salvas
          const credentials = await biometricService.getCredentialsForLogin();
          
          if (!credentials) {
            set({ isLoading: false, error: 'Credenciais biométricas não encontradas' });
            return { success: false, error: 'Credenciais biométricas não encontradas' };
          }

          // Fazer login com as credenciais salvas
          const loginResult = await get().login(credentials.email, credentials.password);
          
          if (loginResult.success) {
            set({ biometricEnabled: true });
          }
          
          return loginResult;
        } catch (error: any) {
          const errorMessage = error.message || 'Erro no login biométrico';
          
          set({
            isLoading: false,
            error: errorMessage
          });
          
          return { success: false, error: errorMessage };
        }
      },

      register: async (userData) => {
        set({ isLoading: true, error: null });
        
        try {
          const response = await authService.register(userData);
          
          const { token, user } = response;
          
          // Salvar token
          await apiUtils.setAuthToken(token);
          await apiUtils.setUserData(user);
          
          set({
            user,
            token,
            isAuthenticated: true,
            isLoading: false,
            error: null
          });
          
          return { success: true, user };
        } catch (error: any) {
          const errorMessage = error.response?.data?.error || error.message || 'Erro ao criar conta';
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: errorMessage
          });
          
          return { success: false, error: errorMessage };
        }
      },

      logout: async () => {
        set({ isLoading: true });
        
        try {
          await authService.logout();
        } catch (error) {
          console.error('Erro ao fazer logout:', error);
        } finally {
          // Limpar dados locais independente do resultado da API
          await apiUtils.removeAuthToken();
          await apiUtils.removeUserData();
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: null,
            biometricEnabled: false
          });
        }
      },

      verifyToken: async () => {
        const token = await apiUtils.getAuthToken();
        
        if (!token) {
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false
          });
          return false;
        }

        set({ isLoading: true });
        
        try {
          const response = await authService.verifyToken();
          
          if (response.user) {
            await apiUtils.setUserData(response.user);
            
            set({
              user: response.user,
              token,
              isAuthenticated: true,
              isLoading: false,
              error: null
            });
            return true;
          } else {
            throw new Error('Token inválido');
          }
        } catch (error) {
          // Token inválido ou expirado
          await apiUtils.removeAuthToken();
          await apiUtils.removeUserData();
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: null
          });
          
          return false;
        }
      },

      refreshToken: async () => {
        try {
          const response = await authService.refreshToken();
          const { token } = response;
          
          await apiUtils.setAuthToken(token);
          
          set({
            token,
            error: null
          });
          
          return true;
        } catch (error) {
          // Não foi possível renovar o token
          get().logout();
          return false;
        }
      },

      updateUser: (userData) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null
        }));
      },

      clearError: () => {
        set({ error: null });
      },

      enableBiometric: async (email, password) => {
        try {
          const result = await biometricService.enableBiometricLogin(email, password);
          
          if (result.success) {
            set({ biometricEnabled: true });
          }
          
          return result;
        } catch (error: any) {
          return {
            success: false,
            error: error.message || 'Erro ao habilitar biometria'
          };
        }
      },

      disableBiometric: async () => {
        try {
          const result = await biometricService.disableBiometricLogin();
          
          if (result.success) {
            set({ biometricEnabled: false });
          }
          
          return result;
        } catch (error: any) {
          return {
            success: false,
            error: error.message || 'Erro ao desabilitar biometria'
          };
        }
      },

      checkBiometricSupport: async () => {
        try {
          const support = await biometricService.checkDeviceSupport();
          return support;
        } catch (error: any) {
          return {
            isSupported: false,
            biometricType: null,
            error: error.message || 'Erro ao verificar suporte à biometria'
          };
        }
      },

      // Getters
      getUser: () => get().user,
      getToken: () => get().token,
      isDriver: () => get().user?.type === 'driver',
      isPassenger: () => get().user?.type === 'passenger',
      isBiometricEnabled: () => get().biometricEnabled,
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
        biometricEnabled: state.biometricEnabled,
      }),
    }
  )
);
