import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuthStore } from '../stores/authStore';
import { LoginScreen } from '../screens/auth/LoginScreen';
import { DashboardScreen } from '../screens/dashboard/DashboardScreen';
import { TripsScreen } from '../screens/trips/TripsScreen';
import { ProfileScreen } from '../screens/profile/ProfileScreen';
import { WalletScreen } from '../screens/wallet/WalletScreen';
import { SocialScreen } from '../screens/social/SocialScreen';
import { colors } from '../constants/tokens';
import { Text } from '../components/atoms';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const AuthStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Login" component={LoginScreen} />
  </Stack.Navigator>
);

const MainTab = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: colors.primary[500],
      tabBarInactiveTintColor: colors.neutral[400],
      tabBarStyle: {
        backgroundColor: 'white',
        borderTopWidth: 1,
        borderTopColor: colors.neutral[200],
        paddingBottom: 8,
        paddingTop: 8,
        height: 60,
      },
    }}
  >
    <Tab.Screen 
      name="Dashboard" 
      component={DashboardScreen}
      options={{
        tabBarLabel: 'Início',
        tabBarIcon: ({ color, size }) => (
          <Text style={{ color, fontSize: size }}>🏠</Text>
        ),
      }}
    />
    <Tab.Screen 
      name="Trips" 
      component={TripsScreen}
      options={{
        tabBarLabel: 'Viagens',
        tabBarIcon: ({ color, size }) => (
          <Text style={{ color, fontSize: size }}>🚗</Text>
        ),
      }}
    />
    <Tab.Screen 
      name="Wallet" 
      component={WalletScreen}
      options={{
        tabBarLabel: 'Carteira',
        tabBarIcon: ({ color, size }) => (
          <Text style={{ color, fontSize: size }}>💰</Text>
        ),
      }}
    />
    <Tab.Screen 
      name="Social" 
      component={SocialScreen}
      options={{
        tabBarLabel: 'Comunidade',
        tabBarIcon: ({ color, size }) => (
          <Text style={{ color, fontSize: size }}>👥</Text>
        ),
      }}
    />
    <Tab.Screen 
      name="Profile" 
      component={ProfileScreen}
      options={{
        tabBarLabel: 'Perfil',
        tabBarIcon: ({ color, size }) => (
          <Text style={{ color, fontSize: size }}>👤</Text>
        ),
      }}
    />
  </Tab.Navigator>
);

export const AppNavigator = () => {
  const { isAuthenticated } = useAuthStore();

  return (
    <NavigationContainer>
      {isAuthenticated ? <MainTab /> : <AuthStack />}
    </NavigationContainer>
  );
};
