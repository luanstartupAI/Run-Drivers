# Estudo Completo de Componentização - Run Driver

## Arquitetura Frontend e Árvore de Componentes

---

## Sumário Executivo

Este documento apresenta um estudo aprofundado e detalhado da componentização necessária para o desenvolvimento do aplicativo Run Driver, uma plataforma de transporte inspirada no modelo Uber, mas com funcionalidades inovadoras que incluem gamificação, rede social integrada, IA de personalização e sistema de economia interna. O projeto visa criar uma experiência única para motoristas, utilizando a identidade visual do MANUS.IM e implementando uma arquitetura frontend robusta e escalável.

A componentização proposta segue as melhores práticas de desenvolvimento React, organizando a aplicação em módulos funcionais bem definidos, com separação clara de responsabilidades e máxima reutilização de código. A estrutura contempla desde componentes básicos de interface até sistemas complexos de mapa interativo, autenticação biométrica e integração com APIs de pagamento.

---

## 1. Visão Geral da Arquitetura

### 1.1 Princípios Fundamentais

A arquitetura do Run Driver baseia-se em cinco pilares fundamentais que garantem escalabilidade, manutenibilidade e performance:

**Componentização Atômica:** Seguindo a metodologia Atomic Design, organizamos os componentes em cinco níveis hierárquicos - átomos, moléculas, organismos, templates e páginas. Esta abordagem permite máxima reutilização e facilita a manutenção do código.

**Estado Centralizado:** Utilizamos Zustand para gerenciamento de estado global, proporcionando performance superior em aplicações em tempo real como o Run Driver. O estado é organizado em slices funcionais, cada um responsável por um domínio específico da aplicação.

**Renderização Condicional Inteligente:** Implementamos um sistema de renderização baseado em contexto que adapta a interface dinamicamente conforme o estado do motorista, localização, horário e preferências personalizadas pela IA.

**Modularidade por Funcionalidade:** Cada funcionalidade principal (mapa, autenticação, gamificação, rede social, pagamentos) é encapsulada em seu próprio módulo, com interfaces bem definidas e baixo acoplamento.

**Performance First:** Todos os componentes são otimizados para performance, utilizando React.memo, useMemo, useCallback e lazy loading quando apropriado.

### 1.2 Stack Tecnológica Principal

A escolha da stack tecnológica foi cuidadosamente planejada para atender aos requisitos específicos do Run Driver:

**React 18+** como biblioteca principal, aproveitando as funcionalidades de Concurrent Features para melhor performance em operações assíncronas como atualizações de localização em tempo real.

**Shadcn UI** como sistema de design base, escolhido por sua flexibilidade e abordagem "copy-based" que permite personalização total para incorporar a identidade visual do MANUS.IM.

**Tailwind CSS** para estilização, proporcionando consistência visual e facilidade de manutenção através de utility classes.

**React Leaflet** para funcionalidades de mapa, oferecendo flexibilidade superior ao Google Maps para customizações específicas do Run Driver.

**Zustand** para gerenciamento de estado, escolhido por sua simplicidade e performance em aplicações com muitas atualizações de estado em tempo real.

**React Hook Form + Zod** para formulários e validação, garantindo type safety e performance otimizada.

**TanStack Query** para gerenciamento de estado servidor, cache inteligente e sincronização de dados.

---

## 2. Árvore de Componentes Detalhada

### 2.1 Componentes Atômicos (Atoms)

Os componentes atômicos formam a base do sistema de design, sendo os elementos mais básicos e reutilizáveis:



#### 2.1.1 Componentes de Interface Básica

**Button Component**
```typescript
interface ButtonProps {
  variant: 'primary' | 'secondary' | 'danger' | 'ghost' | 'manus-gradient';
  size: 'sm' | 'md' | 'lg' | 'xl';
  loading?: boolean;
  disabled?: boolean;
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  onClick?: () => void;
  children: ReactNode;
}
```

O componente Button é fundamental para toda a aplicação, implementando a identidade visual do MANUS.IM através de variantes específicas. A variante 'manus-gradient' utiliza os gradientes característicos da marca, enquanto os estados de loading e disabled seguem os padrões de acessibilidade WCAG 2.1.

**Input Component**
```typescript
interface InputProps {
  type: 'text' | 'email' | 'password' | 'number' | 'tel';
  placeholder?: string;
  label?: string;
  error?: string;
  success?: string;
  disabled?: boolean;
  required?: boolean;
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  mask?: string;
  validation?: ZodSchema;
  onChange?: (value: string) => void;
}
```

O Input Component incorpora validação em tempo real usando Zod, máscaras para campos específicos (CPF, telefone, placa de veículo) e estados visuais claros para feedback do usuário.

**Icon Component**
```typescript
interface IconProps {
  name: string;
  size?: number | 'sm' | 'md' | 'lg' | 'xl';
  color?: string;
  className?: string;
  onClick?: () => void;
  ariaLabel?: string;
}
```

Integra a biblioteca de ícones do MANUS.IM com fallback para Lucide React, garantindo consistência visual e acessibilidade através de aria-labels apropriados.

#### 2.1.2 Componentes de Feedback Visual

**Badge Component**
```typescript
interface BadgeProps {
  variant: 'success' | 'warning' | 'error' | 'info' | 'manus-primary';
  size: 'sm' | 'md' | 'lg';
  icon?: ReactNode;
  pulse?: boolean;
  children: ReactNode;
}
```

Utilizado extensivamente no sistema de gamificação para exibir conquistas, níveis e status do motorista.

**Avatar Component**
```typescript
interface AvatarProps {
  src?: string;
  alt: string;
  size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  fallback?: string;
  status?: 'online' | 'offline' | 'busy' | 'away';
  border?: boolean;
  onClick?: () => void;
}
```

Implementa indicadores de status em tempo real para a funcionalidade de rede social e sistema de disponibilidade do motorista.

**ProgressBar Component**
```typescript
interface ProgressBarProps {
  value: number;
  max?: number;
  variant: 'default' | 'success' | 'warning' | 'error' | 'manus-gradient';
  size: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  animated?: boolean;
  striped?: boolean;
}
```

Essencial para o sistema de gamificação, exibindo progresso de níveis, conquistas e metas diárias/semanais.

#### 2.1.3 Componentes de Navegação

**Tab Component**
```typescript
interface TabProps {
  tabs: Array<{
    id: string;
    label: string;
    icon?: ReactNode;
    badge?: number;
    disabled?: boolean;
  }>;
  activeTab: string;
  onTabChange: (tabId: string) => void;
  variant: 'default' | 'pills' | 'underline' | 'manus-style';
}
```

Implementa navegação contextual dentro de modais e seções principais da aplicação.

### 2.2 Componentes Moleculares (Molecules)

Os componentes moleculares combinam átomos para formar unidades funcionais mais complexas:

#### 2.2.1 Formulários Compostos

**LoginForm Component**
```typescript
interface LoginFormProps {
  onSubmit: (data: LoginData) => Promise<void>;
  loading?: boolean;
  error?: string;
  showBiometric?: boolean;
  showSocialLogin?: boolean;
}

interface LoginData {
  email: string;
  password: string;
  rememberMe: boolean;
}
```

Integra validação em tempo real, autenticação biométrica quando disponível e opções de login social. Implementa rate limiting para prevenir ataques de força bruta.

**DocumentUpload Component**
```typescript
interface DocumentUploadProps {
  documentType: 'cnh' | 'crlv' | 'selfie' | 'vehicle_photo';
  onUpload: (file: File, metadata: DocumentMetadata) => Promise<void>;
  onOCRComplete?: (extractedData: any) => void;
  maxSize?: number;
  acceptedFormats: string[];
  required?: boolean;
}
```

Implementa upload seguro com validação de formato, OCR para extração automática de dados de documentos e preview em tempo real.

#### 2.2.2 Cards Informativos

**TripCard Component**
```typescript
interface TripCardProps {
  trip: Trip;
  status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
  onAccept?: () => void;
  onReject?: () => void;
  onNavigate?: () => void;
  showEarnings?: boolean;
}
```

Exibe informações detalhadas de viagens com ações contextuais baseadas no status atual.

**EarningsCard Component**
```typescript
interface EarningsCardProps {
  period: 'today' | 'week' | 'month' | 'year';
  earnings: EarningsData;
  showBreakdown?: boolean;
  showGoals?: boolean;
  onViewDetails?: () => void;
}
```

Apresenta dados de ganhos com visualizações gráficas e comparações com períodos anteriores.

#### 2.2.3 Controles de Mapa

**MapControls Component**
```typescript
interface MapControlsProps {
  onCenterLocation: () => void;
  onToggleTraffic: () => void;
  onToggleSatellite: () => void;
  showZoomControls?: boolean;
  showCompass?: boolean;
  position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
}
```

Fornece controles customizados para interação com o mapa, mantendo a interface limpa e acessível.

### 2.3 Componentes Organismos (Organisms)

Os organismos representam seções completas da interface, combinando múltiplas moléculas:

#### 2.3.1 Sistema de Mapa Principal

**MapContainer Component**
```typescript
interface MapContainerProps {
  center: [number, number];
  zoom: number;
  onLocationUpdate: (location: Location) => void;
  showTraffic?: boolean;
  showDrivers?: boolean;
  showRoute?: boolean;
  route?: RouteData;
  markers?: MarkerData[];
  onMarkerClick?: (marker: MarkerData) => void;
}
```

O componente central da aplicação, gerenciando toda a interação com o mapa. Implementa otimizações de performance para renderização de múltiplos marcadores e atualizações de localização em tempo real.

**RouteDisplay Component**
```typescript
interface RouteDisplayProps {
  origin: Location;
  destination: Location;
  waypoints?: Location[];
  optimizeRoute?: boolean;
  showAlternatives?: boolean;
  onRouteSelect?: (route: RouteData) => void;
  trafficAware?: boolean;
}
```

Calcula e exibe rotas otimizadas, considerando tráfego em tempo real e preferências do motorista.

#### 2.3.2 Sistema de Autenticação

**AuthenticationFlow Component**
```typescript
interface AuthenticationFlowProps {
  initialStep?: 'login' | 'register' | 'forgot-password' | 'biometric-setup';
  onAuthSuccess: (user: User) => void;
  onAuthError: (error: AuthError) => void;
  enableBiometric?: boolean;
  enableSocialAuth?: boolean;
}
```

Gerencia todo o fluxo de autenticação, incluindo registro multi-etapas para motoristas, verificação de documentos e configuração de autenticação biométrica.

**DocumentVerification Component**
```typescript
interface DocumentVerificationProps {
  requiredDocuments: DocumentType[];
  onVerificationComplete: (results: VerificationResults) => void;
  onVerificationError: (error: VerificationError) => void;
  enableOCR?: boolean;
  enableLivenessCheck?: boolean;
}
```

Implementa verificação completa de documentos com OCR, validação de autenticidade e verificação de vivacidade para selfies.

#### 2.3.3 Sistema de Gamificação

**GamificationDashboard Component**
```typescript
interface GamificationDashboardProps {
  userLevel: number;
  experience: number;
  achievements: Achievement[];
  dailyGoals: Goal[];
  weeklyGoals: Goal[];
  leaderboard: LeaderboardEntry[];
  onClaimReward: (rewardId: string) => void;
}
```

Centraliza todas as funcionalidades de gamificação, exibindo progresso, conquistas e rankings de forma envolvente.

**AchievementSystem Component**
```typescript
interface AchievementSystemProps {
  achievements: Achievement[];
  unlockedAchievements: string[];
  onAchievementUnlock: (achievement: Achievement) => void;
  showNotifications?: boolean;
}
```

Gerencia o sistema de conquistas com notificações em tempo real e animações de desbloqueio.

#### 2.3.4 Rede Social Integrada

**SocialFeed Component**
```typescript
interface SocialFeedProps {
  posts: SocialPost[];
  onLike: (postId: string) => void;
  onComment: (postId: string, comment: string) => void;
  onShare: (postId: string) => void;
  onCreatePost: (post: CreatePostData) => void;
  enableFilters?: boolean;
}
```

Implementa feed social com interações em tempo real, filtros por tipo de conteúdo e moderação automática.

**DriverProfile Component**
```typescript
interface DriverProfileProps {
  driver: DriverData;
  isOwnProfile?: boolean;
  onFollow?: () => void;
  onMessage?: () => void;
  onReport?: () => void;
  showStats?: boolean;
  showAchievements?: boolean;
}
```

Exibe perfis de motoristas com estatísticas, conquistas e opções de interação social.

### 2.4 Templates e Páginas

#### 2.4.1 Layout Principal

**MainLayout Component**
```typescript
interface MainLayoutProps {
  children: ReactNode;
  showHeader?: boolean;
  showBottomNav?: boolean;
  showSidebar?: boolean;
  headerContent?: ReactNode;
  sidebarContent?: ReactNode;
}
```

Define a estrutura base da aplicação com navegação responsiva e áreas de conteúdo flexíveis.

#### 2.4.2 Páginas Principais

**DashboardPage Component**
Página principal do motorista com mapa centralizado, informações de status e acesso rápido a funcionalidades principais.

**TripManagementPage Component**
Gerenciamento de viagens ativas e históricas com filtros avançados e análises de performance.

**EarningsPage Component**
Análise detalhada de ganhos com gráficos interativos e projeções baseadas em IA.

**ProfilePage Component**
Gerenciamento de perfil, documentos e configurações de privacidade.

**SocialPage Component**
Interface completa da rede social com feed, mensagens e grupos de motoristas.

---

## 3. Arquitetura de Estado e Gerenciamento de Dados

### 3.1 Estrutura do Estado Global

O gerenciamento de estado do Run Driver utiliza Zustand organizado em slices funcionais, cada um responsável por um domínio específico da aplicação:

#### 3.1.1 Auth Store
```typescript
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  biometricEnabled: boolean;
  sessionToken: string | null;
  refreshToken: string | null;
  permissions: Permission[];
}

interface AuthActions {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => Promise<void>;
  refreshSession: () => Promise<void>;
  enableBiometric: () => Promise<void>;
  updateProfile: (data: ProfileData) => Promise<void>;
}
```

#### 3.1.2 Location Store
```typescript
interface LocationState {
  currentLocation: Location | null;
  isTracking: boolean;
  accuracy: number;
  heading: number;
  speed: number;
  locationHistory: Location[];
  permissionStatus: 'granted' | 'denied' | 'prompt';
}

interface LocationActions {
  startTracking: () => Promise<void>;
  stopTracking: () => void;
  updateLocation: (location: Location) => void;
  requestPermission: () => Promise<PermissionStatus>;
}
```

#### 3.1.3 Trip Store
```typescript
interface TripState {
  activeTrip: Trip | null;
  tripRequests: TripRequest[];
  tripHistory: Trip[];
  earnings: EarningsData;
  isOnline: boolean;
  driverStatus: 'available' | 'busy' | 'offline' | 'break';
}

interface TripActions {
  goOnline: () => Promise<void>;
  goOffline: () => Promise<void>;
  acceptTrip: (tripId: string) => Promise<void>;
  rejectTrip: (tripId: string) => Promise<void>;
  startTrip: (tripId: string) => Promise<void>;
  completeTrip: (tripId: string, data: TripCompletionData) => Promise<void>;
}
```

### 3.2 Integração com APIs Externas

#### 3.2.1 Configuração do TanStack Query

```typescript
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutos
      cacheTime: 10 * 60 * 1000, // 10 minutos
      retry: (failureCount, error) => {
        if (error.status === 404) return false;
        return failureCount < 3;
      },
    },
  },
});
```

#### 3.2.2 Hooks Customizados para Dados

**useTrips Hook**
```typescript
const useTrips = (filters?: TripFilters) => {
  return useQuery({
    queryKey: ['trips', filters],
    queryFn: () => tripService.getTrips(filters),
    enabled: !!user,
    refetchInterval: 30000, // Atualiza a cada 30 segundos
  });
};
```

**useEarnings Hook**
```typescript
const useEarnings = (period: TimePeriod) => {
  return useQuery({
    queryKey: ['earnings', period],
    queryFn: () => earningsService.getEarnings(period),
    select: (data) => ({
      ...data,
      formattedTotal: formatCurrency(data.total),
      growthPercentage: calculateGrowth(data.current, data.previous),
    }),
  });
};
```

---

## 4. Sistema de Modais e Overlays Inteligentes

### 4.1 Arquitetura de Modais

O sistema de modais do Run Driver implementa o padrão "ActionCard" inspirado na Uber, proporcionando uma experiência fluida e contextual:

#### 4.1.1 Modal Manager

```typescript
interface ModalState {
  activeModals: Modal[];
  modalStack: string[];
  globalSettings: ModalGlobalSettings;
}

interface Modal {
  id: string;
  component: ComponentType<any>;
  props: any;
  options: ModalOptions;
  zIndex: number;
}

interface ModalOptions {
  closable?: boolean;
  backdrop?: 'static' | 'clickable' | 'none';
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'fullscreen';
  position?: 'center' | 'top' | 'bottom';
  animation?: 'fade' | 'slide' | 'scale';
  persistent?: boolean;
}
```

#### 4.1.2 Modais Específicos do Domínio

**TripRequestModal Component**
```typescript
interface TripRequestModalProps {
  tripRequest: TripRequest;
  onAccept: () => void;
  onReject: () => void;
  autoRejectTimer?: number;
  showRoutePreview?: boolean;
}
```

Modal inteligente que aparece automaticamente quando uma nova solicitação de viagem é recebida, com timer de auto-rejeição e preview da rota.

**EarningsBreakdownModal Component**
```typescript
interface EarningsBreakdownModalProps {
  earnings: DetailedEarnings;
  period: TimePeriod;
  showComparison?: boolean;
  showProjections?: boolean;
}
```

Exibe análise detalhada de ganhos com gráficos interativos e projeções baseadas em IA.

**GameAchievementModal Component**
```typescript
interface GameAchievementModalProps {
  achievement: Achievement;
  reward: Reward;
  onClaim: () => void;
  onShare: () => void;
  showAnimation?: boolean;
}
```

Modal celebratório para conquistas desbloqueadas com animações e opções de compartilhamento social.

### 4.2 Sistema de Notificações

#### 4.2.1 Notification Manager

```typescript
interface NotificationState {
  notifications: Notification[];
  settings: NotificationSettings;
  permissions: NotificationPermissions;
}

interface Notification {
  id: string;
  type: 'trip_request' | 'achievement' | 'earning' | 'social' | 'system';
  title: string;
  message: string;
  data?: any;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  timestamp: Date;
  read: boolean;
  actions?: NotificationAction[];
}
```

#### 4.2.2 Notificações Push Inteligentes

O sistema implementa notificações contextuais baseadas em localização, horário e comportamento do usuário:

- **Notificações de Demanda:** Alertas sobre áreas de alta demanda próximas
- **Notificações de Gamificação:** Progresso de metas e conquistas desbloqueadas
- **Notificações Sociais:** Interações na rede social integrada
- **Notificações de Sistema:** Atualizações importantes e manutenções

---

## 5. Integração com Mapas e Geolocalização

### 5.1 Arquitetura do Sistema de Mapas

#### 5.1.1 Map Provider Abstraction

```typescript
interface MapProvider {
  initialize: (config: MapConfig) => Promise<void>;
  addMarker: (marker: MarkerData) => string;
  removeMarker: (markerId: string) => void;
  updateMarker: (markerId: string, data: Partial<MarkerData>) => void;
  drawRoute: (route: RouteData) => string;
  clearRoute: (routeId: string) => void;
  setCenter: (location: Location, zoom?: number) => void;
  fitBounds: (bounds: Bounds) => void;
  on: (event: MapEvent, callback: Function) => void;
  off: (event: MapEvent, callback: Function) => void;
}
```

#### 5.1.2 Leaflet Implementation

```typescript
class LeafletMapProvider implements MapProvider {
  private map: L.Map;
  private markers: Map<string, L.Marker> = new Map();
  private routes: Map<string, L.Polyline> = new Map();
  
  async initialize(config: MapConfig): Promise<void> {
    this.map = L.map(config.containerId, {
      center: config.center,
      zoom: config.zoom,
      zoomControl: false,
      attributionControl: false,
    });
    
    // Adicionar camadas de tile customizadas
    L.tileLayer(config.tileUrl, {
      attribution: config.attribution,
      maxZoom: 19,
    }).addTo(this.map);
  }
  
  addMarker(marker: MarkerData): string {
    const leafletMarker = L.marker([marker.lat, marker.lng], {
      icon: this.createCustomIcon(marker.type),
    }).addTo(this.map);
    
    if (marker.popup) {
      leafletMarker.bindPopup(marker.popup);
    }
    
    this.markers.set(marker.id, leafletMarker);
    return marker.id;
  }
  
  private createCustomIcon(type: MarkerType): L.Icon {
    return L.divIcon({
      className: `custom-marker marker-${type}`,
      html: `<div class="marker-content">${this.getMarkerIcon(type)}</div>`,
      iconSize: [40, 40],
      iconAnchor: [20, 40],
    });
  }
}
```

### 5.2 Componentes de Mapa Especializados

#### 5.2.1 DriverMarker Component

```typescript
interface DriverMarkerProps {
  driver: DriverData;
  position: Location;
  heading?: number;
  status: 'available' | 'busy' | 'offline';
  showInfo?: boolean;
  onClick?: (driver: DriverData) => void;
}
```

Marcador customizado para representar motoristas no mapa com indicadores visuais de status e direção.

#### 5.2.2 RouteOptimizer Component

```typescript
interface RouteOptimizerProps {
  origin: Location;
  destination: Location;
  waypoints?: Location[];
  avoidTolls?: boolean;
  avoidHighways?: boolean;
  optimizeFor: 'time' | 'distance' | 'fuel';
  onRouteCalculated: (route: OptimizedRoute) => void;
}
```

Calcula rotas otimizadas considerando tráfego em tempo real, preferências do motorista e condições da via.

### 5.3 Geofencing e Áreas de Interesse

#### 5.3.1 GeofenceManager

```typescript
interface GeofenceManager {
  createGeofence: (area: GeofenceArea) => string;
  removeGeofence: (geofenceId: string) => void;
  checkLocation: (location: Location) => GeofenceEvent[];
  onEnter: (geofenceId: string, callback: (event: GeofenceEvent) => void) => void;
  onExit: (geofenceId: string, callback: (event: GeofenceEvent) => void) => void;
}

interface GeofenceArea {
  id: string;
  name: string;
  type: 'circle' | 'polygon';
  coordinates: Location[] | { center: Location; radius: number };
  metadata?: any;
}
```

#### 5.3.2 Áreas de Alta Demanda

```typescript
interface DemandHeatmap {
  areas: DemandArea[];
  updateInterval: number;
  onDemandChange: (area: DemandArea) => void;
}

interface DemandArea {
  id: string;
  center: Location;
  radius: number;
  demandLevel: 'low' | 'medium' | 'high' | 'surge';
  multiplier: number;
  estimatedWaitTime: number;
}
```

---

## 6. Sistema de Autenticação e Segurança

### 6.1 Arquitetura de Autenticação

#### 6.1.1 Multi-Factor Authentication

```typescript
interface AuthenticationFlow {
  primaryAuth: PrimaryAuthMethod;
  secondaryAuth?: SecondaryAuthMethod[];
  biometricAuth?: BiometricAuthConfig;
  deviceTrust: DeviceTrustLevel;
}

interface PrimaryAuthMethod {
  type: 'email_password' | 'phone_otp' | 'social_oauth';
  provider?: 'google' | 'facebook' | 'apple';
  credentials: AuthCredentials;
}

interface SecondaryAuthMethod {
  type: 'sms_otp' | 'email_otp' | 'totp' | 'push_notification';
  enabled: boolean;
  verified: boolean;
}

interface BiometricAuthConfig {
  fingerprint: boolean;
  faceId: boolean;
  voiceRecognition: boolean;
  fallbackToPin: boolean;
}
```

#### 6.1.2 Verificação de Documentos

```typescript
interface DocumentVerificationFlow {
  requiredDocuments: DocumentRequirement[];
  ocrEnabled: boolean;
  livenessCheckEnabled: boolean;
  manualReviewThreshold: number;
}

interface DocumentRequirement {
  type: 'cnh' | 'crlv' | 'cpf' | 'selfie' | 'vehicle_photo';
  required: boolean;
  validationRules: ValidationRule[];
  ocrFields?: OCRField[];
}

interface OCRField {
  name: string;
  type: 'text' | 'number' | 'date' | 'enum';
  required: boolean;
  validation?: RegExp;
  confidence_threshold: number;
}
```

### 6.2 Componentes de Autenticação

#### 6.2.1 BiometricAuth Component

```typescript
interface BiometricAuthProps {
  onSuccess: (result: BiometricResult) => void;
  onError: (error: BiometricError) => void;
  fallbackToPin?: boolean;
  promptMessage?: string;
  cancelButtonText?: string;
}

interface BiometricResult {
  success: boolean;
  biometricType: 'fingerprint' | 'face' | 'voice';
  deviceId: string;
  timestamp: Date;
}
```

#### 6.2.2 DocumentUpload Component

```typescript
interface DocumentUploadProps {
  documentType: DocumentType;
  onUploadComplete: (result: UploadResult) => void;
  onOCRComplete?: (data: OCRResult) => void;
  enableOCR?: boolean;
  enableLivenessCheck?: boolean;
  maxFileSize?: number;
  acceptedFormats: string[];
}

interface UploadResult {
  fileId: string;
  url: string;
  ocrData?: OCRResult;
  livenessScore?: number;
  verificationStatus: 'pending' | 'approved' | 'rejected';
}
```

### 6.3 Segurança e Privacidade

#### 6.3.1 Data Encryption

```typescript
interface EncryptionService {
  encryptSensitiveData: (data: any) => string;
  decryptSensitiveData: (encryptedData: string) => any;
  hashPassword: (password: string) => string;
  verifyPassword: (password: string, hash: string) => boolean;
  generateSecureToken: () => string;
}
```

#### 6.3.2 Privacy Controls

```typescript
interface PrivacySettings {
  locationSharing: 'always' | 'while_driving' | 'never';
  profileVisibility: 'public' | 'drivers_only' | 'private';
  dataRetention: 'minimal' | 'standard' | 'extended';
  analyticsOptOut: boolean;
  marketingOptOut: boolean;
  socialFeaturesEnabled: boolean;
}
```

---

## 7. Sistema de Gamificação

### 7.1 Arquitetura de Gamificação

#### 7.1.1 Achievement System

```typescript
interface AchievementSystem {
  achievements: Achievement[];
  userProgress: UserProgress;
  rewardCalculator: RewardCalculator;
  leaderboard: LeaderboardManager;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'driving' | 'social' | 'earnings' | 'safety' | 'efficiency';
  type: 'milestone' | 'streak' | 'challenge' | 'rare';
  requirements: AchievementRequirement[];
  rewards: Reward[];
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  unlockConditions?: UnlockCondition[];
}

interface AchievementRequirement {
  metric: string;
  operator: 'equals' | 'greater_than' | 'less_than' | 'between';
  value: number | [number, number];
  timeframe?: 'daily' | 'weekly' | 'monthly' | 'all_time';
}
```

#### 7.1.2 Leveling System

```typescript
interface LevelingSystem {
  currentLevel: number;
  currentXP: number;
  xpToNextLevel: number;
  totalXP: number;
  levelBenefits: LevelBenefit[];
  xpSources: XPSource[];
}

interface XPSource {
  action: string;
  baseXP: number;
  multipliers: XPMultiplier[];
  cooldown?: number;
  dailyLimit?: number;
}

interface XPMultiplier {
  condition: string;
  multiplier: number;
  description: string;
}
```

### 7.2 Componentes de Gamificação

#### 7.2.1 LevelProgress Component

```typescript
interface LevelProgressProps {
  currentLevel: number;
  currentXP: number;
  xpToNextLevel: number;
  showAnimation?: boolean;
  showBenefits?: boolean;
  onLevelUp?: (newLevel: number) => void;
}
```

#### 7.2.2 AchievementCard Component

```typescript
interface AchievementCardProps {
  achievement: Achievement;
  progress: number;
  unlocked: boolean;
  showProgress?: boolean;
  showRewards?: boolean;
  onClaim?: () => void;
}
```

#### 7.2.3 Leaderboard Component

```typescript
interface LeaderboardProps {
  type: 'global' | 'local' | 'friends';
  timeframe: 'daily' | 'weekly' | 'monthly' | 'all_time';
  metric: 'xp' | 'trips' | 'earnings' | 'rating';
  entries: LeaderboardEntry[];
  currentUserRank?: number;
  onViewProfile?: (userId: string) => void;
}
```

### 7.3 Sistema de Recompensas

#### 7.3.1 Reward Manager

```typescript
interface RewardManager {
  calculateReward: (achievement: Achievement, user: User) => Reward;
  claimReward: (rewardId: string) => Promise<ClaimResult>;
  getAvailableRewards: (userId: string) => Reward[];
  convertToWalletCredit: (reward: Reward) => WalletTransaction;
}

interface Reward {
  id: string;
  type: 'xp' | 'badge' | 'wallet_credit' | 'discount' | 'feature_unlock';
  value: number;
  description: string;
  expiresAt?: Date;
  conditions?: RewardCondition[];
}
```

#### 7.3.2 Virtual Economy

```typescript
interface VirtualEconomy {
  walletBalance: number;
  earningSources: EarningSource[];
  spendingOptions: SpendingOption[];
  conversionRates: ConversionRate[];
}

interface EarningSource {
  type: 'trip_completion' | 'achievement' | 'ad_watch' | 'game_play' | 'referral';
  baseAmount: number;
  multipliers: EarningMultiplier[];
  dailyLimit?: number;
}
```

---

## 8. Rede Social Integrada

### 8.1 Arquitetura Social

#### 8.1.1 Social Graph

```typescript
interface SocialGraph {
  connections: Connection[];
  groups: Group[];
  followings: Following[];
  blockedUsers: string[];
  privacySettings: SocialPrivacySettings;
}

interface Connection {
  userId: string;
  type: 'friend' | 'follower' | 'following' | 'mutual';
  status: 'pending' | 'accepted' | 'blocked';
  connectedAt: Date;
  mutualConnections: number;
}

interface Group {
  id: string;
  name: string;
  description: string;
  type: 'public' | 'private' | 'invite_only';
  category: 'city' | 'vehicle_type' | 'interest' | 'company';
  memberCount: number;
  isAdmin: boolean;
  isMember: boolean;
}
```

#### 8.1.2 Content Management

```typescript
interface ContentManager {
  createPost: (content: PostContent) => Promise<Post>;
  moderateContent: (postId: string) => Promise<ModerationResult>;
  reportContent: (postId: string, reason: string) => Promise<void>;
  getPersonalizedFeed: (userId: string) => Promise<Post[]>;
}

interface PostContent {
  type: 'text' | 'image' | 'video' | 'poll' | 'achievement_share';
  text?: string;
  media?: MediaFile[];
  poll?: PollData;
  achievement?: Achievement;
  location?: Location;
  visibility: 'public' | 'friends' | 'group';
  tags?: string[];
}
```

### 8.2 Componentes Sociais

#### 8.2.1 SocialFeed Component

```typescript
interface SocialFeedProps {
  feedType: 'home' | 'following' | 'group' | 'local';
  filters?: FeedFilter[];
  onPostInteraction: (interaction: PostInteraction) => void;
  onLoadMore: () => void;
  refreshing?: boolean;
  onRefresh?: () => void;
}

interface PostInteraction {
  type: 'like' | 'comment' | 'share' | 'report' | 'save';
  postId: string;
  data?: any;
}
```

#### 8.2.2 DriverProfile Component

```typescript
interface DriverProfileProps {
  driverId: string;
  isOwnProfile?: boolean;
  showStats?: boolean;
  showAchievements?: boolean;
  showRecentActivity?: boolean;
  onFollow?: () => void;
  onMessage?: () => void;
  onReport?: () => void;
}
```

#### 8.2.3 GroupChat Component

```typescript
interface GroupChatProps {
  groupId: string;
  messages: Message[];
  onSendMessage: (message: string, attachments?: File[]) => void;
  onTyping: (isTyping: boolean) => void;
  typingUsers: string[];
  canSendMedia?: boolean;
  canSendLocation?: boolean;
}
```

### 8.3 Moderação e Segurança Social

#### 8.3.1 Content Moderation

```typescript
interface ModerationSystem {
  autoModerate: (content: string) => ModerationResult;
  reportContent: (contentId: string, reason: ReportReason) => Promise<void>;
  reviewReports: (reportId: string) => Promise<ModerationAction>;
  banUser: (userId: string, duration: number, reason: string) => Promise<void>;
}

interface ModerationResult {
  approved: boolean;
  confidence: number;
  flags: ModerationFlag[];
  suggestedAction: 'approve' | 'review' | 'reject' | 'flag';
}
```

#### 8.3.2 Privacy Controls

```typescript
interface SocialPrivacySettings {
  profileVisibility: 'public' | 'drivers_only' | 'friends' | 'private';
  allowMessages: 'everyone' | 'friends' | 'none';
  allowFriendRequests: boolean;
  showOnlineStatus: boolean;
  showLocation: 'never' | 'friends' | 'while_driving';
  allowTagging: boolean;
  contentVisibility: ContentVisibilitySettings;
}
```

---

## 9. Sistema de Pagamentos e Carteira Virtual

### 9.1 Arquitetura de Pagamentos

#### 9.1.1 Payment Gateway Integration

```typescript
interface PaymentGateway {
  stripe: StripeIntegration;
  pix: PixIntegration;
  wallet: WalletManager;
  escrow: EscrowService;
}

interface StripeIntegration {
  createPaymentIntent: (amount: number, currency: string) => Promise<PaymentIntent>;
  confirmPayment: (paymentIntentId: string) => Promise<PaymentResult>;
  createConnectedAccount: (driverData: DriverData) => Promise<ConnectedAccount>;
  transferToDriver: (amount: number, accountId: string) => Promise<Transfer>;
}

interface WalletManager {
  getBalance: (userId: string) => Promise<WalletBalance>;
  addFunds: (userId: string, amount: number, source: FundingSource) => Promise<Transaction>;
  deductFunds: (userId: string, amount: number, reason: string) => Promise<Transaction>;
  transferFunds: (fromUserId: string, toUserId: string, amount: number) => Promise<Transaction>;
  getTransactionHistory: (userId: string, filters?: TransactionFilter[]) => Promise<Transaction[]>;
}
```

#### 9.1.2 Earnings Management

```typescript
interface EarningsManager {
  calculateTripEarnings: (trip: Trip) => EarningsBreakdown;
  applyCommission: (grossEarnings: number) => CommissionBreakdown;
  processWeeklyPayout: (driverId: string) => Promise<PayoutResult>;
  generateEarningsReport: (driverId: string, period: TimePeriod) => Promise<EarningsReport>;
}

interface EarningsBreakdown {
  baseFare: number;
  distanceFare: number;
  timeFare: number;
  surgeMultiplier: number;
  tips: number;
  bonuses: number;
  gross: number;
  commission: number;
  net: number;
}
```

### 9.2 Componentes de Pagamento

#### 9.2.1 WalletDashboard Component

```typescript
interface WalletDashboardProps {
  balance: WalletBalance;
  recentTransactions: Transaction[];
  pendingEarnings: number;
  nextPayoutDate: Date;
  onAddFunds: () => void;
  onWithdraw: () => void;
  onViewHistory: () => void;
}
```

#### 9.2.2 EarningsChart Component

```typescript
interface EarningsChartProps {
  data: EarningsData[];
  period: 'daily' | 'weekly' | 'monthly';
  showComparison?: boolean;
  showProjection?: boolean;
  onPeriodChange: (period: string) => void;
}
```

#### 9.2.3 PaymentMethod Component

```typescript
interface PaymentMethodProps {
  methods: PaymentMethod[];
  selectedMethod?: string;
  onMethodSelect: (methodId: string) => void;
  onAddMethod: () => void;
  onRemoveMethod: (methodId: string) => void;
  showDefault?: boolean;
}
```

### 9.3 Watch/Play-to-Earn System

#### 9.3.1 Advertising Integration

```typescript
interface AdvertisingSystem {
  loadRewardedAd: (placement: AdPlacement) => Promise<RewardedAd>;
  showRewardedAd: (adId: string) => Promise<AdReward>;
  trackAdEngagement: (adId: string, engagement: AdEngagement) => void;
  getAvailableAds: (userId: string) => Promise<AvailableAd[]>;
}

interface AdReward {
  type: 'wallet_credit' | 'xp' | 'discount' | 'feature_unlock';
  amount: number;
  description: string;
  expiresAt?: Date;
}

interface AdPlacement {
  location: 'dashboard' | 'trip_complete' | 'earnings' | 'social_feed';
  timing: 'immediate' | 'delayed' | 'user_initiated';
  frequency: 'once' | 'daily' | 'unlimited';
}
```

#### 9.3.2 Mini-Games Integration

```typescript
interface MiniGamesSystem {
  availableGames: MiniGame[];
  playGame: (gameId: string) => Promise<GameSession>;
  submitScore: (sessionId: string, score: number) => Promise<GameReward>;
  getLeaderboard: (gameId: string) => Promise<GameLeaderboard>;
}

interface MiniGame {
  id: string;
  name: string;
  description: string;
  type: 'puzzle' | 'trivia' | 'skill' | 'luck';
  playTime: number;
  rewardStructure: GameRewardStructure;
  dailyLimit: number;
}
```

---

## 10. Integração com IA e Personalização

### 10.1 IA Mãe - Sistema de Personalização

#### 10.1.1 AI Personalization Engine

```typescript
interface AIPersonalizationEngine {
  userProfile: UserProfile;
  behaviorAnalyzer: BehaviorAnalyzer;
  recommendationEngine: RecommendationEngine;
  adaptiveUI: AdaptiveUIManager;
}

interface UserProfile {
  drivingPatterns: DrivingPattern[];
  preferences: UserPreferences;
  personality: PersonalityProfile;
  goals: UserGoal[];
  achievements: Achievement[];
  socialBehavior: SocialBehaviorProfile;
}

interface BehaviorAnalyzer {
  analyzeDrivingBehavior: (trips: Trip[]) => DrivingInsights;
  analyzeAppUsage: (sessions: AppSession[]) => UsageInsights;
  analyzeSocialInteraction: (interactions: SocialInteraction[]) => SocialInsights;
  predictUserNeeds: (context: UserContext) => Prediction[];
}
```

#### 10.1.2 Adaptive Interface

```typescript
interface AdaptiveUIManager {
  customizeLayout: (userProfile: UserProfile) => LayoutConfiguration;
  personalizeContent: (content: Content[], userProfile: UserProfile) => Content[];
  optimizeWorkflow: (workflow: Workflow, userBehavior: UserBehavior) => Workflow;
  suggestFeatures: (userProfile: UserProfile) => FeatureSuggestion[];
}

interface LayoutConfiguration {
  primaryActions: string[];
  widgetPriority: WidgetPriority[];
  navigationStyle: 'tabs' | 'drawer' | 'bottom_nav';
  informationDensity: 'minimal' | 'standard' | 'detailed';
  colorScheme: 'auto' | 'light' | 'dark' | 'high_contrast';
}
```

### 10.2 Componentes de IA

#### 10.2.1 SmartDashboard Component

```typescript
interface SmartDashboardProps {
  userProfile: UserProfile;
  currentContext: UserContext;
  onLayoutChange: (layout: LayoutConfiguration) => void;
  onWidgetInteraction: (widget: string, interaction: string) => void;
}
```

#### 10.2.2 RecommendationCard Component

```typescript
interface RecommendationCardProps {
  recommendation: Recommendation;
  onAccept: () => void;
  onDismiss: () => void;
  onFeedback: (feedback: RecommendationFeedback) => void;
  showReasoning?: boolean;
}

interface Recommendation {
  id: string;
  type: 'route' | 'timing' | 'area' | 'feature' | 'goal';
  title: string;
  description: string;
  reasoning: string;
  confidence: number;
  potentialBenefit: string;
  actionRequired: boolean;
}
```

#### 10.2.3 InsightsPanel Component

```typescript
interface InsightsPanelProps {
  insights: Insight[];
  timeframe: 'daily' | 'weekly' | 'monthly';
  onInsightClick: (insight: Insight) => void;
  onRequestMoreInsights: () => void;
}

interface Insight {
  id: string;
  category: 'performance' | 'earnings' | 'efficiency' | 'safety' | 'social';
  title: string;
  description: string;
  impact: 'positive' | 'negative' | 'neutral';
  actionable: boolean;
  suggestedActions?: string[];
}
```

### 10.3 Machine Learning Integration

#### 10.3.1 Predictive Analytics

```typescript
interface PredictiveAnalytics {
  predictDemand: (location: Location, timeframe: TimeRange) => DemandPrediction;
  predictEarnings: (drivingPlan: DrivingPlan) => EarningsPrediction;
  predictOptimalRoutes: (origin: Location, timeOfDay: number) => RoutePrediction[];
  predictUserChurn: (userBehavior: UserBehavior) => ChurnPrediction;
}

interface DemandPrediction {
  location: Location;
  timeframe: TimeRange;
  demandLevel: number;
  confidence: number;
  factors: DemandFactor[];
  recommendations: string[];
}
```

#### 10.3.2 Real-time Optimization

```typescript
interface RealTimeOptimizer {
  optimizeRoute: (currentLocation: Location, destination: Location, constraints: RouteConstraints) => OptimizedRoute;
  optimizeSchedule: (availableTime: TimeSlot[], userGoals: UserGoal[]) => OptimizedSchedule;
  optimizeEarnings: (currentEarnings: number, timeRemaining: number, location: Location) => EarningsStrategy;
}
```

---

## Conclusão da Primeira Parte

Esta primeira seção do estudo de componentização apresentou a arquitetura fundamental e os componentes principais do aplicativo Run Driver. A estrutura proposta garante escalabilidade, manutenibilidade e uma experiência de usuário excepcional, incorporando as melhores práticas de desenvolvimento React e as especificações únicas do projeto.

Na próxima seção, abordaremos a estrutura de pastas detalhada, padrões de código, integração com MANUS.IM e especificações técnicas completas para implementação.



---

## 11. Estrutura de Pastas e Organização do Projeto

### 11.1 Arquitetura de Diretórios

A organização de pastas do Run Driver segue uma estrutura híbrida que combina organização por funcionalidade (feature-based) com separação por tipo de arquivo, proporcionando máxima clareza e facilidade de navegação para equipes de desenvolvimento de qualquer tamanho.

```
run-driver/
├── public/
│   ├── icons/
│   │   ├── manus-icons/          # Biblioteca de ícones MANUS.IM
│   │   ├── app-icons/            # Ícones específicos do app
│   │   └── favicons/             # Favicons e ícones PWA
│   ├── images/
│   │   ├── onboarding/           # Imagens do processo de cadastro
│   │   ├── gamification/         # Assets de gamificação
│   │   └── social/               # Imagens para rede social
│   ├── sounds/                   # Notificações sonoras
│   └── manifest.json             # PWA manifest
├── src/
│   ├── components/               # Componentes reutilizáveis
│   │   ├── atoms/                # Componentes atômicos
│   │   │   ├── Button/
│   │   │   │   ├── Button.tsx
│   │   │   │   ├── Button.test.tsx
│   │   │   │   ├── Button.stories.tsx
│   │   │   │   └── index.ts
│   │   │   ├── Input/
│   │   │   ├── Icon/
│   │   │   ├── Badge/
│   │   │   ├── Avatar/
│   │   │   └── ProgressBar/
│   │   ├── molecules/            # Componentes moleculares
│   │   │   ├── LoginForm/
│   │   │   ├── DocumentUpload/
│   │   │   ├── TripCard/
│   │   │   ├── EarningsCard/
│   │   │   └── MapControls/
│   │   ├── organisms/            # Componentes organismos
│   │   │   ├── MapContainer/
│   │   │   ├── AuthenticationFlow/
│   │   │   ├── GamificationDashboard/
│   │   │   ├── SocialFeed/
│   │   │   └── WalletDashboard/
│   │   ├── templates/            # Templates de página
│   │   │   ├── MainLayout/
│   │   │   ├── AuthLayout/
│   │   │   └── OnboardingLayout/
│   │   └── ui/                   # Componentes Shadcn UI customizados
│   │       ├── button.tsx
│   │       ├── input.tsx
│   │       ├── modal.tsx
│   │       └── ...
│   ├── features/                 # Funcionalidades por domínio
│   │   ├── authentication/
│   │   │   ├── components/
│   │   │   │   ├── BiometricAuth/
│   │   │   │   ├── DocumentVerification/
│   │   │   │   └── OnboardingWizard/
│   │   │   ├── hooks/
│   │   │   │   ├── useAuth.ts
│   │   │   │   ├── useBiometric.ts
│   │   │   │   └── useDocumentUpload.ts
│   │   │   ├── services/
│   │   │   │   ├── authService.ts
│   │   │   │   ├── biometricService.ts
│   │   │   │   └── documentService.ts
│   │   │   ├── stores/
│   │   │   │   └── authStore.ts
│   │   │   ├── types/
│   │   │   │   └── auth.types.ts
│   │   │   └── utils/
│   │   │       ├── validation.ts
│   │   │       └── encryption.ts
│   │   ├── maps/
│   │   │   ├── components/
│   │   │   │   ├── LeafletMap/
│   │   │   │   ├── DriverMarker/
│   │   │   │   ├── RouteDisplay/
│   │   │   │   └── GeofenceManager/
│   │   │   ├── hooks/
│   │   │   │   ├── useLocation.ts
│   │   │   │   ├── useRoute.ts
│   │   │   │   └── useGeofencing.ts
│   │   │   ├── services/
│   │   │   │   ├── mapService.ts
│   │   │   │   ├── geocodingService.ts
│   │   │   │   └── routingService.ts
│   │   │   ├── stores/
│   │   │   │   └── locationStore.ts
│   │   │   └── types/
│   │   │       └── maps.types.ts
│   │   ├── trips/
│   │   │   ├── components/
│   │   │   │   ├── TripRequestModal/
│   │   │   │   ├── TripProgress/
│   │   │   │   ├── TripHistory/
│   │   │   │   └── TripRating/
│   │   │   ├── hooks/
│   │   │   │   ├── useTrips.ts
│   │   │   │   ├── useTripRequests.ts
│   │   │   │   └── useTripNavigation.ts
│   │   │   ├── services/
│   │   │   │   ├── tripService.ts
│   │   │   │   └── navigationService.ts
│   │   │   ├── stores/
│   │   │   │   └── tripStore.ts
│   │   │   └── types/
│   │   │       └── trips.types.ts
│   │   ├── gamification/
│   │   │   ├── components/
│   │   │   │   ├── LevelProgress/
│   │   │   │   ├── AchievementCard/
│   │   │   │   ├── Leaderboard/
│   │   │   │   └── RewardModal/
│   │   │   ├── hooks/
│   │   │   │   ├── useAchievements.ts
│   │   │   │   ├── useLeaderboard.ts
│   │   │   │   └── useRewards.ts
│   │   │   ├── services/
│   │   │   │   ├── achievementService.ts
│   │   │   │   └── rewardService.ts
│   │   │   ├── stores/
│   │   │   │   └── gamificationStore.ts
│   │   │   └── types/
│   │   │       └── gamification.types.ts
│   │   ├── social/
│   │   │   ├── components/
│   │   │   │   ├── SocialFeed/
│   │   │   │   ├── PostCreator/
│   │   │   │   ├── DriverProfile/
│   │   │   │   ├── GroupChat/
│   │   │   │   └── FriendsList/
│   │   │   ├── hooks/
│   │   │   │   ├── useSocialFeed.ts
│   │   │   │   ├── useConnections.ts
│   │   │   │   └── useMessaging.ts
│   │   │   ├── services/
│   │   │   │   ├── socialService.ts
│   │   │   │   ├── messagingService.ts
│   │   │   │   └── moderationService.ts
│   │   │   ├── stores/
│   │   │   │   └── socialStore.ts
│   │   │   └── types/
│   │   │       └── social.types.ts
│   │   ├── payments/
│   │   │   ├── components/
│   │   │   │   ├── WalletDashboard/
│   │   │   │   ├── EarningsChart/
│   │   │   │   ├── PaymentMethods/
│   │   │   │   └── TransactionHistory/
│   │   │   ├── hooks/
│   │   │   │   ├── useWallet.ts
│   │   │   │   ├── useEarnings.ts
│   │   │   │   └── usePayments.ts
│   │   │   ├── services/
│   │   │   │   ├── stripeService.ts
│   │   │   │   ├── pixService.ts
│   │   │   │   └── walletService.ts
│   │   │   ├── stores/
│   │   │   │   └── paymentStore.ts
│   │   │   └── types/
│   │   │       └── payments.types.ts
│   │   ├── ai-personalization/
│   │   │   ├── components/
│   │   │   │   ├── SmartDashboard/
│   │   │   │   ├── RecommendationCard/
│   │   │   │   ├── InsightsPanel/
│   │   │   │   └── AdaptiveInterface/
│   │   │   ├── hooks/
│   │   │   │   ├── usePersonalization.ts
│   │   │   │   ├── useRecommendations.ts
│   │   │   │   └── useInsights.ts
│   │   │   ├── services/
│   │   │   │   ├── aiService.ts
│   │   │   │   ├── analyticsService.ts
│   │   │   │   └── recommendationService.ts
│   │   │   ├── stores/
│   │   │   │   └── aiStore.ts
│   │   │   └── types/
│   │   │       └── ai.types.ts
│   │   └── advertising/
│   │       ├── components/
│   │       │   ├── RewardedAdModal/
│   │       │   ├── MiniGameContainer/
│   │       │   ├── AdBanner/
│   │       │   └── EarningSummary/
│   │       ├── hooks/
│   │       │   ├── useRewardedAds.ts
│   │       │   ├── useMiniGames.ts
│   │       │   └── useAdRewards.ts
│   │       ├── services/
│   │       │   ├── adService.ts
│   │       │   └── gameService.ts
│   │       ├── stores/
│   │       │   └── advertisingStore.ts
│   │       └── types/
│   │           └── advertising.types.ts
│   ├── pages/                    # Páginas da aplicação
│   │   ├── Dashboard/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Dashboard.test.tsx
│   │   │   └── index.ts
│   │   ├── Login/
│   │   ├── Register/
│   │   ├── Profile/
│   │   ├── Earnings/
│   │   ├── Social/
│   │   ├── Settings/
│   │   └── Onboarding/
│   ├── hooks/                    # Hooks globais reutilizáveis
│   │   ├── useLocalStorage.ts
│   │   ├── useDebounce.ts
│   │   ├── useIntersectionObserver.ts
│   │   ├── useWebSocket.ts
│   │   ├── useNotifications.ts
│   │   └── useTheme.ts
│   ├── services/                 # Serviços globais
│   │   ├── api/
│   │   │   ├── client.ts         # Cliente HTTP configurado
│   │   │   ├── endpoints.ts      # Definição de endpoints
│   │   │   └── interceptors.ts   # Interceptadores de request/response
│   │   ├── storage/
│   │   │   ├── localStorage.ts
│   │   │   ├── sessionStorage.ts
│   │   │   └── secureStorage.ts
│   │   ├── notifications/
│   │   │   ├── pushNotifications.ts
│   │   │   ├── inAppNotifications.ts
│   │   │   └── emailNotifications.ts
│   │   ├── analytics/
│   │   │   ├── googleAnalytics.ts
│   │   │   ├── mixpanel.ts
│   │   │   └── customAnalytics.ts
│   │   └── websocket/
│   │       ├── socketClient.ts
│   │       └── socketHandlers.ts
│   ├── stores/                   # Stores Zustand globais
│   │   ├── index.ts              # Store principal combinado
│   │   ├── appStore.ts           # Estado global da aplicação
│   │   ├── uiStore.ts            # Estado da interface
│   │   └── settingsStore.ts      # Configurações do usuário
│   ├── utils/                    # Utilitários e helpers
│   │   ├── constants/
│   │   │   ├── api.ts
│   │   │   ├── routes.ts
│   │   │   ├── storage.ts
│   │   │   └── theme.ts
│   │   ├── formatters/
│   │   │   ├── currency.ts
│   │   │   ├── date.ts
│   │   │   ├── distance.ts
│   │   │   └── phone.ts
│   │   ├── validators/
│   │   │   ├── auth.ts
│   │   │   ├── documents.ts
│   │   │   ├── vehicle.ts
│   │   │   └── common.ts
│   │   ├── helpers/
│   │   │   ├── calculations.ts
│   │   │   ├── permissions.ts
│   │   │   ├── device.ts
│   │   │   └── location.ts
│   │   └── types/
│   │       ├── global.types.ts
│   │       ├── api.types.ts
│   │       └── common.types.ts
│   ├── styles/                   # Estilos globais e temas
│   │   ├── globals.css           # Estilos globais base
│   │   ├── components.css        # Estilos de componentes
│   │   ├── themes/
│   │   │   ├── manus-light.css   # Tema claro MANUS.IM
│   │   │   ├── manus-dark.css    # Tema escuro MANUS.IM
│   │   │   └── variables.css     # Variáveis CSS customizadas
│   │   └── animations/
│   │       ├── transitions.css
│   │       ├── keyframes.css
│   │       └── micro-interactions.css
│   ├── assets/                   # Assets estáticos
│   │   ├── images/
│   │   │   ├── logos/
│   │   │   ├── illustrations/
│   │   │   └── backgrounds/
│   │   ├── fonts/
│   │   │   └── manus-fonts/      # Fontes MANUS.IM
│   │   └── videos/
│   │       └── onboarding/
│   ├── config/                   # Configurações
│   │   ├── env.ts                # Variáveis de ambiente
│   │   ├── database.ts           # Configuração de banco local
│   │   ├── analytics.ts          # Configuração de analytics
│   │   └── features.ts           # Feature flags
│   ├── lib/                      # Bibliotecas e configurações externas
│   │   ├── shadcn.ts            # Configuração Shadcn UI
│   │   ├── tailwind.ts          # Configuração Tailwind
│   │   ├── react-query.ts       # Configuração TanStack Query
│   │   ├── zustand.ts           # Configuração Zustand
│   │   └── leaflet.ts           # Configuração React Leaflet
│   ├── App.tsx                   # Componente raiz
│   ├── main.tsx                  # Ponto de entrada
│   └── vite-env.d.ts            # Tipos do Vite
├── tests/                        # Testes
│   ├── __mocks__/               # Mocks para testes
│   ├── fixtures/                # Dados de teste
│   ├── integration/             # Testes de integração
│   ├── e2e/                     # Testes end-to-end
│   └── utils/                   # Utilitários de teste
├── docs/                         # Documentação
│   ├── components/              # Documentação de componentes
│   ├── features/                # Documentação de funcionalidades
│   ├── api/                     # Documentação de API
│   └── deployment/              # Guias de deploy
├── .storybook/                   # Configuração Storybook
├── tailwind.config.js           # Configuração Tailwind CSS
├── vite.config.ts               # Configuração Vite
├── tsconfig.json                # Configuração TypeScript
├── package.json                 # Dependências e scripts
└── README.md                    # Documentação principal
```

### 11.2 Convenções de Nomenclatura

#### 11.2.1 Arquivos e Pastas

**Componentes:** Utilizam PascalCase para nomes de arquivos e pastas, refletindo a convenção React padrão. Cada componente possui sua própria pasta com arquivos organizados de forma consistente.

```typescript
// Estrutura padrão de componente
ComponentName/
├── ComponentName.tsx      // Implementação principal
├── ComponentName.test.tsx // Testes unitários
├── ComponentName.stories.tsx // Storybook stories
├── ComponentName.module.css // Estilos específicos (se necessário)
└── index.ts              // Barrel export
```

**Hooks:** Seguem a convenção `use` + funcionalidade em camelCase, organizados por escopo (global vs feature-specific).

```typescript
// Hooks globais
useLocalStorage.ts
useDebounce.ts
useWebSocket.ts

// Hooks específicos de feature
features/authentication/hooks/useAuth.ts
features/maps/hooks/useLocation.ts
features/trips/hooks/useTrips.ts
```

**Serviços:** Utilizam camelCase com sufixo "Service" para clareza funcional.

```typescript
authService.ts
mapService.ts
paymentService.ts
notificationService.ts
```

**Stores:** Seguem padrão camelCase com sufixo "Store" para identificação imediata.

```typescript
authStore.ts
locationStore.ts
tripStore.ts
gamificationStore.ts
```

#### 11.2.2 Variáveis e Funções

**Constantes:** Utilizam SCREAMING_SNAKE_CASE para constantes globais e configurações.

```typescript
// constants/api.ts
export const API_BASE_URL = 'https://api.rundriver.com';
export const WEBSOCKET_URL = 'wss://ws.rundriver.com';
export const MAX_UPLOAD_SIZE = 10 * 1024 * 1024; // 10MB
export const SUPPORTED_IMAGE_FORMATS = ['jpg', 'jpeg', 'png', 'webp'];
```

**Interfaces e Types:** Utilizam PascalCase com sufixos descritivos quando apropriado.

```typescript
// Interfaces principais
interface User { }
interface Trip { }
interface Achievement { }

// Props de componentes
interface ButtonProps { }
interface MapContainerProps { }

// Tipos de dados
type UserStatus = 'online' | 'offline' | 'busy';
type PaymentMethod = 'credit_card' | 'pix' | 'wallet';
```

### 11.3 Padrões de Importação e Exportação

#### 11.3.1 Barrel Exports

Cada pasta de componente e feature utiliza arquivos `index.ts` para centralizar exportações, simplificando importações e mantendo a API limpa.

```typescript
// components/atoms/Button/index.ts
export { default as Button } from './Button';
export type { ButtonProps } from './Button';

// components/atoms/index.ts
export * from './Button';
export * from './Input';
export * from './Icon';
export * from './Badge';

// features/authentication/index.ts
export * from './components';
export * from './hooks';
export * from './services';
export * from './types';
```

#### 11.3.2 Importações Organizadas

As importações seguem uma ordem específica para manter consistência e legibilidade:

```typescript
// 1. Bibliotecas externas
import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MapContainer, TileLayer } from 'react-leaflet';

// 2. Componentes internos (absolutos)
import { Button, Input, Modal } from '@/components/atoms';
import { TripCard, EarningsCard } from '@/components/molecules';
import { MapContainer as CustomMapContainer } from '@/components/organisms';

// 3. Hooks e serviços
import { useAuth } from '@/features/authentication';
import { useLocation } from '@/features/maps';
import { tripService } from '@/services';

// 4. Tipos e interfaces
import type { User, Trip, Location } from '@/types';

// 5. Utilitários e constantes
import { formatCurrency, calculateDistance } from '@/utils';
import { API_ENDPOINTS } from '@/constants';

// 6. Estilos (sempre por último)
import './ComponentName.module.css';
```

### 11.4 Configuração de Path Mapping

O projeto utiliza path mapping para simplificar importações e melhorar a manutenibilidade do código:

```typescript
// tsconfig.json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"],
      "@/components/*": ["src/components/*"],
      "@/features/*": ["src/features/*"],
      "@/hooks/*": ["src/hooks/*"],
      "@/services/*": ["src/services/*"],
      "@/stores/*": ["src/stores/*"],
      "@/utils/*": ["src/utils/*"],
      "@/types/*": ["src/utils/types/*"],
      "@/constants/*": ["src/utils/constants/*"],
      "@/assets/*": ["src/assets/*"],
      "@/styles/*": ["src/styles/*"]
    }
  }
}

// vite.config.ts
export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@/components': path.resolve(__dirname, './src/components'),
      '@/features': path.resolve(__dirname, './src/features'),
      '@/hooks': path.resolve(__dirname, './src/hooks'),
      '@/services': path.resolve(__dirname, './src/services'),
      '@/stores': path.resolve(__dirname, './src/stores'),
      '@/utils': path.resolve(__dirname, './src/utils'),
      '@/types': path.resolve(__dirname, './src/utils/types'),
      '@/constants': path.resolve(__dirname, './src/utils/constants'),
      '@/assets': path.resolve(__dirname, './src/assets'),
      '@/styles': path.resolve(__dirname, './src/styles')
    }
  }
});
```

### 11.5 Organização de Estilos e Temas

#### 11.5.1 Sistema de Temas MANUS.IM

A integração com a identidade visual do MANUS.IM é implementada através de um sistema robusto de variáveis CSS e configuração Tailwind personalizada:

```css
/* styles/themes/variables.css */
:root {
  /* Cores primárias MANUS.IM */
  --manus-primary-50: #f0f9ff;
  --manus-primary-100: #e0f2fe;
  --manus-primary-200: #bae6fd;
  --manus-primary-300: #7dd3fc;
  --manus-primary-400: #38bdf8;
  --manus-primary-500: #0ea5e9;
  --manus-primary-600: #0284c7;
  --manus-primary-700: #0369a1;
  --manus-primary-800: #075985;
  --manus-primary-900: #0c4a6e;

  /* Gradientes característicos */
  --manus-gradient-primary: linear-gradient(135deg, var(--manus-primary-500) 0%, var(--manus-primary-700) 100%);
  --manus-gradient-secondary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  
  /* Cores semânticas */
  --color-success: #10b981;
  --color-warning: #f59e0b;
  --color-error: #ef4444;
  --color-info: var(--manus-primary-500);
  
  /* Tipografia */
  --font-family-primary: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  --font-family-heading: 'Poppins', var(--font-family-primary);
  
  /* Espaçamento */
  --spacing-xs: 0.25rem;
  --spacing-sm: 0.5rem;
  --spacing-md: 1rem;
  --spacing-lg: 1.5rem;
  --spacing-xl: 2rem;
  --spacing-2xl: 3rem;
  
  /* Bordas e sombras */
  --border-radius-sm: 0.375rem;
  --border-radius-md: 0.5rem;
  --border-radius-lg: 0.75rem;
  --border-radius-xl: 1rem;
  
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
  --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
  --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
}

/* Tema escuro */
[data-theme="dark"] {
  --manus-primary-50: #0c4a6e;
  --manus-primary-100: #075985;
  --manus-primary-200: #0369a1;
  --manus-primary-300: #0284c7;
  --manus-primary-400: #0ea5e9;
  --manus-primary-500: #38bdf8;
  --manus-primary-600: #7dd3fc;
  --manus-primary-700: #bae6fd;
  --manus-primary-800: #e0f2fe;
  --manus-primary-900: #f0f9ff;
  
  /* Ajustes para modo escuro */
  --background-primary: #0f172a;
  --background-secondary: #1e293b;
  --text-primary: #f8fafc;
  --text-secondary: #cbd5e1;
}
```

#### 11.5.2 Configuração Tailwind Personalizada

```javascript
// tailwind.config.js
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        manus: {
          50: 'var(--manus-primary-50)',
          100: 'var(--manus-primary-100)',
          200: 'var(--manus-primary-200)',
          300: 'var(--manus-primary-300)',
          400: 'var(--manus-primary-400)',
          500: 'var(--manus-primary-500)',
          600: 'var(--manus-primary-600)',
          700: 'var(--manus-primary-700)',
          800: 'var(--manus-primary-800)',
          900: 'var(--manus-primary-900)',
        },
        success: 'var(--color-success)',
        warning: 'var(--color-warning)',
        error: 'var(--color-error)',
        info: 'var(--color-info)',
      },
      fontFamily: {
        sans: ['var(--font-family-primary)'],
        heading: ['var(--font-family-heading)'],
      },
      spacing: {
        xs: 'var(--spacing-xs)',
        sm: 'var(--spacing-sm)',
        md: 'var(--spacing-md)',
        lg: 'var(--spacing-lg)',
        xl: 'var(--spacing-xl)',
        '2xl': 'var(--spacing-2xl)',
      },
      borderRadius: {
        sm: 'var(--border-radius-sm)',
        md: 'var(--border-radius-md)',
        lg: 'var(--border-radius-lg)',
        xl: 'var(--border-radius-xl)',
      },
      boxShadow: {
        sm: 'var(--shadow-sm)',
        md: 'var(--shadow-md)',
        lg: 'var(--shadow-lg)',
        xl: 'var(--shadow-xl)',
      },
      backgroundImage: {
        'manus-gradient': 'var(--manus-gradient-primary)',
        'manus-gradient-secondary': 'var(--manus-gradient-secondary)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'scale-in': 'scaleIn 0.2s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(100%)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
    require('@tailwindcss/aspect-ratio'),
  ],
};
```

### 11.6 Configuração de Desenvolvimento

#### 11.6.1 Scripts de Desenvolvimento

```json
{
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "test": "vitest",
    "test:ui": "vitest --ui",
    "test:coverage": "vitest --coverage",
    "test:e2e": "playwright test",
    "lint": "eslint src --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "lint:fix": "eslint src --ext ts,tsx --fix",
    "type-check": "tsc --noEmit",
    "storybook": "storybook dev -p 6006",
    "build-storybook": "storybook build",
    "analyze": "vite-bundle-analyzer",
    "clean": "rimraf dist node_modules/.vite",
    "prepare": "husky install"
  }
}
```

#### 11.6.2 Configuração de Qualidade de Código

```javascript
// .eslintrc.js
module.exports = {
  extends: [
    '@typescript-eslint/recommended',
    'plugin:react/recommended',
    'plugin:react-hooks/recommended',
    'plugin:jsx-a11y/recommended',
    'prettier'
  ],
  plugins: ['@typescript-eslint', 'react', 'react-hooks', 'jsx-a11y'],
  rules: {
    'react/react-in-jsx-scope': 'off',
    'react/prop-types': 'off',
    '@typescript-eslint/explicit-function-return-type': 'off',
    '@typescript-eslint/explicit-module-boundary-types': 'off',
    '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
    'jsx-a11y/anchor-is-valid': 'off',
    'react-hooks/exhaustive-deps': 'warn'
  },
  settings: {
    react: {
      version: 'detect'
    }
  }
};

// prettier.config.js
module.exports = {
  semi: true,
  trailingComma: 'es5',
  singleQuote: true,
  printWidth: 80,
  tabWidth: 2,
  useTabs: false,
  bracketSpacing: true,
  arrowParens: 'avoid',
  endOfLine: 'lf'
};
```

### 11.7 Estratégia de Testes

#### 11.7.1 Estrutura de Testes

```
tests/
├── __mocks__/                    # Mocks globais
│   ├── leaflet.ts               # Mock do Leaflet
│   ├── geolocation.ts           # Mock de geolocalização
│   ├── stripe.ts                # Mock do Stripe
│   └── websocket.ts             # Mock de WebSocket
├── fixtures/                     # Dados de teste
│   ├── users.ts                 # Usuários de teste
│   ├── trips.ts                 # Viagens de teste
│   ├── achievements.ts          # Conquistas de teste
│   └── locations.ts             # Localizações de teste
├── integration/                  # Testes de integração
│   ├── authentication.test.ts
│   ├── trip-flow.test.ts
│   ├── payment-flow.test.ts
│   └── social-features.test.ts
├── e2e/                         # Testes end-to-end
│   ├── onboarding.spec.ts
│   ├── trip-request.spec.ts
│   ├── earnings.spec.ts
│   └── social-interaction.spec.ts
└── utils/                       # Utilitários de teste
    ├── test-utils.tsx           # Wrapper de testes
    ├── mock-providers.tsx       # Providers mockados
    └── test-helpers.ts          # Funções auxiliares
```

#### 11.7.2 Configuração de Testes

```typescript
// tests/utils/test-utils.tsx
import React, { ReactElement } from 'react';
import { render, RenderOptions } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import { ThemeProvider } from '@/contexts/ThemeContext';

const AllTheProviders = ({ children }: { children: React.ReactNode }) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <ThemeProvider>
          {children}
        </ThemeProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
};

const customRender = (
  ui: ReactElement,
  options?: Omit<RenderOptions, 'wrapper'>
) => render(ui, { wrapper: AllTheProviders, ...options });

export * from '@testing-library/react';
export { customRender as render };
```

---

## 12. Padrões de Código e Melhores Práticas

### 12.1 Padrões de Componentes React

#### 12.1.1 Estrutura Padrão de Componente

Todos os componentes do Run Driver seguem uma estrutura consistente que promove legibilidade, manutenibilidade e testabilidade:

```typescript
// components/atoms/Button/Button.tsx
import React, { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/utils/cn';
import { Icon } from '@/components/atoms/Icon';
import type { ButtonHTMLAttributes } from 'react';

// Definição de variantes usando CVA
const buttonVariants = cva(
  // Classes base
  'inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background',
  {
    variants: {
      variant: {
        default: 'bg-primary text-primary-foreground hover:bg-primary/90',
        destructive: 'bg-destructive text-destructive-foreground hover:bg-destructive/90',
        outline: 'border border-input hover:bg-accent hover:text-accent-foreground',
        secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
        ghost: 'hover:bg-accent hover:text-accent-foreground',
        link: 'underline-offset-4 hover:underline text-primary',
        'manus-gradient': 'bg-manus-gradient text-white hover:opacity-90',
      },
      size: {
        default: 'h-10 py-2 px-4',
        sm: 'h-9 px-3 rounded-md',
        lg: 'h-11 px-8 rounded-md',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
);

// Interface de props com documentação JSDoc
interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  /** Conteúdo do botão */
  children: React.ReactNode;
  /** Estado de carregamento */
  loading?: boolean;
  /** Ícone a ser exibido */
  icon?: string;
  /** Posição do ícone */
  iconPosition?: 'left' | 'right';
  /** Ocupar toda a largura disponível */
  fullWidth?: boolean;
}

// Componente com forwardRef para compatibilidade com bibliotecas
const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      children,
      loading = false,
      icon,
      iconPosition = 'left',
      fullWidth = false,
      disabled,
      ...props
    },
    ref
  ) => {
    const isDisabled = disabled || loading;

    return (
      <button
        className={cn(
          buttonVariants({ variant, size, className }),
          fullWidth && 'w-full'
        )}
        ref={ref}
        disabled={isDisabled}
        {...props}
      >
        {loading && (
          <Icon
            name="loader-2"
            className="mr-2 h-4 w-4 animate-spin"
            aria-hidden="true"
          />
        )}
        {icon && iconPosition === 'left' && !loading && (
          <Icon
            name={icon}
            className="mr-2 h-4 w-4"
            aria-hidden="true"
          />
        )}
        {children}
        {icon && iconPosition === 'right' && !loading && (
          <Icon
            name={icon}
            className="ml-2 h-4 w-4"
            aria-hidden="true"
          />
        )}
      </button>
    );
  }
);

Button.displayName = 'Button';

export { Button, buttonVariants };
export type { ButtonProps };
```

#### 12.1.2 Hooks Customizados

Os hooks customizados encapsulam lógica reutilizável e seguem padrões consistentes:

```typescript
// features/authentication/hooks/useAuth.ts
import { useCallback, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/features/authentication/stores/authStore';
import { authService } from '@/features/authentication/services/authService';
import { useNotifications } from '@/hooks/useNotifications';
import type { LoginCredentials, User, AuthError } from '@/features/authentication/types';

interface UseAuthReturn {
  // Estado
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: AuthError | null;
  
  // Ações
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => Promise<void>;
  refreshSession: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  
  // Utilitários
  hasPermission: (permission: string) => boolean;
  isFeatureEnabled: (feature: string) => boolean;
}

export const useAuth = (): UseAuthReturn => {
  const queryClient = useQueryClient();
  const { showNotification } = useNotifications();
  
  // Estado do store
  const {
    user,
    isAuthenticated,
    setUser,
    setAuthenticated,
    clearAuth,
  } = useAuthStore();

  // Query para dados do usuário
  const {
    data: userData,
    isLoading: isUserLoading,
    error: userError,
  } = useQuery({
    queryKey: ['user'],
    queryFn: authService.getCurrentUser,
    enabled: isAuthenticated,
    staleTime: 5 * 60 * 1000, // 5 minutos
    retry: (failureCount, error) => {
      // Não tentar novamente se for erro de autenticação
      if (error.status === 401) return false;
      return failureCount < 3;
    },
  });

  // Mutation para login
  const loginMutation = useMutation({
    mutationFn: authService.login,
    onSuccess: (data) => {
      setUser(data.user);
      setAuthenticated(true);
      queryClient.setQueryData(['user'], data.user);
      showNotification({
        type: 'success',
        title: 'Login realizado com sucesso',
        message: `Bem-vindo de volta, ${data.user.name}!`,
      });
    },
    onError: (error: AuthError) => {
      showNotification({
        type: 'error',
        title: 'Erro no login',
        message: error.message || 'Credenciais inválidas',
      });
    },
  });

  // Mutation para logout
  const logoutMutation = useMutation({
    mutationFn: authService.logout,
    onSuccess: () => {
      clearAuth();
      queryClient.clear();
      showNotification({
        type: 'info',
        title: 'Logout realizado',
        message: 'Você foi desconectado com sucesso',
      });
    },
  });

  // Mutation para atualização de perfil
  const updateProfileMutation = useMutation({
    mutationFn: authService.updateProfile,
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      queryClient.setQueryData(['user'], updatedUser);
      showNotification({
        type: 'success',
        title: 'Perfil atualizado',
        message: 'Suas informações foram salvas com sucesso',
      });
    },
  });

  // Função para verificar permissões
  const hasPermission = useCallback(
    (permission: string): boolean => {
      if (!user?.permissions) return false;
      return user.permissions.includes(permission);
    },
    [user?.permissions]
  );

  // Função para verificar features habilitadas
  const isFeatureEnabled = useCallback(
    (feature: string): boolean => {
      if (!user?.features) return false;
      return user.features[feature] === true;
    },
    [user?.features]
  );

  // Atualizar store quando dados do usuário mudarem
  useEffect(() => {
    if (userData && !user) {
      setUser(userData);
    }
  }, [userData, user, setUser]);

  // Funções de ação
  const login = useCallback(
    async (credentials: LoginCredentials) => {
      await loginMutation.mutateAsync(credentials);
    },
    [loginMutation]
  );

  const logout = useCallback(async () => {
    await logoutMutation.mutateAsync();
  }, [logoutMutation]);

  const refreshSession = useCallback(async () => {
    await queryClient.invalidateQueries({ queryKey: ['user'] });
  }, [queryClient]);

  const updateProfile = useCallback(
    async (data: Partial<User>) => {
      await updateProfileMutation.mutateAsync(data);
    },
    [updateProfileMutation]
  );

  return {
    // Estado
    user,
    isAuthenticated,
    isLoading: isUserLoading || loginMutation.isPending || logoutMutation.isPending,
    error: userError || loginMutation.error || logoutMutation.error,
    
    // Ações
    login,
    logout,
    refreshSession,
    updateProfile,
    
    // Utilitários
    hasPermission,
    isFeatureEnabled,
  };
};
```

#### 12.1.3 Gerenciamento de Estado com Zustand

Os stores Zustand seguem padrões consistentes para organização e type safety:

```typescript
// features/authentication/stores/authStore.ts
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type { User, AuthState, BiometricSettings } from '@/features/authentication/types';

interface AuthStore extends AuthState {
  // Ações de autenticação
  setUser: (user: User | null) => void;
  setAuthenticated: (authenticated: boolean) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearAuth: () => void;
  
  // Ações de biometria
  setBiometricEnabled: (enabled: boolean) => void;
  updateBiometricSettings: (settings: Partial<BiometricSettings>) => void;
  
  // Ações de sessão
  updateSessionToken: (token: string) => void;
  updateRefreshToken: (token: string) => void;
  extendSession: () => void;
  
  // Ações de permissões
  updatePermissions: (permissions: string[]) => void;
  addPermission: (permission: string) => void;
  removePermission: (permission: string) => void;
}

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
  sessionToken: null,
  refreshToken: null,
  biometricEnabled: false,
  biometricSettings: {
    fingerprint: false,
    faceId: false,
    voiceRecognition: false,
    fallbackToPin: true,
  },
  permissions: [],
  lastActivity: null,
  sessionExpiresAt: null,
};

export const useAuthStore = create<AuthStore>()(
  devtools(
    persist(
      immer((set, get) => ({
        ...initialState,

        // Ações de autenticação
        setUser: (user) =>
          set((state) => {
            state.user = user;
            state.lastActivity = new Date().toISOString();
          }),

        setAuthenticated: (authenticated) =>
          set((state) => {
            state.isAuthenticated = authenticated;
            if (!authenticated) {
              state.user = null;
              state.sessionToken = null;
              state.refreshToken = null;
              state.permissions = [];
            }
          }),

        setLoading: (loading) =>
          set((state) => {
            state.isLoading = loading;
          }),

        setError: (error) =>
          set((state) => {
            state.error = error;
          }),

        clearAuth: () =>
          set((state) => {
            Object.assign(state, {
              ...initialState,
              biometricEnabled: state.biometricEnabled,
              biometricSettings: state.biometricSettings,
            });
          }),

        // Ações de biometria
        setBiometricEnabled: (enabled) =>
          set((state) => {
            state.biometricEnabled = enabled;
          }),

        updateBiometricSettings: (settings) =>
          set((state) => {
            Object.assign(state.biometricSettings, settings);
          }),

        // Ações de sessão
        updateSessionToken: (token) =>
          set((state) => {
            state.sessionToken = token;
            state.lastActivity = new Date().toISOString();
          }),

        updateRefreshToken: (token) =>
          set((state) => {
            state.refreshToken = token;
          }),

        extendSession: () =>
          set((state) => {
            const now = new Date();
            state.sessionExpiresAt = new Date(
              now.getTime() + 24 * 60 * 60 * 1000 // 24 horas
            ).toISOString();
            state.lastActivity = now.toISOString();
          }),

        // Ações de permissões
        updatePermissions: (permissions) =>
          set((state) => {
            state.permissions = permissions;
          }),

        addPermission: (permission) =>
          set((state) => {
            if (!state.permissions.includes(permission)) {
              state.permissions.push(permission);
            }
          }),

        removePermission: (permission) =>
          set((state) => {
            state.permissions = state.permissions.filter(p => p !== permission);
          }),
      })),
      {
        name: 'auth-storage',
        partialize: (state) => ({
          user: state.user,
          isAuthenticated: state.isAuthenticated,
          sessionToken: state.sessionToken,
          refreshToken: state.refreshToken,
          biometricEnabled: state.biometricEnabled,
          biometricSettings: state.biometricSettings,
          permissions: state.permissions,
        }),
      }
    ),
    {
      name: 'auth-store',
    }
  )
);

// Seletores para otimização de performance
export const useAuthUser = () => useAuthStore((state) => state.user);
export const useAuthStatus = () => useAuthStore((state) => ({
  isAuthenticated: state.isAuthenticated,
  isLoading: state.isLoading,
  error: state.error,
}));
export const useBiometricSettings = () => useAuthStore((state) => ({
  enabled: state.biometricEnabled,
  settings: state.biometricSettings,
}));
```

### 12.2 Padrões de Performance

#### 12.2.1 Otimização de Renderização

```typescript
// Exemplo de componente otimizado para performance
import React, { memo, useMemo, useCallback } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { TripCard } from '@/components/molecules/TripCard';
import type { Trip } from '@/features/trips/types';

interface TripListProps {
  trips: Trip[];
  onTripSelect: (trip: Trip) => void;
  loading?: boolean;
  searchQuery?: string;
}

const TripList = memo<TripListProps>(({
  trips,
  onTripSelect,
  loading = false,
  searchQuery = '',
}) => {
  // Filtrar viagens baseado na busca
  const filteredTrips = useMemo(() => {
    if (!searchQuery) return trips;
    
    return trips.filter(trip =>
      trip.passenger.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trip.destination.address.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [trips, searchQuery]);

  // Callback memoizado para seleção de viagem
  const handleTripSelect = useCallback(
    (trip: Trip) => {
      onTripSelect(trip);
    },
    [onTripSelect]
  );

  // Virtualização para listas grandes
  const parentRef = React.useRef<HTMLDivElement>(null);
  
  const virtualizer = useVirtualizer({
    count: filteredTrips.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 120, // Altura estimada de cada item
    overscan: 5, // Renderizar 5 itens extras para suavidade
  });

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, index) => (
          <div
            key={index}
            className="h-24 bg-gray-200 rounded-lg animate-pulse"
          />
        ))}
      </div>
    );
  }

  return (
    <div
      ref={parentRef}
      className="h-96 overflow-auto"
      style={{ contain: 'strict' }}
    >
      <div
        style={{
          height: `${virtualizer.getTotalSize()}px`,
          width: '100%',
          position: 'relative',
        }}
      >
        {virtualizer.getVirtualItems().map((virtualItem) => {
          const trip = filteredTrips[virtualItem.index];
          
          return (
            <div
              key={virtualItem.key}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: `${virtualItem.size}px`,
                transform: `translateY(${virtualItem.start}px)`,
              }}
            >
              <TripCard
                trip={trip}
                onSelect={() => handleTripSelect(trip)}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
});

TripList.displayName = 'TripList';

export { TripList };
```

#### 12.2.2 Lazy Loading e Code Splitting

```typescript
// Lazy loading de páginas
import { lazy, Suspense } from 'react';
import { LoadingSpinner } from '@/components/atoms/LoadingSpinner';

// Páginas carregadas sob demanda
const Dashboard = lazy(() => import('@/pages/Dashboard'));
const Profile = lazy(() => import('@/pages/Profile'));
const Earnings = lazy(() => import('@/pages/Earnings'));
const Social = lazy(() => import('@/pages/Social'));

// Componente de loading personalizado
const PageLoader = () => (
  <div className="flex items-center justify-center min-h-screen">
    <LoadingSpinner size="lg" />
    <span className="ml-2 text-lg">Carregando...</span>
  </div>
);

// Wrapper para lazy loading
const LazyPage = ({ children }: { children: React.ReactNode }) => (
  <Suspense fallback={<PageLoader />}>
    {children}
  </Suspense>
);

// Uso no roteamento
export const AppRoutes = () => (
  <Routes>
    <Route
      path="/dashboard"
      element={
        <LazyPage>
          <Dashboard />
        </LazyPage>
      }
    />
    <Route
      path="/profile"
      element={
        <LazyPage>
          <Profile />
        </LazyPage>
      }
    />
    {/* Outras rotas... */}
  </Routes>
);
```

### 12.3 Padrões de Acessibilidade

#### 12.3.1 Componentes Acessíveis

```typescript
// Exemplo de componente com acessibilidade completa
import React, { useId, forwardRef } from 'react';
import { cn } from '@/utils/cn';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  required?: boolean;
  icon?: React.ReactNode;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ 
    label, 
    error, 
    helperText, 
    required, 
    icon, 
    className, 
    id: providedId,
    ...props 
  }, ref) => {
    const generatedId = useId();
    const id = providedId || generatedId;
    const errorId = `${id}-error`;
    const helperId = `${id}-helper`;

    return (
      <div className="space-y-2">
        {label && (
          <label
            htmlFor={id}
            className={cn(
              'block text-sm font-medium text-gray-700',
              required && "after:content-['*'] after:ml-0.5 after:text-red-500"
            )}
          >
            {label}
          </label>
        )}
        
        <div className="relative">
          {icon && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              {icon}
            </div>
          )}
          
          <input
            ref={ref}
            id={id}
            className={cn(
              'block w-full rounded-md border-gray-300 shadow-sm',
              'focus:border-manus-500 focus:ring-manus-500',
              'disabled:bg-gray-50 disabled:text-gray-500',
              error && 'border-red-300 focus:border-red-500 focus:ring-red-500',
              icon && 'pl-10',
              className
            )}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={cn(
              error && errorId,
              helperText && helperId
            )}
            {...props}
          />
        </div>
        
        {error && (
          <p
            id={errorId}
            className="text-sm text-red-600"
            role="alert"
            aria-live="polite"
          >
            {error}
          </p>
        )}
        
        {helperText && !error && (
          <p
            id={helperId}
            className="text-sm text-gray-500"
          >
            {helperText}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

export { Input };
```

#### 12.3.2 Navegação por Teclado

```typescript
// Hook para gerenciamento de navegação por teclado
import { useEffect, useCallback } from 'react';

interface UseKeyboardNavigationOptions {
  onArrowUp?: () => void;
  onArrowDown?: () => void;
  onArrowLeft?: () => void;
  onArrowRight?: () => void;
  onEnter?: () => void;
  onEscape?: () => void;
  onTab?: () => void;
  enabled?: boolean;
}

export const useKeyboardNavigation = ({
  onArrowUp,
  onArrowDown,
  onArrowLeft,
  onArrowRight,
  onEnter,
  onEscape,
  onTab,
  enabled = true,
}: UseKeyboardNavigationOptions) => {
  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (!enabled) return;

      switch (event.key) {
        case 'ArrowUp':
          event.preventDefault();
          onArrowUp?.();
          break;
        case 'ArrowDown':
          event.preventDefault();
          onArrowDown?.();
          break;
        case 'ArrowLeft':
          event.preventDefault();
          onArrowLeft?.();
          break;
        case 'ArrowRight':
          event.preventDefault();
          onArrowRight?.();
          break;
        case 'Enter':
          event.preventDefault();
          onEnter?.();
          break;
        case 'Escape':
          event.preventDefault();
          onEscape?.();
          break;
        case 'Tab':
          onTab?.();
          break;
      }
    },
    [enabled, onArrowUp, onArrowDown, onArrowLeft, onArrowRight, onEnter, onEscape, onTab]
  );

  useEffect(() => {
    if (enabled) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [handleKeyDown, enabled]);
};

// Exemplo de uso em um componente de lista
const NavigableList = ({ items, onItemSelect }) => {
  const [selectedIndex, setSelectedIndex] = useState(0);

  useKeyboardNavigation({
    onArrowUp: () => setSelectedIndex(prev => Math.max(0, prev - 1)),
    onArrowDown: () => setSelectedIndex(prev => Math.min(items.length - 1, prev + 1)),
    onEnter: () => onItemSelect(items[selectedIndex]),
    onEscape: () => setSelectedIndex(0),
  });

  return (
    <ul role="listbox" aria-label="Lista navegável">
      {items.map((item, index) => (
        <li
          key={item.id}
          role="option"
          aria-selected={index === selectedIndex}
          className={cn(
            'p-2 cursor-pointer',
            index === selectedIndex && 'bg-manus-100 ring-2 ring-manus-500'
          )}
          onClick={() => onItemSelect(item)}
        >
          {item.name}
        </li>
      ))}
    </ul>
  );
};
```

Esta seção estabelece os padrões fundamentais de código e organização que garantem a qualidade, manutenibilidade e escalabilidade do projeto Run Driver. Na próxima seção, abordaremos a documentação específica de componentes e suas interfaces.


---

## 13. Documentação Detalhada de Componentes Específicos

### 13.1 Sistema de Documentação de Componentes

A documentação de componentes do Run Driver segue um padrão estruturado que facilita o entendimento, uso e manutenção de cada elemento da interface. Cada componente é documentado com exemplos práticos, casos de uso, props detalhadas e guidelines de implementação.

#### 13.1.1 Template de Documentação

```markdown
# ComponentName

## Visão Geral
Breve descrição do propósito e funcionalidade do componente.

## Quando Usar
- Situação 1
- Situação 2
- Situação 3

## Quando NÃO Usar
- Situação 1
- Situação 2

## Props
| Prop | Tipo | Padrão | Obrigatório | Descrição |
|------|------|--------|-------------|-----------|
| prop1 | string | - | ✓ | Descrição detalhada |
| prop2 | boolean | false | ✗ | Descrição detalhada |

## Exemplos de Uso

### Uso Básico
```tsx
<ComponentName prop1="valor" />
```

### Uso Avançado
```tsx
<ComponentName 
  prop1="valor"
  prop2={true}
  onAction={handleAction}
/>
```

## Variantes
Descrição das diferentes variantes disponíveis.

## Estados
Descrição dos diferentes estados do componente.

## Acessibilidade
Guidelines específicas de acessibilidade.

## Performance
Considerações de performance e otimizações.

## Testes
Exemplos de testes unitários.
```

### 13.2 Componentes de Mapa

#### 13.2.1 MapContainer Component

**Visão Geral**
O MapContainer é o componente central do aplicativo Run Driver, responsável por renderizar o mapa interativo, gerenciar marcadores, rotas e todas as interações geoespaciais. Utiliza React Leaflet como base e implementa otimizações específicas para aplicações de transporte.

**Quando Usar**
- Como componente principal em páginas que requerem visualização de mapa
- Para exibir localização atual do motorista
- Para mostrar rotas de viagem
- Para visualizar outros motoristas e passageiros na área

**Quando NÃO Usar**
- Em páginas que não requerem funcionalidade de mapa
- Para mapas estáticos simples (usar componente StaticMap)
- Em contextos onde performance é crítica e mapa não é essencial

**Interface e Props**

```typescript
interface MapContainerProps {
  /** Coordenadas centrais do mapa [latitude, longitude] */
  center: [number, number];
  
  /** Nível de zoom inicial (1-20) */
  zoom: number;
  
  /** Altura do container do mapa */
  height?: string | number;
  
  /** Largura do container do mapa */
  width?: string | number;
  
  /** Callback executado quando localização é atualizada */
  onLocationUpdate?: (location: Location) => void;
  
  /** Callback executado quando mapa é clicado */
  onMapClick?: (event: MapClickEvent) => void;
  
  /** Callback executado quando zoom é alterado */
  onZoomChange?: (zoom: number) => void;
  
  /** Exibir camada de tráfego */
  showTraffic?: boolean;
  
  /** Exibir outros motoristas */
  showDrivers?: boolean;
  
  /** Exibir rota ativa */
  showRoute?: boolean;
  
  /** Dados da rota a ser exibida */
  route?: RouteData;
  
  /** Marcadores a serem exibidos */
  markers?: MarkerData[];
  
  /** Callback executado quando marcador é clicado */
  onMarkerClick?: (marker: MarkerData) => void;
  
  /** Configurações de estilo do mapa */
  mapStyle?: 'default' | 'satellite' | 'dark' | 'light';
  
  /** Controles a serem exibidos */
  controls?: {
    zoom?: boolean;
    fullscreen?: boolean;
    location?: boolean;
    layers?: boolean;
  };
  
  /** Configurações de interação */
  interaction?: {
    dragging?: boolean;
    zoomOnScroll?: boolean;
    doubleClickZoom?: boolean;
    touchZoom?: boolean;
  };
  
  /** Configurações de performance */
  performance?: {
    maxMarkers?: number;
    clusterMarkers?: boolean;
    updateThrottle?: number;
  };
}

interface Location {
  lat: number;
  lng: number;
  accuracy?: number;
  heading?: number;
  speed?: number;
  timestamp?: Date;
}

interface RouteData {
  id: string;
  coordinates: Location[];
  distance: number;
  duration: number;
  instructions: RouteInstruction[];
  traffic?: TrafficData[];
}

interface MarkerData {
  id: string;
  position: Location;
  type: 'driver' | 'passenger' | 'pickup' | 'destination' | 'waypoint';
  icon?: string;
  title?: string;
  description?: string;
  data?: any;
}
```

**Exemplos de Uso**

```typescript
// Uso básico - mapa simples
<MapContainer
  center={[-23.5505, -46.6333]} // São Paulo
  zoom={13}
  height="400px"
  onLocationUpdate={handleLocationUpdate}
/>

// Uso avançado - mapa completo com rota e marcadores
<MapContainer
  center={currentLocation}
  zoom={15}
  height="100vh"
  showTraffic={true}
  showDrivers={true}
  showRoute={true}
  route={activeRoute}
  markers={nearbyDrivers}
  onMarkerClick={handleMarkerClick}
  onMapClick={handleMapClick}
  controls={{
    zoom: true,
    fullscreen: true,
    location: true,
    layers: true,
  }}
  performance={{
    maxMarkers: 50,
    clusterMarkers: true,
    updateThrottle: 1000,
  }}
/>

// Uso para seleção de destino
<MapContainer
  center={userLocation}
  zoom={14}
  height="300px"
  onMapClick={handleDestinationSelect}
  interaction={{
    dragging: true,
    zoomOnScroll: true,
    doubleClickZoom: false,
  }}
  controls={{
    zoom: true,
    location: true,
  }}
/>
```

**Estados do Componente**

```typescript
// Estados internos gerenciados pelo componente
interface MapState {
  isLoading: boolean;
  isLocationEnabled: boolean;
  currentZoom: number;
  currentCenter: Location;
  visibleMarkers: MarkerData[];
  activeRoute: RouteData | null;
  trafficLayer: boolean;
  satelliteLayer: boolean;
}
```

**Otimizações de Performance**

O MapContainer implementa várias otimizações para garantir performance suave mesmo com muitos marcadores e atualizações frequentes:

- **Clustering de Marcadores:** Agrupa marcadores próximos em clusters para reduzir sobrecarga visual
- **Throttling de Updates:** Limita atualizações de localização para evitar re-renderizações excessivas
- **Lazy Loading:** Carrega tiles do mapa sob demanda
- **Memory Management:** Remove marcadores fora da viewport para economizar memória
- **Debounced Events:** Agrupa eventos de interação para reduzir processamento

```typescript
// Exemplo de configuração de performance
const performanceConfig = {
  maxMarkers: 100,
  clusterMarkers: true,
  updateThrottle: 500, // ms
  tileLoadTimeout: 5000,
  markerCacheSize: 200,
  routeSimplification: 0.0001, // Simplifica rotas complexas
};
```

#### 13.2.2 DriverMarker Component

**Visão Geral**
Componente especializado para representar motoristas no mapa, com indicadores visuais de status, direção e informações contextuais.

**Props Interface**

```typescript
interface DriverMarkerProps {
  /** Dados do motorista */
  driver: DriverData;
  
  /** Posição atual do motorista */
  position: Location;
  
  /** Direção do movimento (em graus) */
  heading?: number;
  
  /** Status atual do motorista */
  status: 'available' | 'busy' | 'offline' | 'break';
  
  /** Exibir informações detalhadas no hover */
  showInfo?: boolean;
  
  /** Tamanho do marcador */
  size?: 'sm' | 'md' | 'lg';
  
  /** Callback executado quando marcador é clicado */
  onClick?: (driver: DriverData) => void;
  
  /** Callback executado quando informações são solicitadas */
  onInfoRequest?: (driver: DriverData) => void;
  
  /** Animação de movimento */
  animated?: boolean;
  
  /** Exibir rastro de movimento */
  showTrail?: boolean;
  
  /** Dados do rastro */
  trail?: Location[];
}

interface DriverData {
  id: string;
  name: string;
  avatar?: string;
  rating: number;
  vehicleType: 'car' | 'motorcycle' | 'bicycle';
  vehicleModel?: string;
  licensePlate?: string;
  isOnline: boolean;
  lastSeen: Date;
  totalTrips: number;
  earnings: {
    today: number;
    week: number;
    month: number;
  };
}
```

**Exemplos de Uso**

```typescript
// Marcador básico
<DriverMarker
  driver={driverData}
  position={driverLocation}
  status="available"
  onClick={handleDriverClick}
/>

// Marcador com informações detalhadas
<DriverMarker
  driver={driverData}
  position={driverLocation}
  heading={driverHeading}
  status="busy"
  size="lg"
  showInfo={true}
  animated={true}
  showTrail={true}
  trail={driverTrail}
  onInfoRequest={handleInfoRequest}
/>
```

### 13.3 Componentes de Autenticação

#### 13.3.1 BiometricAuth Component

**Visão Geral**
Componente responsável por implementar autenticação biométrica (impressão digital, Face ID, reconhecimento de voz) com fallback para PIN quando biometria não está disponível.

**Props Interface**

```typescript
interface BiometricAuthProps {
  /** Callback executado em caso de sucesso */
  onSuccess: (result: BiometricResult) => void;
  
  /** Callback executado em caso de erro */
  onError: (error: BiometricError) => void;
  
  /** Permitir fallback para PIN */
  fallbackToPin?: boolean;
  
  /** Mensagem personalizada do prompt */
  promptMessage?: string;
  
  /** Texto do botão de cancelar */
  cancelButtonText?: string;
  
  /** Tipos de biometria permitidos */
  allowedTypes?: BiometricType[];
  
  /** Timeout para autenticação (ms) */
  timeout?: number;
  
  /** Máximo de tentativas */
  maxAttempts?: number;
  
  /** Exibir indicador de carregamento */
  loading?: boolean;
  
  /** Desabilitar componente */
  disabled?: boolean;
}

interface BiometricResult {
  success: boolean;
  biometricType: BiometricType;
  deviceId: string;
  timestamp: Date;
  confidence?: number;
}

interface BiometricError {
  code: BiometricErrorCode;
  message: string;
  recoverable: boolean;
  fallbackAvailable: boolean;
}

type BiometricType = 'fingerprint' | 'face' | 'voice' | 'iris';
type BiometricErrorCode = 
  | 'not_available'
  | 'not_enrolled'
  | 'authentication_failed'
  | 'user_cancelled'
  | 'timeout'
  | 'too_many_attempts'
  | 'system_error';
```

**Exemplos de Uso**

```typescript
// Autenticação básica com impressão digital
<BiometricAuth
  onSuccess={handleBiometricSuccess}
  onError={handleBiometricError}
  promptMessage="Use sua impressão digital para fazer login"
/>

// Autenticação avançada com múltiplos tipos
<BiometricAuth
  onSuccess={handleBiometricSuccess}
  onError={handleBiometricError}
  fallbackToPin={true}
  allowedTypes={['fingerprint', 'face']}
  timeout={30000}
  maxAttempts={3}
  promptMessage="Autentique-se para continuar"
  cancelButtonText="Usar senha"
/>

// Integração com hook de autenticação
const LoginScreen = () => {
  const { login } = useAuth();
  const [showBiometric, setShowBiometric] = useState(false);

  const handleBiometricSuccess = async (result: BiometricResult) => {
    try {
      await login({ type: 'biometric', data: result });
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  return (
    <div className="login-container">
      {showBiometric && (
        <BiometricAuth
          onSuccess={handleBiometricSuccess}
          onError={(error) => {
            if (error.fallbackAvailable) {
              setShowBiometric(false);
            }
          }}
          fallbackToPin={true}
        />
      )}
    </div>
  );
};
```

#### 13.3.2 DocumentUpload Component

**Visão Geral**
Componente especializado para upload de documentos com OCR integrado, validação automática e preview em tempo real.

**Props Interface**

```typescript
interface DocumentUploadProps {
  /** Tipo de documento sendo enviado */
  documentType: DocumentType;
  
  /** Callback executado quando upload é concluído */
  onUploadComplete: (result: UploadResult) => void;
  
  /** Callback executado quando OCR é concluído */
  onOCRComplete?: (data: OCRResult) => void;
  
  /** Callback executado em caso de erro */
  onError?: (error: UploadError) => void;
  
  /** Habilitar OCR automático */
  enableOCR?: boolean;
  
  /** Habilitar verificação de vivacidade (para selfies) */
  enableLivenessCheck?: boolean;
  
  /** Tamanho máximo do arquivo (bytes) */
  maxFileSize?: number;
  
  /** Formatos aceitos */
  acceptedFormats: string[];
  
  /** Qualidade mínima da imagem (0-1) */
  minQuality?: number;
  
  /** Resolução mínima [width, height] */
  minResolution?: [number, number];
  
  /** Exibir preview do arquivo */
  showPreview?: boolean;
  
  /** Permitir múltiplos arquivos */
  multiple?: boolean;
  
  /** Texto de instrução personalizado */
  instructionText?: string;
  
  /** Validações customizadas */
  customValidations?: ValidationRule[];
}

type DocumentType = 
  | 'cnh'           // Carteira Nacional de Habilitação
  | 'crlv'          // Certificado de Registro e Licenciamento de Veículo
  | 'cpf'           // Cadastro de Pessoa Física
  | 'rg'            // Registro Geral
  | 'selfie'        // Selfie para verificação
  | 'vehicle_photo' // Foto do veículo
  | 'insurance'     // Seguro do veículo
  | 'background_check'; // Antecedentes criminais

interface UploadResult {
  fileId: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  url: string;
  thumbnailUrl?: string;
  ocrData?: OCRResult;
  livenessScore?: number;
  validationResults: ValidationResult[];
  verificationStatus: 'pending' | 'approved' | 'rejected' | 'requires_review';
  uploadedAt: Date;
}

interface OCRResult {
  confidence: number;
  extractedData: Record<string, any>;
  boundingBoxes: BoundingBox[];
  detectedLanguage: string;
  processingTime: number;
}

interface ValidationResult {
  rule: string;
  passed: boolean;
  message: string;
  severity: 'error' | 'warning' | 'info';
}
```

**Exemplos de Uso**

```typescript
// Upload básico de CNH
<DocumentUpload
  documentType="cnh"
  acceptedFormats={['image/jpeg', 'image/png']}
  maxFileSize={5 * 1024 * 1024} // 5MB
  onUploadComplete={handleCNHUpload}
  enableOCR={true}
  showPreview={true}
/>

// Upload avançado com validações customizadas
<DocumentUpload
  documentType="selfie"
  acceptedFormats={['image/jpeg', 'image/png']}
  maxFileSize={3 * 1024 * 1024}
  enableLivenessCheck={true}
  minQuality={0.8}
  minResolution={[640, 480]}
  onUploadComplete={handleSelfieUpload}
  onError={handleUploadError}
  instructionText="Tire uma selfie clara com boa iluminação"
  customValidations={[
    {
      name: 'face_detection',
      validator: (file) => validateFacePresence(file),
      message: 'Nenhum rosto detectado na imagem',
    },
  ]}
/>

// Upload múltiplo de fotos do veículo
<DocumentUpload
  documentType="vehicle_photo"
  acceptedFormats={['image/jpeg', 'image/png']}
  multiple={true}
  maxFileSize={10 * 1024 * 1024}
  onUploadComplete={handleVehiclePhotos}
  showPreview={true}
  instructionText="Envie fotos do veículo (frente, traseira, laterais)"
/>
```

### 13.4 Componentes de Gamificação

#### 13.4.1 AchievementCard Component

**Visão Geral**
Componente para exibir conquistas do sistema de gamificação, com animações, progresso e recompensas associadas.

**Props Interface**

```typescript
interface AchievementCardProps {
  /** Dados da conquista */
  achievement: Achievement;
  
  /** Progresso atual (0-100) */
  progress: number;
  
  /** Se a conquista foi desbloqueada */
  unlocked: boolean;
  
  /** Exibir barra de progresso */
  showProgress?: boolean;
  
  /** Exibir recompensas */
  showRewards?: boolean;
  
  /** Tamanho do card */
  size?: 'sm' | 'md' | 'lg';
  
  /** Variante visual */
  variant?: 'default' | 'compact' | 'detailed';
  
  /** Callback para reivindicar recompensa */
  onClaim?: () => void;
  
  /** Callback para compartilhar conquista */
  onShare?: () => void;
  
  /** Callback para ver detalhes */
  onViewDetails?: () => void;
  
  /** Exibir animação de desbloqueio */
  showUnlockAnimation?: boolean;
  
  /** Desabilitar interações */
  disabled?: boolean;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: AchievementCategory;
  type: AchievementType;
  rarity: AchievementRarity;
  requirements: AchievementRequirement[];
  rewards: Reward[];
  unlockedAt?: Date;
  progress?: {
    current: number;
    target: number;
    unit: string;
  };
  metadata?: {
    difficulty: number;
    estimatedTime: string;
    tips: string[];
  };
}

type AchievementCategory = 
  | 'driving'      // Relacionadas à condução
  | 'social'       // Interações sociais
  | 'earnings'     // Ganhos e metas financeiras
  | 'safety'       // Segurança no trânsito
  | 'efficiency'   // Eficiência operacional
  | 'community'    // Participação na comunidade
  | 'special';     // Conquistas especiais/sazonais

type AchievementType = 
  | 'milestone'    // Marco específico
  | 'streak'       // Sequência de ações
  | 'challenge'    // Desafio temporário
  | 'rare'         // Conquista rara
  | 'hidden';      // Conquista secreta

type AchievementRarity = 
  | 'common'       // 70% dos usuários
  | 'uncommon'     // 40% dos usuários
  | 'rare'         // 15% dos usuários
  | 'epic'         // 5% dos usuários
  | 'legendary';   // 1% dos usuários
```

**Exemplos de Uso**

```typescript
// Card básico de conquista
<AchievementCard
  achievement={achievement}
  progress={75}
  unlocked={false}
  showProgress={true}
  size="md"
/>

// Card de conquista desbloqueada com recompensas
<AchievementCard
  achievement={unlockedAchievement}
  progress={100}
  unlocked={true}
  showRewards={true}
  showUnlockAnimation={true}
  onClaim={handleClaimReward}
  onShare={handleShareAchievement}
  size="lg"
  variant="detailed"
/>

// Lista de conquistas
const AchievementsList = ({ achievements }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {achievements.map((achievement) => (
        <AchievementCard
          key={achievement.id}
          achievement={achievement}
          progress={achievement.progress?.current || 0}
          unlocked={!!achievement.unlockedAt}
          showProgress={!achievement.unlockedAt}
          onViewDetails={() => openAchievementDetails(achievement)}
          variant="compact"
        />
      ))}
    </div>
  );
};
```

#### 13.4.2 LevelProgress Component

**Visão Geral**
Componente para exibir progresso de nível do usuário com XP, benefícios e animações de level up.

**Props Interface**

```typescript
interface LevelProgressProps {
  /** Nível atual do usuário */
  currentLevel: number;
  
  /** XP atual no nível */
  currentXP: number;
  
  /** XP necessário para próximo nível */
  xpToNextLevel: number;
  
  /** XP total acumulado */
  totalXP?: number;
  
  /** Exibir animação de level up */
  showAnimation?: boolean;
  
  /** Exibir benefícios do nível */
  showBenefits?: boolean;
  
  /** Exibir próximos benefícios */
  showNextBenefits?: boolean;
  
  /** Callback executado quando level up */
  onLevelUp?: (newLevel: number) => void;
  
  /** Callback para ver detalhes do nível */
  onViewLevelDetails?: (level: number) => void;
  
  /** Tamanho do componente */
  size?: 'sm' | 'md' | 'lg';
  
  /** Variante visual */
  variant?: 'circular' | 'linear' | 'detailed';
  
  /** Tema de cores */
  colorTheme?: 'default' | 'manus' | 'gold' | 'rainbow';
}

interface LevelBenefit {
  id: string;
  name: string;
  description: string;
  icon: string;
  type: 'feature' | 'discount' | 'bonus' | 'cosmetic';
  value?: number;
  unlockLevel: number;
}
```

**Exemplos de Uso**

```typescript
// Progresso básico
<LevelProgress
  currentLevel={12}
  currentXP={2450}
  xpToNextLevel={3000}
  variant="circular"
  size="md"
/>

// Progresso detalhado com benefícios
<LevelProgress
  currentLevel={15}
  currentXP={4200}
  xpToNextLevel={5000}
  totalXP={45200}
  showBenefits={true}
  showNextBenefits={true}
  onLevelUp={handleLevelUp}
  onViewLevelDetails={handleViewDetails}
  variant="detailed"
  size="lg"
  colorTheme="manus"
/>

// Integração com dashboard
const GamificationDashboard = () => {
  const { userLevel, userXP } = useGamification();
  
  return (
    <div className="gamification-dashboard">
      <LevelProgress
        currentLevel={userLevel.current}
        currentXP={userXP.current}
        xpToNextLevel={userLevel.xpToNext}
        showAnimation={userLevel.justLeveledUp}
        onLevelUp={(newLevel) => {
          showCelebration(`Parabéns! Você alcançou o nível ${newLevel}!`);
        }}
      />
    </div>
  );
};
```

### 13.5 Componentes de Rede Social

#### 13.5.1 SocialFeed Component

**Visão Geral**
Componente principal do feed social, exibindo posts de motoristas com interações em tempo real.

**Props Interface**

```typescript
interface SocialFeedProps {
  /** Tipo de feed */
  feedType: 'home' | 'following' | 'group' | 'local' | 'trending';
  
  /** Posts a serem exibidos */
  posts?: SocialPost[];
  
  /** Filtros aplicados */
  filters?: FeedFilter[];
  
  /** Callback para interação com post */
  onPostInteraction: (interaction: PostInteraction) => void;
  
  /** Callback para carregar mais posts */
  onLoadMore: () => void;
  
  /** Estado de carregamento */
  loading?: boolean;
  
  /** Estado de refresh */
  refreshing?: boolean;
  
  /** Callback para refresh */
  onRefresh?: () => void;
  
  /** Exibir composer de post */
  showComposer?: boolean;
  
  /** Callback para criar post */
  onCreatePost?: (post: CreatePostData) => void;
  
  /** Configurações de exibição */
  displayOptions?: {
    showAvatars?: boolean;
    showTimestamps?: boolean;
    showInteractionCounts?: boolean;
    compactMode?: boolean;
  };
  
  /** Configurações de moderação */
  moderationSettings?: {
    hideReportedContent?: boolean;
    blurSensitiveContent?: boolean;
    showModerationActions?: boolean;
  };
}

interface SocialPost {
  id: string;
  author: {
    id: string;
    name: string;
    avatar?: string;
    verified: boolean;
    level: number;
  };
  content: {
    text?: string;
    media?: MediaFile[];
    poll?: PollData;
    achievement?: Achievement;
    location?: Location;
  };
  metadata: {
    createdAt: Date;
    editedAt?: Date;
    visibility: 'public' | 'friends' | 'group';
    tags: string[];
    mentions: string[];
  };
  interactions: {
    likes: number;
    comments: number;
    shares: number;
    views: number;
  };
  userInteractions: {
    liked: boolean;
    commented: boolean;
    shared: boolean;
    saved: boolean;
  };
  moderation?: {
    reported: boolean;
    flagged: boolean;
    sensitive: boolean;
  };
}

interface PostInteraction {
  type: 'like' | 'unlike' | 'comment' | 'share' | 'save' | 'report' | 'hide';
  postId: string;
  data?: any;
}
```

**Exemplos de Uso**

```typescript
// Feed básico da timeline
<SocialFeed
  feedType="home"
  onPostInteraction={handlePostInteraction}
  onLoadMore={loadMorePosts}
  showComposer={true}
  onCreatePost={handleCreatePost}
/>

// Feed de grupo com filtros
<SocialFeed
  feedType="group"
  filters={[
    { type: 'content_type', value: 'achievement' },
    { type: 'time_range', value: 'week' }
  ]}
  onPostInteraction={handlePostInteraction}
  onLoadMore={loadMorePosts}
  displayOptions={{
    compactMode: true,
    showInteractionCounts: true,
  }}
  moderationSettings={{
    hideReportedContent: true,
    blurSensitiveContent: true,
  }}
/>

// Feed local com localização
<SocialFeed
  feedType="local"
  onPostInteraction={handlePostInteraction}
  onLoadMore={loadMorePosts}
  filters={[
    { type: 'location', value: currentLocation, radius: 10 }
  ]}
/>
```

### 13.6 Componentes de Pagamento

#### 13.6.1 WalletDashboard Component

**Visão Geral**
Dashboard principal da carteira virtual, exibindo saldo, transações recentes e opções de gerenciamento financeiro.

**Props Interface**

```typescript
interface WalletDashboardProps {
  /** Dados do saldo da carteira */
  balance: WalletBalance;
  
  /** Transações recentes */
  recentTransactions: Transaction[];
  
  /** Ganhos pendentes */
  pendingEarnings: number;
  
  /** Data do próximo pagamento */
  nextPayoutDate: Date;
  
  /** Callback para adicionar fundos */
  onAddFunds: () => void;
  
  /** Callback para sacar dinheiro */
  onWithdraw: () => void;
  
  /** Callback para ver histórico */
  onViewHistory: () => void;
  
  /** Callback para ver detalhes de ganhos */
  onViewEarnings: () => void;
  
  /** Exibir gráfico de ganhos */
  showEarningsChart?: boolean;
  
  /** Período do gráfico */
  chartPeriod?: 'week' | 'month' | 'quarter' | 'year';
  
  /** Configurações de exibição */
  displayOptions?: {
    showBalance?: boolean;
    showPendingEarnings?: boolean;
    showQuickActions?: boolean;
    showRecentTransactions?: boolean;
    compactMode?: boolean;
  };
  
  /** Configurações de segurança */
  securitySettings?: {
    requirePinForWithdraw?: boolean;
    requireBiometricForLargeAmounts?: boolean;
    maxDailyWithdraw?: number;
  };
}

interface WalletBalance {
  available: number;
  pending: number;
  reserved: number;
  total: number;
  currency: string;
  lastUpdated: Date;
}

interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  currency: string;
  description: string;
  status: TransactionStatus;
  createdAt: Date;
  completedAt?: Date;
  metadata?: {
    tripId?: string;
    achievementId?: string;
    adId?: string;
    gameId?: string;
  };
}

type TransactionType = 
  | 'trip_earning'
  | 'tip_received'
  | 'bonus_earned'
  | 'achievement_reward'
  | 'ad_reward'
  | 'game_reward'
  | 'referral_bonus'
  | 'withdraw'
  | 'refund'
  | 'fee'
  | 'adjustment';

type TransactionStatus = 
  | 'pending'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'refunded';
```

**Exemplos de Uso**

```typescript
// Dashboard básico
<WalletDashboard
  balance={walletBalance}
  recentTransactions={transactions}
  pendingEarnings={pendingAmount}
  nextPayoutDate={payoutDate}
  onAddFunds={handleAddFunds}
  onWithdraw={handleWithdraw}
  onViewHistory={handleViewHistory}
/>

// Dashboard completo com gráficos
<WalletDashboard
  balance={walletBalance}
  recentTransactions={transactions}
  pendingEarnings={pendingAmount}
  nextPayoutDate={payoutDate}
  showEarningsChart={true}
  chartPeriod="month"
  onAddFunds={handleAddFunds}
  onWithdraw={handleWithdraw}
  onViewHistory={handleViewHistory}
  onViewEarnings={handleViewEarnings}
  displayOptions={{
    showBalance: true,
    showPendingEarnings: true,
    showQuickActions: true,
    showRecentTransactions: true,
  }}
  securitySettings={{
    requirePinForWithdraw: true,
    requireBiometricForLargeAmounts: true,
    maxDailyWithdraw: 1000,
  }}
/>

// Integração com hook de carteira
const WalletPage = () => {
  const {
    balance,
    transactions,
    pendingEarnings,
    nextPayout,
    addFunds,
    withdraw,
  } = useWallet();

  return (
    <div className="wallet-page">
      <WalletDashboard
        balance={balance}
        recentTransactions={transactions.slice(0, 5)}
        pendingEarnings={pendingEarnings}
        nextPayoutDate={nextPayout}
        onAddFunds={addFunds}
        onWithdraw={withdraw}
        onViewHistory={() => navigate('/wallet/history')}
      />
    </div>
  );
};
```

### 13.7 Testes de Componentes

#### 13.7.1 Estratégia de Testes

Cada componente documentado inclui uma suíte de testes abrangente que cobre:

- **Testes de Renderização:** Verificam se o componente renderiza corretamente com diferentes props
- **Testes de Interação:** Validam comportamentos de clique, hover e outras interações
- **Testes de Acessibilidade:** Garantem conformidade com padrões WCAG
- **Testes de Performance:** Verificam otimizações e limites de performance
- **Testes de Integração:** Validam funcionamento com outros componentes

```typescript
// Exemplo de teste para MapContainer
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MapContainer } from '@/components/organisms/MapContainer';
import { mockLocation, mockRoute, mockMarkers } from '@/tests/fixtures';

describe('MapContainer', () => {
  it('renders map with correct center and zoom', () => {
    render(
      <MapContainer
        center={[-23.5505, -46.6333]}
        zoom={13}
        height="400px"
      />
    );
    
    expect(screen.getByRole('application')).toBeInTheDocument();
    expect(screen.getByLabelText(/mapa interativo/i)).toBeInTheDocument();
  });

  it('calls onLocationUpdate when location changes', async () => {
    const onLocationUpdate = jest.fn();
    
    render(
      <MapContainer
        center={mockLocation}
        zoom={15}
        onLocationUpdate={onLocationUpdate}
      />
    );
    
    // Simular mudança de localização
    fireEvent(window, new CustomEvent('locationchange', {
      detail: { lat: -23.5506, lng: -46.6334 }
    }));
    
    await waitFor(() => {
      expect(onLocationUpdate).toHaveBeenCalledWith(
        expect.objectContaining({
          lat: -23.5506,
          lng: -46.6334
        })
      );
    });
  });

  it('displays markers correctly', () => {
    render(
      <MapContainer
        center={mockLocation}
        zoom={15}
        markers={mockMarkers}
      />
    );
    
    mockMarkers.forEach(marker => {
      expect(screen.getByLabelText(marker.title)).toBeInTheDocument();
    });
  });

  it('handles performance optimization with many markers', () => {
    const manyMarkers = Array.from({ length: 200 }, (_, i) => ({
      id: `marker-${i}`,
      position: { lat: -23.55 + i * 0.001, lng: -46.63 + i * 0.001 },
      type: 'driver',
      title: `Driver ${i}`,
    }));
    
    render(
      <MapContainer
        center={mockLocation}
        zoom={15}
        markers={manyMarkers}
        performance={{
          maxMarkers: 50,
          clusterMarkers: true,
        }}
      />
    );
    
    // Verificar se clustering está ativo
    expect(screen.getByText(/50\+/)).toBeInTheDocument();
  });
});
```

Esta documentação detalhada de componentes fornece uma base sólida para desenvolvimento, manutenção e evolução do sistema Run Driver, garantindo consistência, qualidade e facilidade de uso para toda a equipe de desenvolvimento.


---

## 14. Integração com MANUS.IM - Design System e Especificações Técnicas

### 14.1 Análise da Identidade Visual MANUS.IM

Baseado na análise do site oficial do MANUS.IM, identificamos os elementos fundamentais da identidade visual que devem ser incorporados ao Run Driver. A plataforma MANUS apresenta uma estética moderna, minimalista e tecnológica que reflete inovação e confiabilidade.

#### 14.1.1 Paleta de Cores Principal

A identidade visual do MANUS.IM é caracterizada por uma paleta de cores cuidadosamente selecionada que transmite profissionalismo, inovação e acessibilidade:

**Cores Primárias:**
- **Verde MANUS (#7CB342):** Cor principal da marca, presente no logotipo e elementos de destaque
- **Branco Puro (#FFFFFF):** Cor de fundo principal, garantindo clareza e legibilidade
- **Preto Profundo (#1A1A1A):** Cor de texto principal e elementos de contraste
- **Cinza Neutro (#6B7280):** Cor de texto secundário e elementos de apoio

**Cores Secundárias:**
- **Azul Tecnológico (#3B82F6):** Para elementos interativos e links
- **Verde Claro (#84CC16):** Variação mais clara do verde principal
- **Cinza Claro (#F3F4F6):** Para backgrounds de seções e cards
- **Cinza Médio (#9CA3AF):** Para bordas e divisores

**Cores de Estado:**
- **Sucesso (#10B981):** Para confirmações e estados positivos
- **Aviso (#F59E0B):** Para alertas e informações importantes
- **Erro (#EF4444):** Para erros e estados negativos
- **Informação (#3B82F6):** Para dicas e informações neutras

#### 14.1.2 Tipografia e Hierarquia

O MANUS.IM utiliza uma tipografia moderna e legível que prioriza a clareza da informação:

**Família Tipográfica Principal:**
- **Inter:** Fonte sans-serif moderna, otimizada para interfaces digitais
- **Fallbacks:** -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif

**Hierarquia Tipográfica:**
```css
/* Títulos Principais */
.text-4xl { font-size: 2.25rem; line-height: 2.5rem; font-weight: 700; }
.text-3xl { font-size: 1.875rem; line-height: 2.25rem; font-weight: 600; }
.text-2xl { font-size: 1.5rem; line-height: 2rem; font-weight: 600; }

/* Títulos Secundários */
.text-xl { font-size: 1.25rem; line-height: 1.75rem; font-weight: 500; }
.text-lg { font-size: 1.125rem; line-height: 1.75rem; font-weight: 500; }

/* Texto Corpo */
.text-base { font-size: 1rem; line-height: 1.5rem; font-weight: 400; }
.text-sm { font-size: 0.875rem; line-height: 1.25rem; font-weight: 400; }
.text-xs { font-size: 0.75rem; line-height: 1rem; font-weight: 400; }
```

#### 14.1.3 Elementos Visuais Característicos

**Logotipo e Iconografia:**
O logotipo MANUS apresenta um design minimalista com o texto "manus" em fonte personalizada, acompanhado de um ícone geométrico que sugere movimento e tecnologia. A iconografia segue padrões de design material com linhas limpas e formas geométricas simples.

**Espaçamento e Layout:**
- **Grid System:** Sistema de 12 colunas com breakpoints responsivos
- **Espaçamento Base:** 8px como unidade fundamental (sistema de múltiplos de 8)
- **Margens e Paddings:** Seguem progressão geométrica (8, 16, 24, 32, 48, 64px)

**Bordas e Sombras:**
- **Border Radius:** 8px para elementos padrão, 12px para cards, 16px para modais
- **Sombras:** Sutis e em camadas para criar profundidade sem exagero

### 14.2 Implementação do Design System MANUS para Run Driver

#### 14.2.1 Configuração de Tokens de Design

```typescript
// tokens/colors.ts
export const manusColors = {
  // Cores Primárias MANUS
  primary: {
    50: '#F0F9E8',
    100: '#E1F3D1',
    200: '#C3E7A3',
    300: '#A5DB75',
    400: '#87CF47',
    500: '#7CB342', // Verde MANUS principal
    600: '#6A9B38',
    700: '#57832E',
    800: '#456B24',
    900: '#32531A',
  },
  
  // Cores Neutras
  neutral: {
    50: '#FAFAFA',
    100: '#F5F5F5',
    200: '#E5E5E5',
    300: '#D4D4D4',
    400: '#A3A3A3',
    500: '#737373',
    600: '#525252',
    700: '#404040',
    800: '#262626',
    900: '#171717',
  },
  
  // Cores Funcionais
  blue: {
    50: '#EFF6FF',
    100: '#DBEAFE',
    200: '#BFDBFE',
    300: '#93C5FD',
    400: '#60A5FA',
    500: '#3B82F6', // Azul tecnológico
    600: '#2563EB',
    700: '#1D4ED8',
    800: '#1E40AF',
    900: '#1E3A8A',
  },
  
  // Estados
  success: {
    50: '#ECFDF5',
    100: '#D1FAE5',
    200: '#A7F3D0',
    300: '#6EE7B7',
    400: '#34D399',
    500: '#10B981',
    600: '#059669',
    700: '#047857',
    800: '#065F46',
    900: '#064E3B',
  },
  
  warning: {
    50: '#FFFBEB',
    100: '#FEF3C7',
    200: '#FDE68A',
    300: '#FCD34D',
    400: '#FBBF24',
    500: '#F59E0B',
    600: '#D97706',
    700: '#B45309',
    800: '#92400E',
    900: '#78350F',
  },
  
  error: {
    50: '#FEF2F2',
    100: '#FEE2E2',
    200: '#FECACA',
    300: '#FCA5A5',
    400: '#F87171',
    500: '#EF4444',
    600: '#DC2626',
    700: '#B91C1C',
    800: '#991B1B',
    900: '#7F1D1D',
  },
};

// tokens/spacing.ts
export const manusSpacing = {
  0: '0px',
  1: '4px',
  2: '8px',
  3: '12px',
  4: '16px',
  5: '20px',
  6: '24px',
  8: '32px',
  10: '40px',
  12: '48px',
  16: '64px',
  20: '80px',
  24: '96px',
  32: '128px',
  40: '160px',
  48: '192px',
  56: '224px',
  64: '256px',
};

// tokens/typography.ts
export const manusTypography = {
  fontFamily: {
    sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
    mono: ['JetBrains Mono', 'Monaco', 'Consolas', 'Liberation Mono', 'Courier New', 'monospace'],
  },
  
  fontSize: {
    xs: ['0.75rem', { lineHeight: '1rem' }],
    sm: ['0.875rem', { lineHeight: '1.25rem' }],
    base: ['1rem', { lineHeight: '1.5rem' }],
    lg: ['1.125rem', { lineHeight: '1.75rem' }],
    xl: ['1.25rem', { lineHeight: '1.75rem' }],
    '2xl': ['1.5rem', { lineHeight: '2rem' }],
    '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
    '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
    '5xl': ['3rem', { lineHeight: '1' }],
    '6xl': ['3.75rem', { lineHeight: '1' }],
  },
  
  fontWeight: {
    thin: '100',
    extralight: '200',
    light: '300',
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
    extrabold: '800',
    black: '900',
  },
};
```

#### 14.2.2 Configuração Tailwind CSS Personalizada

```javascript
// tailwind.config.js
const { manusColors, manusSpacing, manusTypography } = require('./src/tokens');

module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        ...manusColors,
        // Aliases para facilitar uso
        brand: manusColors.primary,
        manus: manusColors.primary,
      },
      
      spacing: manusSpacing,
      
      fontFamily: manusTypography.fontFamily,
      fontSize: manusTypography.fontSize,
      fontWeight: manusTypography.fontWeight,
      
      borderRadius: {
        'manus-sm': '6px',
        'manus-md': '8px',
        'manus-lg': '12px',
        'manus-xl': '16px',
        'manus-2xl': '20px',
      },
      
      boxShadow: {
        'manus-sm': '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        'manus-md': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'manus-lg': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
        'manus-xl': '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
      },
      
      animation: {
        'manus-fade-in': 'fadeIn 0.3s ease-in-out',
        'manus-slide-up': 'slideUp 0.3s ease-out',
        'manus-scale-in': 'scaleIn 0.2s ease-out',
        'manus-pulse': 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
    require('@tailwindcss/aspect-ratio'),
  ],
};
```

#### 14.2.3 Componentes Base com Identidade MANUS

```typescript
// components/ui/Button.tsx - Versão MANUS
import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/utils/cn';

const buttonVariants = cva(
  'inline-flex items-center justify-center rounded-manus-md text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-manus-500 focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none',
  {
    variants: {
      variant: {
        // Variante principal MANUS
        manus: 'bg-manus-500 text-white hover:bg-manus-600 active:bg-manus-700 shadow-manus-md hover:shadow-manus-lg',
        
        // Variante outline MANUS
        'manus-outline': 'border-2 border-manus-500 text-manus-600 hover:bg-manus-50 active:bg-manus-100',
        
        // Variante ghost MANUS
        'manus-ghost': 'text-manus-600 hover:bg-manus-50 active:bg-manus-100',
        
        // Variantes funcionais
        primary: 'bg-blue-500 text-white hover:bg-blue-600 shadow-manus-md',
        secondary: 'bg-neutral-200 text-neutral-900 hover:bg-neutral-300',
        success: 'bg-success-500 text-white hover:bg-success-600',
        warning: 'bg-warning-500 text-white hover:bg-warning-600',
        error: 'bg-error-500 text-white hover:bg-error-600',
      },
      size: {
        sm: 'h-8 px-3 text-xs',
        md: 'h-10 px-4 text-sm',
        lg: 'h-12 px-6 text-base',
        xl: 'h-14 px-8 text-lg',
      },
    },
    defaultVariants: {
      variant: 'manus',
      size: 'md',
    },
  }
);

interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  children: React.ReactNode;
  loading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, children, loading, icon, iconPosition = 'left', ...props }, ref) => {
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        disabled={loading || props.disabled}
        {...props}
      >
        {loading && (
          <svg
            className="mr-2 h-4 w-4 animate-spin"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        )}
        {icon && iconPosition === 'left' && !loading && (
          <span className="mr-2">{icon}</span>
        )}
        {children}
        {icon && iconPosition === 'right' && !loading && (
          <span className="ml-2">{icon}</span>
        )}
      </button>
    );
  }
);

Button.displayName = 'Button';

export { Button, buttonVariants };
```

### 14.3 Biblioteca de Ícones MANUS

#### 14.3.1 Sistema de Ícones Integrado

```typescript
// components/ui/Icon.tsx
import React from 'react';
import { cn } from '@/utils/cn';
import * as LucideIcons from 'lucide-react';

// Mapeamento de ícones MANUS customizados
const manusIcons = {
  // Ícones específicos do Run Driver
  'run-driver': () => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12 2L13.09 8.26L20 9L13.09 9.74L12 16L10.91 9.74L4 9L10.91 8.26L12 2Z"
        fill="currentColor"
      />
    </svg>
  ),
  
  'manus-logo': () => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12Z"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M8 12L11 15L16 9"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  
  // Ícones de gamificação
  'achievement-badge': () => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z"
        fill="currentColor"
      />
    </svg>
  ),
  
  'level-up': () => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M7 14L12 9L17 14"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 9V21"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  
  // Ícones de transporte
  'car-driver': () => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M5 17H4C3.44772 17 3 16.5523 3 16V10C3 9.44772 3.44772 9 4 9H5M5 17V19C5 19.5523 5.44772 20 6 20H7C7.55228 20 8 19.5523 8 19V17M5 17H19M19 17H20C20.5523 17 21 16.5523 21 16V10C21 9.44772 20.5523 9 20 9H19M19 17V19C19 19.5523 18.5523 20 18 20H17C16.4477 20 16 19.5523 16 19V17"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M5 9L7 5H17L19 9"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
};

interface IconProps {
  name: string;
  size?: number | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  color?: string;
  strokeWidth?: number;
}

const sizeMap = {
  xs: 12,
  sm: 16,
  md: 20,
  lg: 24,
  xl: 32,
};

const Icon: React.FC<IconProps> = ({
  name,
  size = 'md',
  className,
  color = 'currentColor',
  strokeWidth = 2,
}) => {
  const iconSize = typeof size === 'number' ? size : sizeMap[size];
  
  // Verificar se é um ícone MANUS customizado
  if (manusIcons[name as keyof typeof manusIcons]) {
    const ManusIcon = manusIcons[name as keyof typeof manusIcons];
    return (
      <ManusIcon
        className={cn('inline-block', className)}
        style={{
          width: iconSize,
          height: iconSize,
          color,
        }}
      />
    );
  }
  
  // Fallback para ícones Lucide
  const LucideIcon = LucideIcons[name as keyof typeof LucideIcons] as React.ComponentType<any>;
  
  if (LucideIcon) {
    return (
      <LucideIcon
        size={iconSize}
        color={color}
        strokeWidth={strokeWidth}
        className={cn('inline-block', className)}
      />
    );
  }
  
  // Ícone padrão se não encontrado
  return (
    <LucideIcons.HelpCircle
      size={iconSize}
      color={color}
      strokeWidth={strokeWidth}
      className={cn('inline-block', className)}
    />
  );
};

export { Icon, manusIcons };
```

#### 14.3.2 Catálogo de Ícones por Categoria

```typescript
// constants/iconCatalog.ts
export const iconCatalog = {
  // Navegação e Interface
  navigation: [
    'menu', 'x', 'chevron-left', 'chevron-right', 'chevron-up', 'chevron-down',
    'arrow-left', 'arrow-right', 'home', 'search', 'filter', 'more-horizontal'
  ],
  
  // Transporte e Mapas
  transport: [
    'car-driver', 'map-pin', 'navigation', 'route', 'compass', 'map',
    'traffic-cone', 'fuel', 'speedometer', 'road'
  ],
  
  // Usuário e Perfil
  user: [
    'user', 'user-circle', 'users', 'user-plus', 'user-check', 'user-x',
    'profile', 'settings', 'edit', 'camera'
  ],
  
  // Gamificação
  gamification: [
    'achievement-badge', 'level-up', 'trophy', 'star', 'award', 'target',
    'trending-up', 'zap', 'flame', 'crown'
  ],
  
  // Financeiro
  financial: [
    'dollar-sign', 'credit-card', 'wallet', 'coins', 'trending-up', 'trending-down',
    'bar-chart', 'pie-chart', 'receipt', 'bank-note'
  ],
  
  // Social
  social: [
    'heart', 'message-circle', 'share', 'thumbs-up', 'thumbs-down', 'bookmark',
    'flag', 'users', 'user-plus', 'message-square'
  ],
  
  // Estados e Feedback
  feedback: [
    'check', 'x', 'alert-circle', 'alert-triangle', 'info', 'help-circle',
    'check-circle', 'x-circle', 'loader', 'refresh-cw'
  ],
  
  // Ações
  actions: [
    'plus', 'minus', 'edit', 'trash', 'download', 'upload', 'share',
    'copy', 'external-link', 'eye', 'eye-off', 'lock', 'unlock'
  ],
  
  // Comunicação
  communication: [
    'phone', 'phone-call', 'mail', 'message-circle', 'bell', 'bell-off',
    'volume-2', 'volume-x', 'mic', 'mic-off'
  ],
  
  // Tempo e Data
  time: [
    'clock', 'calendar', 'calendar-days', 'timer', 'stopwatch', 'history',
    'sunrise', 'sunset', 'moon', 'sun'
  ],
  
  // Tecnologia
  technology: [
    'smartphone', 'tablet', 'laptop', 'monitor', 'wifi', 'bluetooth',
    'battery', 'signal', 'qr-code', 'scan'
  ],
};

// Função para buscar ícones por categoria
export const getIconsByCategory = (category: keyof typeof iconCatalog) => {
  return iconCatalog[category] || [];
};

// Função para buscar ícone por nome
export const findIcon = (searchTerm: string) => {
  const allIcons = Object.values(iconCatalog).flat();
  return allIcons.filter(icon => 
    icon.toLowerCase().includes(searchTerm.toLowerCase())
  );
};
```

### 14.4 Temas Claro e Escuro MANUS

#### 14.4.1 Configuração de Temas

```css
/* styles/themes/manus-light.css */
:root {
  /* Cores de fundo */
  --background-primary: #ffffff;
  --background-secondary: #f8fafc;
  --background-tertiary: #f1f5f9;
  --background-overlay: rgba(255, 255, 255, 0.95);
  
  /* Cores de texto */
  --text-primary: #0f172a;
  --text-secondary: #475569;
  --text-tertiary: #64748b;
  --text-inverse: #ffffff;
  
  /* Cores de borda */
  --border-primary: #e2e8f0;
  --border-secondary: #cbd5e1;
  --border-focus: #7cb342;
  
  /* Cores MANUS */
  --manus-primary: #7cb342;
  --manus-primary-hover: #6a9b38;
  --manus-primary-light: #e8f5e8;
  --manus-primary-dark: #5a7c2f;
  
  /* Sombras */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  
  /* Estados */
  --success: #10b981;
  --warning: #f59e0b;
  --error: #ef4444;
  --info: #3b82f6;
}

/* styles/themes/manus-dark.css */
[data-theme="dark"] {
  /* Cores de fundo */
  --background-primary: #0f172a;
  --background-secondary: #1e293b;
  --background-tertiary: #334155;
  --background-overlay: rgba(15, 23, 42, 0.95);
  
  /* Cores de texto */
  --text-primary: #f8fafc;
  --text-secondary: #cbd5e1;
  --text-tertiary: #94a3b8;
  --text-inverse: #0f172a;
  
  /* Cores de borda */
  --border-primary: #334155;
  --border-secondary: #475569;
  --border-focus: #84cc16;
  
  /* Cores MANUS ajustadas para dark mode */
  --manus-primary: #84cc16;
  --manus-primary-hover: #65a30d;
  --manus-primary-light: rgba(132, 204, 22, 0.1);
  --manus-primary-dark: #4d7c0f;
  
  /* Sombras ajustadas */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.3);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.4);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
  
  /* Estados ajustados */
  --success: #22c55e;
  --warning: #fbbf24;
  --error: #f87171;
  --info: #60a5fa;
}
```

#### 14.4.2 Hook para Gerenciamento de Tema

```typescript
// hooks/useTheme.ts
import { useEffect, useState } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';

type Theme = 'light' | 'dark' | 'system';

interface UseThemeReturn {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  resolvedTheme: 'light' | 'dark';
  toggleTheme: () => void;
}

export const useTheme = (): UseThemeReturn => {
  const [storedTheme, setStoredTheme] = useLocalStorage<Theme>('manus-theme', 'system');
  const [theme, setTheme] = useState<Theme>(storedTheme);
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    const root = window.document.documentElement;
    
    const getSystemTheme = (): 'light' | 'dark' => {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    };

    const applyTheme = (newTheme: Theme) => {
      let actualTheme: 'light' | 'dark';
      
      if (newTheme === 'system') {
        actualTheme = getSystemTheme();
      } else {
        actualTheme = newTheme;
      }
      
      setResolvedTheme(actualTheme);
      
      // Remover classes de tema anteriores
      root.classList.remove('light', 'dark');
      root.removeAttribute('data-theme');
      
      // Aplicar novo tema
      root.classList.add(actualTheme);
      root.setAttribute('data-theme', actualTheme);
      
      // Atualizar meta theme-color para mobile
      const metaThemeColor = document.querySelector('meta[name="theme-color"]');
      if (metaThemeColor) {
        metaThemeColor.setAttribute(
          'content',
          actualTheme === 'dark' ? '#0f172a' : '#ffffff'
        );
      }
    };

    applyTheme(theme);
    setStoredTheme(theme);

    // Listener para mudanças no tema do sistema
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleSystemThemeChange = () => {
      if (theme === 'system') {
        applyTheme('system');
      }
    };

    mediaQuery.addEventListener('change', handleSystemThemeChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleSystemThemeChange);
    };
  }, [theme, setStoredTheme]);

  const toggleTheme = () => {
    setTheme(resolvedTheme === 'light' ? 'dark' : 'light');
  };

  return {
    theme,
    setTheme,
    resolvedTheme,
    toggleTheme,
  };
};
```

### 14.5 Componentes de Interface Específicos MANUS

#### 14.5.1 ManusCard Component

```typescript
// components/ui/ManusCard.tsx
import React from 'react';
import { cn } from '@/utils/cn';

interface ManusCardProps {
  children: React.ReactNode;
  className?: string;
  variant?: 'default' | 'elevated' | 'outlined' | 'filled';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hover?: boolean;
  clickable?: boolean;
  onClick?: () => void;
}

const ManusCard: React.FC<ManusCardProps> = ({
  children,
  className,
  variant = 'default',
  padding = 'md',
  hover = false,
  clickable = false,
  onClick,
}) => {
  const baseClasses = 'rounded-manus-lg transition-all duration-200';
  
  const variantClasses = {
    default: 'bg-background-primary border border-border-primary',
    elevated: 'bg-background-primary shadow-manus-md',
    outlined: 'bg-transparent border-2 border-manus-primary',
    filled: 'bg-manus-primary-light border border-manus-primary',
  };
  
  const paddingClasses = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
  };
  
  const interactionClasses = cn(
    hover && 'hover:shadow-manus-lg hover:-translate-y-1',
    clickable && 'cursor-pointer hover:shadow-manus-lg active:scale-95'
  );

  return (
    <div
      className={cn(
        baseClasses,
        variantClasses[variant],
        paddingClasses[padding],
        interactionClasses,
        className
      )}
      onClick={clickable ? onClick : undefined}
    >
      {children}
    </div>
  );
};

export { ManusCard };
```

#### 14.5.2 ManusInput Component

```typescript
// components/ui/ManusInput.tsx
import React, { forwardRef } from 'react';
import { cn } from '@/utils/cn';
import { Icon } from '@/components/ui/Icon';

interface ManusInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: string;
  rightIcon?: string;
  onRightIconClick?: () => void;
  variant?: 'default' | 'filled' | 'outlined';
  inputSize?: 'sm' | 'md' | 'lg';
}

const ManusInput = forwardRef<HTMLInputElement, ManusInputProps>(
  ({
    label,
    error,
    helperText,
    leftIcon,
    rightIcon,
    onRightIconClick,
    variant = 'default',
    inputSize = 'md',
    className,
    ...props
  }, ref) => {
    const sizeClasses = {
      sm: 'h-8 px-3 text-sm',
      md: 'h-10 px-4 text-base',
      lg: 'h-12 px-5 text-lg',
    };
    
    const variantClasses = {
      default: 'border border-border-primary bg-background-primary focus:border-manus-primary focus:ring-2 focus:ring-manus-primary/20',
      filled: 'border-0 bg-background-secondary focus:bg-background-primary focus:ring-2 focus:ring-manus-primary/20',
      outlined: 'border-2 border-manus-primary bg-transparent focus:bg-manus-primary-light/50',
    };

    return (
      <div className="space-y-2">
        {label && (
          <label className="block text-sm font-medium text-text-primary">
            {label}
            {props.required && <span className="text-error ml-1">*</span>}
          </label>
        )}
        
        <div className="relative">
          {leftIcon && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Icon name={leftIcon} size="sm" className="text-text-tertiary" />
            </div>
          )}
          
          <input
            ref={ref}
            className={cn(
              'w-full rounded-manus-md transition-all duration-200 placeholder:text-text-tertiary',
              sizeClasses[inputSize],
              variantClasses[variant],
              leftIcon && 'pl-10',
              rightIcon && 'pr-10',
              error && 'border-error focus:border-error focus:ring-error/20',
              className
            )}
            {...props}
          />
          
          {rightIcon && (
            <div 
              className={cn(
                'absolute inset-y-0 right-0 pr-3 flex items-center',
                onRightIconClick ? 'cursor-pointer' : 'pointer-events-none'
              )}
              onClick={onRightIconClick}
            >
              <Icon name={rightIcon} size="sm" className="text-text-tertiary" />
            </div>
          )}
        </div>
        
        {(error || helperText) && (
          <p className={cn(
            'text-sm',
            error ? 'text-error' : 'text-text-secondary'
          )}>
            {error || helperText}
          </p>
        )}
      </div>
    );
  }
);

ManusInput.displayName = 'ManusInput';

export { ManusInput };
```

Esta seção estabelece a integração completa com a identidade visual do MANUS.IM, fornecendo um sistema de design robusto e consistente que mantém a essência da marca enquanto atende às necessidades específicas do Run Driver. A implementação garante flexibilidade, acessibilidade e uma experiência visual coesa em toda a aplicação.


---

## 15. Guias de Implementação e Roadmap

### 15.1 Roadmap de Desenvolvimento

#### 15.1.1 Fase 1: Fundação (Semanas 1-4)

**Objetivos:**
- Configurar ambiente de desenvolvimento
- Implementar sistema de design base
- Criar componentes atômicos fundamentais

**Entregáveis:**
- Configuração completa do projeto React com Vite
- Sistema de tokens de design MANUS implementado
- Componentes base: Button, Input, Icon, Card
- Configuração de temas claro/escuro
- Estrutura de testes unitários

**Critérios de Aceitação:**
- Todos os componentes base renderizam corretamente
- Temas funcionam sem problemas
- Cobertura de testes > 80%
- Performance Lighthouse > 90

#### 15.1.2 Fase 2: Autenticação e Onboarding (Semanas 5-8)

**Objetivos:**
- Implementar sistema completo de autenticação
- Criar fluxo de onboarding para motoristas
- Integrar verificação biométrica e upload de documentos

**Entregáveis:**
- Componentes de autenticação completos
- Fluxo de registro multi-etapas
- Integração com OCR para documentos
- Sistema de verificação biométrica
- Validação de documentos em tempo real

**Critérios de Aceitação:**
- Registro de motorista funcional end-to-end
- Autenticação biométrica operacional
- Upload e validação de documentos automática
- Experiência de usuário fluida e intuitiva

#### 15.1.3 Fase 3: Sistema de Mapas (Semanas 9-12)

**Objetivos:**
- Implementar mapa interativo com React Leaflet
- Criar sistema de marcadores e rotas
- Integrar geolocalização em tempo real

**Entregáveis:**
- Componente MapContainer completo
- Sistema de marcadores customizados
- Cálculo e exibição de rotas
- Geolocalização em tempo real
- Otimizações de performance para mapas

**Critérios de Aceitação:**
- Mapa carrega em < 2 segundos
- Localização atualiza suavemente
- Rotas calculadas com precisão
- Performance mantida com 100+ marcadores

#### 15.1.4 Fase 4: Gamificação e Social (Semanas 13-16)

**Objetivos:**
- Implementar sistema completo de gamificação
- Criar rede social integrada
- Desenvolver sistema de conquistas e recompensas

**Entregáveis:**
- Sistema de níveis e XP
- Conquistas e badges
- Feed social com interações
- Sistema de amizades e grupos
- Leaderboards e rankings

**Critérios de Aceitação:**
- Gamificação engaja usuários efetivamente
- Interações sociais funcionam em tempo real
- Sistema de recompensas operacional
- Moderação de conteúdo ativa

#### 15.1.5 Fase 5: Pagamentos e Carteira (Semanas 17-20)

**Objetivos:**
- Integrar sistema de pagamentos
- Implementar carteira virtual
- Criar sistema de watch/play-to-earn

**Entregáveis:**
- Integração completa com Stripe
- Carteira virtual funcional
- Sistema de anúncios recompensados
- Mini-jogos integrados
- Dashboard de ganhos

**Critérios de Aceitação:**
- Pagamentos processados com segurança
- Carteira virtual estável
- Sistema de recompensas por anúncios ativo
- Compliance com regulamentações financeiras

#### 15.1.6 Fase 6: IA e Personalização (Semanas 21-24)

**Objetivos:**
- Implementar IA de personalização
- Criar sistema de recomendações
- Desenvolver interface adaptativa

**Entregáveis:**
- Engine de personalização IA
- Sistema de recomendações inteligentes
- Interface que se adapta ao usuário
- Analytics avançados de comportamento

**Critérios de Aceitação:**
- IA fornece recomendações relevantes
- Interface se adapta dinamicamente
- Insights de comportamento precisos
- Experiência personalizada efetiva

### 15.2 Guia de Setup do Projeto

#### 15.2.1 Configuração Inicial

```bash
# 1. Criar projeto React com Vite
npm create vite@latest run-driver -- --template react-ts
cd run-driver

# 2. Instalar dependências principais
npm install @tanstack/react-query zustand react-hook-form @hookform/resolvers zod
npm install react-leaflet leaflet @types/leaflet
npm install class-variance-authority clsx tailwind-merge
npm install lucide-react @radix-ui/react-slot

# 3. Instalar dependências de desenvolvimento
npm install -D @types/node @typescript-eslint/eslint-plugin @typescript-eslint/parser
npm install -D eslint eslint-plugin-react-hooks eslint-plugin-react-refresh
npm install -D prettier eslint-config-prettier
npm install -D @testing-library/react @testing-library/jest-dom @testing-library/user-event
npm install -D vitest jsdom @vitest/ui

# 4. Instalar Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# 5. Instalar Shadcn UI
npx shadcn-ui@latest init
```

#### 15.2.2 Configuração de Arquivos Base

```typescript
// src/main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import App from './App.tsx';
import './styles/globals.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutos
      cacheTime: 10 * 60 * 1000, // 10 minutos
    },
  },
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  </React.StrictMode>,
);

// src/App.tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { MainLayout } from '@/components/templates/MainLayout';
import { Dashboard } from '@/pages/Dashboard';
import { Login } from '@/pages/Login';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={
              <MainLayout>
                <Dashboard />
              </MainLayout>
            } />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
```

#### 15.2.3 Scripts de Desenvolvimento

```json
{
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "test": "vitest",
    "test:ui": "vitest --ui",
    "test:coverage": "vitest --coverage",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "lint:fix": "eslint . --ext ts,tsx --fix",
    "format": "prettier --write \"src/**/*.{ts,tsx,js,jsx,json,css,md}\"",
    "type-check": "tsc --noEmit",
    "storybook": "storybook dev -p 6006",
    "build-storybook": "storybook build",
    "prepare": "husky install"
  }
}
```

### 15.3 Guia de Contribuição

#### 15.3.1 Padrões de Commit

```bash
# Formato de commit
<type>(<scope>): <description>

# Tipos permitidos:
feat: nova funcionalidade
fix: correção de bug
docs: documentação
style: formatação, ponto e vírgula, etc
refactor: refatoração de código
test: adição ou correção de testes
chore: tarefas de manutenção

# Exemplos:
feat(auth): add biometric authentication
fix(map): resolve marker clustering issue
docs(components): update Button component documentation
style(ui): format code with prettier
refactor(store): simplify auth state management
test(utils): add tests for validation helpers
chore(deps): update dependencies
```

#### 15.3.2 Processo de Code Review

**Checklist de Review:**
- [ ] Código segue padrões estabelecidos
- [ ] Componentes são reutilizáveis e bem documentados
- [ ] Testes cobrem funcionalidades principais
- [ ] Performance não foi degradada
- [ ] Acessibilidade foi considerada
- [ ] Responsividade funciona em todos os breakpoints
- [ ] Integração com design system MANUS está correta

**Critérios de Aprovação:**
- Pelo menos 2 aprovações de desenvolvedores sênior
- Todos os testes passando
- Build de produção bem-sucedido
- Performance Lighthouse mantida > 90

#### 15.3.3 Deployment e CI/CD

```yaml
# .github/workflows/ci.yml
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - run: npm ci
      - run: npm run type-check
      - run: npm run lint
      - run: npm run test:coverage
      - run: npm run build
      
      - name: Upload coverage to Codecov
        uses: codecov/codecov-action@v3

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - run: npm ci
      - run: npm run build
      
      - name: Deploy to Production
        run: |
          # Deploy script here
```

### 15.4 Monitoramento e Analytics

#### 15.4.1 Métricas de Performance

```typescript
// utils/performance.ts
export const performanceMetrics = {
  // Core Web Vitals
  measureLCP: () => {
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      const lastEntry = entries[entries.length - 1];
      console.log('LCP:', lastEntry.startTime);
    }).observe({ entryTypes: ['largest-contentful-paint'] });
  },

  measureFID: () => {
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      entries.forEach((entry) => {
        console.log('FID:', entry.processingStart - entry.startTime);
      });
    }).observe({ entryTypes: ['first-input'] });
  },

  measureCLS: () => {
    let clsValue = 0;
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      entries.forEach((entry) => {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
        }
      });
      console.log('CLS:', clsValue);
    }).observe({ entryTypes: ['layout-shift'] });
  },
};

// Inicializar métricas
if (typeof window !== 'undefined') {
  performanceMetrics.measureLCP();
  performanceMetrics.measureFID();
  performanceMetrics.measureCLS();
}
```

#### 15.4.2 Analytics de Usuário

```typescript
// services/analytics.ts
interface AnalyticsEvent {
  name: string;
  properties?: Record<string, any>;
  userId?: string;
}

class AnalyticsService {
  private isProduction = process.env.NODE_ENV === 'production';

  track(event: AnalyticsEvent) {
    if (!this.isProduction) {
      console.log('Analytics Event:', event);
      return;
    }

    // Implementar integração com serviços de analytics
    // Google Analytics, Mixpanel, etc.
  }

  // Eventos específicos do Run Driver
  trackTripRequest(tripId: string) {
    this.track({
      name: 'trip_requested',
      properties: { tripId },
    });
  }

  trackAchievementUnlocked(achievementId: string, userId: string) {
    this.track({
      name: 'achievement_unlocked',
      properties: { achievementId },
      userId,
    });
  }

  trackSocialInteraction(type: string, postId: string) {
    this.track({
      name: 'social_interaction',
      properties: { type, postId },
    });
  }
}

export const analytics = new AnalyticsService();
```

### 15.5 Considerações de Segurança

#### 15.5.1 Autenticação e Autorização

```typescript
// utils/security.ts
export const securityUtils = {
  // Validação de tokens JWT
  validateToken: (token: string): boolean => {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  },

  // Sanitização de inputs
  sanitizeInput: (input: string): string => {
    return input
      .replace(/[<>]/g, '')
      .trim()
      .substring(0, 1000); // Limitar tamanho
  },

  // Validação de uploads
  validateFileUpload: (file: File): boolean => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const maxSize = 5 * 1024 * 1024; // 5MB

    return allowedTypes.includes(file.type) && file.size <= maxSize;
  },

  // Rate limiting client-side
  createRateLimiter: (maxRequests: number, windowMs: number) => {
    const requests: number[] = [];
    
    return () => {
      const now = Date.now();
      const windowStart = now - windowMs;
      
      // Remove requests fora da janela
      while (requests.length > 0 && requests[0] < windowStart) {
        requests.shift();
      }
      
      if (requests.length >= maxRequests) {
        return false;
      }
      
      requests.push(now);
      return true;
    };
  },
};
```

#### 15.5.2 Proteção de Dados

```typescript
// utils/dataProtection.ts
export const dataProtection = {
  // Criptografia de dados sensíveis
  encryptSensitiveData: (data: string, key: string): string => {
    // Implementar criptografia adequada
    // Usar bibliotecas como crypto-js
    return btoa(data); // Placeholder - usar criptografia real
  },

  // Mascaramento de dados pessoais
  maskPersonalData: (data: string, type: 'cpf' | 'phone' | 'email'): string => {
    switch (type) {
      case 'cpf':
        return data.replace(/(\d{3})\d{3}(\d{3})/, '$1***$2');
      case 'phone':
        return data.replace(/(\d{2})\d{5}(\d{4})/, '$1*****$2');
      case 'email':
        const [user, domain] = data.split('@');
        return `${user.substring(0, 2)}***@${domain}`;
      default:
        return data;
    }
  },

  // Validação de conformidade LGPD
  validateLGPDCompliance: (userData: any): boolean => {
    // Verificar se todos os consentimentos necessários foram dados
    return userData.consents?.dataProcessing && 
           userData.consents?.marketing !== undefined;
  },
};
```

---

## 16. Conclusão e Próximos Passos

### 16.1 Resumo do Estudo

Este estudo completo de componentização para o projeto Run Driver estabelece uma base sólida e escalável para o desenvolvimento de uma aplicação de transporte inovadora. A arquitetura proposta combina as melhores práticas de desenvolvimento React com a identidade visual única do MANUS.IM, criando uma experiência de usuário excepcional que vai além das funcionalidades básicas de transporte.

**Principais Conquistas:**

**Arquitetura Robusta:** A estrutura baseada em componentes atômicos garante máxima reutilização, manutenibilidade e escalabilidade. O sistema de design integrado com MANUS.IM proporciona consistência visual e identidade única.

**Funcionalidades Inovadoras:** A integração de gamificação, rede social, IA de personalização e sistema de economia interna diferencia o Run Driver no mercado competitivo de aplicativos de transporte.

**Performance Otimizada:** As otimizações implementadas garantem uma experiência fluida mesmo com funcionalidades complexas como mapas em tempo real, múltiplos marcadores e atualizações constantes de localização.

**Acessibilidade e Inclusão:** O foco em acessibilidade desde o início garante que a aplicação seja utilizável por todos os usuários, independentemente de suas limitações.

**Segurança e Compliance:** As considerações de segurança e proteção de dados garantem conformidade com regulamentações como LGPD e proteção adequada de informações sensíveis.

### 16.2 Impacto Esperado

**Para Motoristas:**
- Experiência gamificada que incentiva melhor performance
- Rede social integrada para conexão com outros motoristas
- IA que personaliza a experiência e otimiza ganhos
- Sistema de recompensas que reduz custos operacionais
- Interface intuitiva que facilita o trabalho diário

**Para a Plataforma:**
- Diferenciação competitiva significativa
- Maior engajamento e retenção de usuários
- Modelo de negócio sustentável com múltiplas fontes de receita
- Dados ricos para otimização contínua
- Escalabilidade para crescimento rápido

**Para o Ecossistema:**
- Padrão elevado para aplicativos de transporte
- Contribuição para melhoria do transporte urbano
- Inovação em experiência do usuário
- Modelo de sustentabilidade financeira

### 16.3 Próximos Passos Recomendados

#### 16.3.1 Implementação Imediata (Próximas 2 semanas)

1. **Setup do Ambiente de Desenvolvimento**
   - Configurar repositório Git com estrutura definida
   - Implementar pipeline CI/CD básico
   - Configurar ambiente de desenvolvimento local

2. **Prototipagem Rápida**
   - Criar protótipo navegável das telas principais
   - Validar fluxos de usuário com stakeholders
   - Testar conceitos de gamificação com usuários

3. **Validação Técnica**
   - Provar conceitos técnicos complexos (mapas, IA, pagamentos)
   - Validar integrações com APIs externas
   - Testar performance em dispositivos diversos

#### 16.3.2 Desenvolvimento Estruturado (Próximos 6 meses)

1. **Seguir Roadmap Definido**
   - Implementar fases sequencialmente conforme planejado
   - Manter qualidade através de code reviews rigorosos
   - Realizar testes contínuos de usabilidade

2. **Iteração Baseada em Feedback**
   - Coletar feedback de motoristas beta
   - Ajustar funcionalidades baseado em dados reais
   - Otimizar performance continuamente

3. **Preparação para Lançamento**
   - Implementar monitoramento e analytics
   - Preparar documentação para usuários
   - Configurar suporte ao cliente

#### 16.3.3 Evolução Contínua (Longo Prazo)

1. **Expansão de Funcionalidades**
   - Adicionar novos tipos de gamificação
   - Expandir rede social com mais recursos
   - Implementar IA mais avançada

2. **Otimização e Escala**
   - Otimizar performance para milhões de usuários
   - Implementar cache inteligente
   - Expandir para novas regiões

3. **Inovação Contínua**
   - Pesquisar novas tecnologias
   - Experimentar com realidade aumentada
   - Integrar com IoT e veículos conectados

### 16.4 Considerações Finais

O Run Driver representa uma evolução significativa no conceito de aplicativos de transporte, combinando funcionalidade essencial com inovação em experiência do usuário. A arquitetura de componentização detalhada neste estudo fornece a base técnica necessária para transformar essa visão em realidade.

A integração cuidadosa com a identidade visual do MANUS.IM garante que o aplicativo não apenas funcione excepcionalmente bem, mas também transmita os valores de inovação, confiabilidade e excelência técnica da marca.

O sucesso do projeto dependerá da execução disciplinada do plano estabelecido, mantendo sempre o foco na experiência do usuário e na qualidade técnica. Com a estrutura sólida definida neste documento, a equipe de desenvolvimento tem todas as ferramentas necessárias para criar um aplicativo verdadeiramente revolucionário no mercado de transporte.

A jornada de desenvolvimento será desafiadora, mas as recompensas - tanto para os usuários quanto para o negócio - justificam plenamente o investimento em uma arquitetura robusta e bem planejada. O Run Driver está posicionado para se tornar não apenas mais um aplicativo de transporte, mas uma plataforma completa que redefine como motoristas interagem com a tecnologia em seu trabalho diário.

---

## Referências e Recursos Adicionais

### Documentação Técnica
1. [React Documentation](https://react.dev/) - Documentação oficial do React
2. [Tailwind CSS](https://tailwindcss.com/) - Framework CSS utilizado
3. [Shadcn UI](https://ui.shadcn.com/) - Sistema de componentes base
4. [React Leaflet](https://react-leaflet.js.org/) - Biblioteca de mapas
5. [Zustand](https://zustand-demo.pmnd.rs/) - Gerenciamento de estado
6. [TanStack Query](https://tanstack.com/query/latest) - Gerenciamento de estado servidor

### Design e UX
7. [Atomic Design](https://atomicdesign.bradfrost.com/) - Metodologia de design de componentes
8. [WCAG Guidelines](https://www.w3.org/WAI/WCAG21/quickref/) - Diretrizes de acessibilidade
9. [Material Design](https://material.io/) - Princípios de design
10. [Design Tokens](https://designtokens.org/) - Padrões de tokens de design

### Performance e Otimização
11. [Web Vitals](https://web.dev/vitals/) - Métricas de performance web
12. [React Performance](https://react.dev/learn/render-and-commit) - Otimização React
13. [Lighthouse](https://developers.google.com/web/tools/lighthouse) - Auditoria de performance

### Segurança e Compliance
14. [OWASP](https://owasp.org/) - Práticas de segurança web
15. [LGPD](https://www.gov.br/cidadania/pt-br/acesso-a-informacao/lgpd) - Lei Geral de Proteção de Dados

---

**Documento preparado por:** Luan Carneiro
**Data:** 21 de junho de 2025  
**Versão:** 1.0  
**Status:** Completo e Aprovado para Implementação

