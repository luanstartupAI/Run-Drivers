# 🚗 Run Driver - O Melhor App para Motoristas

![Run Driver](https://img.shields.io/badge/Run%20Driver-v1.0.0-7CB342?style=for-the-badge&logo=react)
![Status](https://img.shields.io/badge/Status-Em%20Desenvolvimento-yellow?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-blue?style=for-the-badge)

## 📋 Sobre o Projeto

O **Run Driver** é uma aplicação revolucionária para motoristas que combina funcionalidades essenciais de transporte com inovações em gamificação, rede social e IA de personalização. Desenvolvido com foco na experiência do usuário e na maximização dos lucros dos motoristas.

### ✨ Características Principais

- 🎮 **Gamificação Completa**: Sistema de níveis, XP, conquistas e recompensas
- 🤝 **Rede Social Integrada**: Conecte-se com outros motoristas
- 🧠 **IA de Personalização**: Experiência adaptada ao perfil do usuário
- 💰 **Carteira Virtual**: Sistema de pagamentos e recompensas por anúncios
- 🗺️ **Mapas Avançados**: Integração com React Leaflet
- 🔐 **Autenticação Robusta**: Sistema completo com verificação biométrica
- 🌙 **Temas Claro/Escuro**: Interface adaptável
- 📱 **Design Responsivo**: Funciona perfeitamente em todos os dispositivos

## 🛠️ Tecnologias Utilizadas

### Frontend
- **React 19** - Biblioteca principal
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Framework CSS
- **Shadcn/UI** - Componentes base
- **Lucide React** - Ícones
- **Framer Motion** - Animações

### Estado e Dados
- **Zustand** - Gerenciamento de estado
- **TanStack Query** - Cache e sincronização de dados
- **React Hook Form** - Formulários
- **Zod** - Validação de schemas

### Mapas e Localização
- **React Leaflet** - Mapas interativos
- **Leaflet** - Biblioteca de mapas

### Roteamento
- **React Router DOM** - Navegação

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+
- pnpm (recomendado) ou npm

### Instalação

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/run-driver.git

# Entre no diretório
cd run-driver

# Instale as dependências
pnpm install

# Inicie o servidor de desenvolvimento
pnpm run dev
```

A aplicação estará disponível em `http://localhost:5173`

### Scripts Disponíveis

```bash
# Desenvolvimento
pnpm run dev

# Build para produção
pnpm run build

# Preview da build
pnpm run preview

# Linting
pnpm run lint
```

## 📁 Estrutura do Projeto

```
src/
├── components/          # Componentes React
│   ├── atoms/          # Componentes atômicos (Button, Input, etc.)
│   ├── molecules/      # Componentes moleculares (LoginForm, etc.)
│   ├── organisms/      # Componentes organismos (Header, etc.)
│   ├── templates/      # Templates de página
│   └── ui/            # Componentes UI base (shadcn)
├── pages/              # Páginas da aplicação
│   ├── auth/          # Páginas de autenticação
│   ├── dashboard/     # Dashboard principal
│   ├── profile/       # Perfil do usuário
│   ├── trips/         # Viagens
│   ├── social/        # Rede social
│   ├── gamification/  # Gamificação
│   └── wallet/        # Carteira
├── stores/             # Stores Zustand
├── services/           # Serviços e APIs
├── hooks/              # Custom hooks
├── contexts/           # Contextos React
├── utils/              # Utilitários
├── types/              # Tipos TypeScript
├── constants/          # Constantes e tokens
├── styles/             # Estilos globais
└── assets/             # Assets estáticos
```

## 🎨 Design System MANUS

O projeto utiliza o design system baseado na identidade visual do MANUS.IM:

### Cores Principais
- **Verde MANUS**: `#7CB342` - Cor principal da marca
- **Verde Hover**: `#6A9B38` - Estado hover
- **Verde Claro**: `#F0F9E8` - Backgrounds claros

### Componentes Base
- **Button**: Botões com variantes MANUS
- **Input**: Campos de entrada personalizados
- **Card**: Cards com variantes específicas
- **Icon**: Biblioteca de ícones customizada

## 🔐 Autenticação e Segurança

### Funcionalidades Implementadas
- ✅ Login/Logout
- ✅ Registro de usuários
- ✅ Validação de formulários
- ✅ Gerenciamento de tokens
- ✅ Rotas protegidas

### Simulações para Desenvolvimento
- 🔄 **API de Autenticação**: Simulada com delays realistas
- 🔄 **Upload de Documentos**: Simulação de OCR
- 🔄 **Verificação Biométrica**: Simulação de processamento
- 🔄 **Banco de Dados**: Mock local para desenvolvimento

## 📱 Funcionalidades Principais

### Dashboard
- 📊 Estatísticas de ganhos
- 🗺️ Mapa de viagens (em desenvolvimento)
- 📈 Progresso de gamificação
- 🏆 Conquistas recentes
- ⚡ Ações rápidas

### Sistema de Gamificação
- 🎯 Níveis e XP
- 🏅 Conquistas e badges
- 📊 Leaderboards
- 🎁 Sistema de recompensas

### Rede Social (Planejado)
- 👥 Feed de atividades
- 💬 Comentários e likes
- 🤝 Sistema de amizades
- 📸 Compartilhamento de conquistas

### Carteira Virtual (Planejado)
- 💳 Integração com Stripe
- 🎮 Recompensas por jogos
- 📺 Recompensas por anúncios
- 💰 Histórico de transações

## 🔧 Configurações de Desenvolvimento

### Variáveis de Ambiente
```env
# API Base URL (quando implementada)
VITE_API_BASE_URL=https://api.rundriver.com

# Stripe (para pagamentos)
VITE_STRIPE_PUBLIC_KEY=pk_test_...

# Mapbox (para mapas avançados)
VITE_MAPBOX_TOKEN=pk.eyJ1...
```

### Configuração do Tailwind
O projeto utiliza configuração customizada do Tailwind com:
- Cores MANUS personalizadas
- Animações específicas
- Componentes utilitários
- Suporte a temas claro/escuro

## 🚧 Próximos Passos

### Fase 2: Sistema de Mapas
- [ ] Integração completa com React Leaflet
- [ ] Geolocalização em tempo real
- [ ] Cálculo de rotas
- [ ] Marcadores customizados

### Fase 3: APIs Reais
- [ ] Substituir simulações por APIs reais
- [ ] Integração com backend
- [ ] Autenticação JWT real
- [ ] Upload de documentos real

### Fase 4: Funcionalidades Avançadas
- [ ] Sistema de pagamentos (Stripe)
- [ ] Verificação biométrica real
- [ ] IA de personalização
- [ ] Push notifications

### Fase 5: Rede Social
- [ ] Feed de atividades
- [ ] Sistema de comentários
- [ ] Gamificação social
- [ ] Moderação de conteúdo

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 🤝 Contribuição

Contribuições são bem-vindas! Por favor, leia o [CONTRIBUTING.md](CONTRIBUTING.md) para detalhes sobre nosso código de conduta e processo de submissão de pull requests.

## 📞 Suporte

Para suporte, envie um email para suporte@rundriver.com ou abra uma issue no GitHub.

---

**Run Driver** - Transformando a experiência dos motoristas no mundo inteiro! 🚗✨

