// Serviço de autenticação com simulações de API
// NOTA: Este arquivo contém simulações para desenvolvimento
// Em produção, substituir pelas chamadas reais da API

import { generateId } from '../utils';

// Simulação de delay de rede
const simulateNetworkDelay = (min = 500, max = 1500) => {
  const delay = Math.random() * (max - min) + min;
  return new Promise(resolve => setTimeout(resolve, delay));
};

// Simulação de banco de dados local
const mockDatabase = {
  users: [
    {
      id: '1',
      email: 'motorista@exemplo.com',
      password: '123456', // Em produção, usar hash
      name: 'João Silva',
      phone: '(11) 99999-9999',
      type: 'driver',
      verified: false,
      onboardingCompleted: false,
      biometricVerified: false,
      documents: [],
      createdAt: new Date().toISOString(),
    }
  ],
  tokens: new Map(),
};

// Simulação de validação de token JWT
const generateToken = (userId) => {
  const token = `mock_token_${userId}_${Date.now()}`;
  mockDatabase.tokens.set(token, {
    userId,
    expiresAt: Date.now() + (24 * 60 * 60 * 1000), // 24 horas
  });
  return token;
};

const validateToken = (token) => {
  const tokenData = mockDatabase.tokens.get(token);
  if (!tokenData) return null;
  
  if (Date.now() > tokenData.expiresAt) {
    mockDatabase.tokens.delete(token);
    return null;
  }
  
  return tokenData;
};

export const authService = {
  // Login do usuário
  async login(credentials) {
    await simulateNetworkDelay();
    
    const { email, password, rememberMe } = credentials;
    
    // Validação básica
    if (!email || !password) {
      return {
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Email e senha são obrigatórios',
        },
      };
    }

    // Buscar usuário no mock database
    const user = mockDatabase.users.find(u => u.email === email);
    
    if (!user || user.password !== password) {
      return {
        success: false,
        error: {
          code: 'INVALID_CREDENTIALS',
          message: 'Email ou senha incorretos',
        },
      };
    }

    // Gerar token
    const token = generateToken(user.id);
    
    // Remover senha do retorno
    const { password: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      data: {
        user: userWithoutPassword,
        token,
      },
    };
  },

  // Registro de novo usuário
  async register(userData) {
    await simulateNetworkDelay();
    
    const { email, password, confirmPassword, phone, name, acceptTerms } = userData;
    
    // Validações
    if (!email || !password || !phone || !name) {
      return {
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Todos os campos são obrigatórios',
        },
      };
    }

    if (password !== confirmPassword) {
      return {
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Senhas não coincidem',
        },
      };
    }

    if (!acceptTerms) {
      return {
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'É necessário aceitar os termos de uso',
        },
      };
    }

    // Verificar se email já existe
    const existingUser = mockDatabase.users.find(u => u.email === email);
    if (existingUser) {
      return {
        success: false,
        error: {
          code: 'EMAIL_EXISTS',
          message: 'Este email já está cadastrado',
        },
      };
    }

    // Criar novo usuário
    const newUser = {
      id: generateId(),
      email,
      password, // Em produção, fazer hash
      name,
      phone,
      type: 'driver',
      verified: false,
      onboardingCompleted: false,
      biometricVerified: false,
      documents: [],
      createdAt: new Date().toISOString(),
    };

    mockDatabase.users.push(newUser);

    return {
      success: true,
      data: {
        message: 'Conta criada com sucesso',
      },
    };
  },

  // Logout
  async logout() {
    await simulateNetworkDelay(200, 500);
    
    // Em produção, invalidar token no servidor
    return {
      success: true,
      data: {
        message: 'Logout realizado com sucesso',
      },
    };
  },

  // Verificar token
  async verifyToken(token) {
    await simulateNetworkDelay(200, 800);
    
    const tokenData = validateToken(token);
    
    if (!tokenData) {
      return {
        success: false,
        error: {
          code: 'INVALID_TOKEN',
          message: 'Token inválido ou expirado',
        },
      };
    }

    const user = mockDatabase.users.find(u => u.id === tokenData.userId);
    
    if (!user) {
      return {
        success: false,
        error: {
          code: 'USER_NOT_FOUND',
          message: 'Usuário não encontrado',
        },
      };
    }

    const { password: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      data: {
        user: userWithoutPassword,
      },
    };
  },

  // Renovar token
  async refreshToken(currentToken) {
    await simulateNetworkDelay(300, 700);
    
    const tokenData = validateToken(currentToken);
    
    if (!tokenData) {
      return {
        success: false,
        error: {
          code: 'INVALID_TOKEN',
          message: 'Token inválido',
        },
      };
    }

    // Invalidar token atual
    mockDatabase.tokens.delete(currentToken);
    
    // Gerar novo token
    const newToken = generateToken(tokenData.userId);
    
    const user = mockDatabase.users.find(u => u.id === tokenData.userId);
    const { password: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      data: {
        token: newToken,
        user: userWithoutPassword,
      },
    };
  },

  // Atualizar perfil
  async updateProfile(profileData) {
    await simulateNetworkDelay();
    
    // Em produção, validar token e permissões
    const { userId, ...updateData } = profileData;
    
    const userIndex = mockDatabase.users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
      return {
        success: false,
        error: {
          code: 'USER_NOT_FOUND',
          message: 'Usuário não encontrado',
        },
      };
    }

    // Atualizar dados
    mockDatabase.users[userIndex] = {
      ...mockDatabase.users[userIndex],
      ...updateData,
      updatedAt: new Date().toISOString(),
    };

    const { password: _, ...userWithoutPassword } = mockDatabase.users[userIndex];
    
    return {
      success: true,
      data: userWithoutPassword,
    };
  },

  // Upload de documento
  async uploadDocument(documentData) {
    await simulateNetworkDelay(1000, 3000); // Simular upload mais lento
    
    const { userId, type, file } = documentData;
    
    // Simular validação de arquivo
    if (!file || file.size > 5 * 1024 * 1024) {
      return {
        success: false,
        error: {
          code: 'INVALID_FILE',
          message: 'Arquivo inválido ou muito grande',
        },
      };
    }

    // Simular upload e OCR
    const document = {
      id: generateId(),
      type,
      url: `https://mock-storage.com/documents/${generateId()}.jpg`,
      status: 'pending',
      uploadedAt: new Date().toISOString(),
      // Simular dados extraídos por OCR
      extractedData: type === 'driver_license' ? {
        number: '123456789',
        category: 'B',
        expiryDate: '2025-12-31',
      } : null,
    };

    // Adicionar documento ao usuário
    const userIndex = mockDatabase.users.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      mockDatabase.users[userIndex].documents.push(document);
    }

    return {
      success: true,
      data: document,
    };
  },

  // Verificação biométrica
  async verifyBiometric(biometricData) {
    await simulateNetworkDelay(2000, 4000); // Simular processamento biométrico
    
    const { userId, type, data } = biometricData;
    
    // Simular validação biométrica
    // Em produção, usar serviços como AWS Rekognition, Azure Face API, etc.
    const isValid = Math.random() > 0.1; // 90% de sucesso para simulação
    
    if (!isValid) {
      return {
        success: false,
        error: {
          code: 'BIOMETRIC_VERIFICATION_FAILED',
          message: 'Falha na verificação biométrica. Tente novamente.',
        },
      };
    }

    // Atualizar status do usuário
    const userIndex = mockDatabase.users.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      mockDatabase.users[userIndex].biometricVerified = true;
    }

    return {
      success: true,
      data: {
        verified: true,
        confidence: 0.95,
      },
    };
  },

  // Recuperação de senha
  async forgotPassword(email) {
    await simulateNetworkDelay();
    
    const user = mockDatabase.users.find(u => u.email === email);
    
    if (!user) {
      // Por segurança, não revelar se o email existe
      return {
        success: true,
        data: {
          message: 'Se o email estiver cadastrado, você receberá instruções para redefinir sua senha.',
        },
      };
    }

    // Simular envio de email
    console.log(`[SIMULAÇÃO] Email de recuperação enviado para: ${email}`);
    
    return {
      success: true,
      data: {
        message: 'Instruções enviadas para seu email.',
      },
    };
  },

  // Redefinir senha
  async resetPassword(resetData) {
    await simulateNetworkDelay();
    
    const { token, newPassword } = resetData;
    
    // Simular validação de token de reset
    // Em produção, validar token criptografado
    
    return {
      success: true,
      data: {
        message: 'Senha redefinida com sucesso.',
      },
    };
  },
};

// INSTRUÇÕES PARA PRODUÇÃO:
// 
// 1. AUTENTICAÇÃO:
//    - Substituir simulações por chamadas reais à API
//    - Implementar JWT real com chaves secretas
//    - Usar HTTPS obrigatório
//    - Implementar rate limiting
//
// 2. SENHAS:
//    - Usar bcrypt ou argon2 para hash de senhas
//    - Implementar política de senhas forte
//    - Adicionar autenticação de dois fatores (2FA)
//
// 3. UPLOAD DE DOCUMENTOS:
//    - Integrar com AWS S3, Google Cloud Storage ou similar
//    - Implementar OCR real (AWS Textract, Google Vision API)
//    - Adicionar validação de documentos brasileiros
//    - Implementar compressão e otimização de imagens
//
// 4. VERIFICAÇÃO BIOMÉTRICA:
//    - Integrar com AWS Rekognition, Azure Face API ou similar
//    - Implementar liveness detection
//    - Adicionar validação de qualidade da imagem
//    - Considerar LGPD para dados biométricos
//
// 5. SEGURANÇA:
//    - Implementar CSRF protection
//    - Adicionar headers de segurança
//    - Usar Content Security Policy (CSP)
//    - Implementar logging de segurança
//    - Adicionar monitoramento de tentativas de login
//
// 6. COMPLIANCE:
//    - Implementar conformidade com LGPD
//    - Adicionar termos de uso e política de privacidade
//    - Implementar consentimento granular
//    - Adicionar auditoria de dados

