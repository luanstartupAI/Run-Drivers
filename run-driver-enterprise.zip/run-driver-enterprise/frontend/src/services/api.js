import axios from 'axios';

// Configuração base da API
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token de autenticação
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor para tratar respostas e erros
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expirado ou inválido
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_data');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Serviços de Autenticação
export const authService = {
  async login(email, password) {
    const response = await api.post('/api/auth/login', { email, password });
    return response.data;
  },

  async register(userData) {
    const response = await api.post('/api/auth/register', userData);
    return response.data;
  },

  async logout() {
    const response = await api.post('/api/auth/logout');
    return response.data;
  },

  async verifyToken() {
    const response = await api.post('/api/auth/verify-token');
    return response.data;
  },

  async refreshToken() {
    const response = await api.post('/api/auth/refresh-token');
    return response.data;
  }
};

// Serviços de Motorista
export const driverService = {
  async getProfile() {
    const response = await api.get('/api/drivers/profile');
    return response.data;
  },

  async updateProfile(profileData) {
    const response = await api.put('/api/drivers/profile', profileData);
    return response.data;
  },

  async updateLocation(lat, lng) {
    const response = await api.put('/api/drivers/location', { lat, lng });
    return response.data;
  },

  async updateStatus(status) {
    const response = await api.put('/api/drivers/status', status);
    return response.data;
  },

  async getDashboard() {
    const response = await api.get('/api/drivers/dashboard');
    return response.data;
  },

  async getNearbyDrivers(lat, lng, radius = 10) {
    const response = await api.get('/api/drivers/nearby', {
      params: { lat, lng, radius }
    });
    return response.data;
  },

  async getLeaderboard(period = 'week', limit = 10) {
    const response = await api.get('/api/drivers/leaderboard', {
      params: { period, limit }
    });
    return response.data;
  }
};

// Serviços de Viagens
export const tripService = {
  async getTrips(page = 1, perPage = 10, status = null) {
    const params = { page, per_page: perPage };
    if (status) params.status = status;
    
    const response = await api.get('/api/trips', { params });
    return response.data;
  },

  async getTrip(tripId) {
    const response = await api.get(`/api/trips/${tripId}`);
    return response.data;
  },

  async createTrip(tripData) {
    const response = await api.post('/api/trips', tripData);
    return response.data;
  },

  async acceptTrip(tripId) {
    const response = await api.post(`/api/trips/${tripId}/accept`);
    return response.data;
  },

  async startTrip(tripId) {
    const response = await api.post(`/api/trips/${tripId}/start`);
    return response.data;
  },

  async completeTrip(tripId) {
    const response = await api.post(`/api/trips/${tripId}/complete`);
    return response.data;
  },

  async cancelTrip(tripId) {
    const response = await api.post(`/api/trips/${tripId}/cancel`);
    return response.data;
  },

  async rateTrip(tripId, rating, comment = '') {
    const response = await api.post(`/api/trips/${tripId}/rate`, {
      rating,
      comment
    });
    return response.data;
  },

  async getAvailableTrips(radius = 10) {
    const response = await api.get('/api/trips/available', {
      params: { radius }
    });
    return response.data;
  }
};

// Serviços de IA
export const aiService = {
  async getLocationRecommendations() {
    const response = await api.get('/api/ai/recommendations/locations');
    return response.data;
  },

  async getScheduleRecommendations() {
    const response = await api.get('/api/ai/recommendations/schedule');
    return response.data;
  },

  async getPersonalizationProfile() {
    const response = await api.get('/api/ai/personalization/profile');
    return response.data;
  },

  async optimizeTripMatching(tripId) {
    const response = await api.post('/api/ai/matching/optimize', { trip_id: tripId });
    return response.data;
  },

  async predictDemand(lat, lng, hours = 2) {
    const response = await api.get('/api/ai/predictions/demand', {
      params: { lat, lng, hours }
    });
    return response.data;
  },

  async getPerformanceAnalytics() {
    const response = await api.get('/api/ai/analytics/performance');
    return response.data;
  },

  async sendChatbotMessage(message) {
    const response = await api.post('/api/ai/chatbot/message', { message });
    return response.data;
  }
};

// Serviços de Gamificação
export const gamificationService = {
  async getAchievements() {
    const response = await api.get('/api/gamification/achievements');
    return response.data;
  },

  async getLeaderboard(period = 'week', limit = 10) {
    const response = await api.get('/api/gamification/leaderboard', {
      params: { period, limit }
    });
    return response.data;
  },

  async getChallenges() {
    const response = await api.get('/api/gamification/challenges');
    return response.data;
  }
};

// Serviços de Documentos
export const documentService = {
  async getDocuments() {
    const response = await api.get('/api/documents');
    return response.data;
  },

  async uploadDocument(type, url) {
    const response = await api.post('/api/documents/upload', { type, url });
    return response.data;
  }
};

// Serviços Sociais
export const socialService = {
  async getFeed(page = 1, perPage = 10) {
    const response = await api.get('/api/social/feed', {
      params: { page, per_page: perPage }
    });
    return response.data;
  },

  async createPost(content, imageUrl = null, location = null) {
    const postData = { content };
    if (imageUrl) postData.image_url = imageUrl;
    if (location) {
      postData.location_lat = location.lat;
      postData.location_lng = location.lng;
      postData.location_name = location.name;
    }

    const response = await api.post('/api/social/posts', postData);
    return response.data;
  },

  async likePost(postId) {
    const response = await api.post(`/api/social/posts/${postId}/like`);
    return response.data;
  },

  async getComments(postId) {
    const response = await api.get(`/api/social/posts/${postId}/comments`);
    return response.data;
  },

  async createComment(postId, content) {
    const response = await api.post(`/api/social/posts/${postId}/comments`, {
      content
    });
    return response.data;
  },

  async deletePost(postId) {
    const response = await api.delete(`/api/social/posts/${postId}`);
    return response.data;
  },

  async getTrending() {
    const response = await api.get('/api/social/trending');
    return response.data;
  }
};

// Serviços de Pagamentos
export const paymentService = {
  async getWallet() {
    const response = await api.get('/api/payments/wallet');
    return response.data;
  },

  async requestWithdrawal(amount, paymentMethod) {
    const response = await api.post('/api/payments/withdraw', {
      amount,
      payment_method: paymentMethod
    });
    return response.data;
  },

  async getPaymentMethods() {
    const response = await api.get('/api/payments/payment-methods');
    return response.data;
  },

  async addPaymentMethod(methodData) {
    const response = await api.post('/api/payments/payment-methods', methodData);
    return response.data;
  },

  async getTransactions(page = 1, perPage = 20, type = null) {
    const params = { page, per_page: perPage };
    if (type) params.type = type;

    const response = await api.get('/api/payments/transactions', { params });
    return response.data;
  },

  async getEarningsSummary() {
    const response = await api.get('/api/payments/earnings/summary');
    return response.data;
  },

  async createSetupIntent() {
    const response = await api.post('/api/payments/stripe/setup-intent');
    return response.data;
  }
};

// Serviços de Usuário
export const userService = {
  async getUsers() {
    const response = await api.get('/api/users');
    return response.data;
  },

  async getUser(userId) {
    const response = await api.get(`/api/users/${userId}`);
    return response.data;
  },

  async updateUser(userId, userData) {
    const response = await api.put(`/api/users/${userId}`, userData);
    return response.data;
  },

  async deleteUser(userId) {
    const response = await api.delete(`/api/users/${userId}`);
    return response.data;
  }
};

// Utilitários
export const apiUtils = {
  setAuthToken(token) {
    localStorage.setItem('auth_token', token);
  },

  removeAuthToken() {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
  },

  getAuthToken() {
    return localStorage.getItem('auth_token');
  },

  isAuthenticated() {
    return !!this.getAuthToken();
  }
};

export default api;

