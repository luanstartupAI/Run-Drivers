import React, { createContext, useContext, useEffect, useState } from 'react';
import { secureStorage } from '../utils';

const ThemeContext = createContext();

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme deve ser usado dentro de ThemeProvider');
  }
  return context;
};

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState('system');
  const [resolvedTheme, setResolvedTheme] = useState('light');

  useEffect(() => {
    // Carregar tema salvo
    const savedTheme = secureStorage.get('theme') || 'system';
    setTheme(savedTheme);
  }, []);

  useEffect(() => {
    const root = window.document.documentElement;
    
    const getSystemTheme = () => {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    };

    const applyTheme = (newTheme) => {
      let actualTheme;
      
      if (newTheme === 'system') {
        actualTheme = getSystemTheme();
      } else {
        actualTheme = newTheme;
      }
      
      setResolvedTheme(actualTheme);
      
      // Remover classes de tema anteriores
      root.classList.remove('light', 'dark');
      root.removeAttribute('data-theme');
      
      // Aplicar novo tema
      root.classList.add(actualTheme);
      root.setAttribute('data-theme', actualTheme);
      
      // Atualizar meta theme-color para mobile
      const metaThemeColor = document.querySelector('meta[name="theme-color"]');
      if (metaThemeColor) {
        metaThemeColor.setAttribute(
          'content',
          actualTheme === 'dark' ? '#0f172a' : '#7CB342'
        );
      }
    };

    applyTheme(theme);
    secureStorage.set('theme', theme);

    // Listener para mudanças no tema do sistema
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleSystemThemeChange = () => {
      if (theme === 'system') {
        applyTheme('system');
      }
    };

    mediaQuery.addEventListener('change', handleSystemThemeChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleSystemThemeChange);
    };
  }, [theme]);

  const toggleTheme = () => {
    setTheme(resolvedTheme === 'light' ? 'dark' : 'light');
  };

  const value = {
    theme,
    setTheme,
    resolvedTheme,
    toggleTheme,
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

