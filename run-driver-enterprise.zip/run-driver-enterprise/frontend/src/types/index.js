// Tipos principais da aplicação Run Driver

// Usuário e Autenticação
export interface User {
  id: string;
  email: string;
  phone: string;
  name: string;
  avatar?: string;
  status: 'active' | 'inactive' | 'suspended';
  createdAt: string;
  updatedAt: string;
}

export interface Driver extends User {
  driverLicense: {
    number: string;
    category: string;
    expiryDate: string;
    verified: boolean;
  };
  vehicle: {
    plate: string;
    model: string;
    year: number;
    color: string;
    documents: {
      registration: string;
      insurance: string;
    };
    verified: boolean;
  };
  rating: number;
  totalTrips: number;
  totalEarnings: number;
  level: number;
  xp: number;
  badges: Badge[];
  isOnline: boolean;
  location?: {
    lat: number;
    lng: number;
    heading?: number;
  };
}

// Autenticação
export interface AuthState {
  user: Driver | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  token: string | null;
}

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterData {
  email: string;
  password: string;
  confirmPassword: string;
  phone: string;
  name: string;
  acceptTerms: boolean;
}

export interface BiometricData {
  type: 'fingerprint' | 'face' | 'voice';
  data: string;
  verified: boolean;
}

// Documentos
export interface Document {
  id: string;
  type: 'driver_license' | 'vehicle_registration' | 'insurance' | 'selfie' | 'vehicle_photo';
  url: string;
  status: 'pending' | 'approved' | 'rejected';
  uploadedAt: string;
  verifiedAt?: string;
  rejectionReason?: string;
}

// Viagens
export interface Trip {
  id: string;
  driverId: string;
  passengerId: string;
  status: 'requested' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
  pickup: {
    address: string;
    coordinates: [number, number];
  };
  destination: {
    address: string;
    coordinates: [number, number];
  };
  distance: number; // em metros
  duration: number; // em segundos
  fare: {
    base: number;
    distance: number;
    time: number;
    surge: number;
    total: number;
  };
  requestedAt: string;
  acceptedAt?: string;
  startedAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  rating?: {
    driver: number;
    passenger: number;
    driverComment?: string;
    passengerComment?: string;
  };
}

// Gamificação
export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt: string;
  progress?: {
    current: number;
    target: number;
  };
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'trips' | 'earnings' | 'rating' | 'social' | 'special';
  requirements: {
    type: string;
    value: number;
  }[];
  reward: {
    xp: number;
    coins?: number;
    badge?: string;
  };
  unlocked: boolean;
  progress: {
    current: number;
    target: number;
  };
}

export interface Level {
  level: number;
  name: string;
  xpRequired: number;
  benefits: string[];
  icon: string;
}

// Social
export interface SocialPost {
  id: string;
  authorId: string;
  author: {
    name: string;
    avatar: string;
    level: number;
  };
  content: string;
  images?: string[];
  type: 'text' | 'achievement' | 'trip_milestone' | 'photo';
  likes: number;
  comments: number;
  shares: number;
  isLiked: boolean;
  createdAt: string;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  author: {
    name: string;
    avatar: string;
  };
  content: string;
  likes: number;
  isLiked: boolean;
  createdAt: string;
}

// Carteira e Pagamentos
export interface Wallet {
  id: string;
  driverId: string;
  balance: number;
  pendingBalance: number;
  totalEarnings: number;
  currency: string;
  transactions: Transaction[];
}

export interface Transaction {
  id: string;
  type: 'earning' | 'withdrawal' | 'bonus' | 'penalty' | 'ad_reward' | 'game_reward';
  amount: number;
  description: string;
  status: 'pending' | 'completed' | 'failed';
  createdAt: string;
  completedAt?: string;
  metadata?: {
    tripId?: string;
    adId?: string;
    gameId?: string;
  };
}

// Mapas e Localização
export interface MapMarker {
  id: string;
  type: 'driver' | 'passenger' | 'pickup' | 'destination' | 'poi';
  position: [number, number];
  data?: any;
  icon?: string;
}

export interface Route {
  id: string;
  coordinates: [number, number][];
  distance: number;
  duration: number;
  instructions: RouteInstruction[];
}

export interface RouteInstruction {
  text: string;
  distance: number;
  time: number;
  maneuver: string;
}

// Notificações
export interface Notification {
  id: string;
  userId: string;
  type: 'trip_request' | 'trip_update' | 'achievement' | 'social' | 'system' | 'payment';
  title: string;
  message: string;
  data?: any;
  read: boolean;
  createdAt: string;
}

// API Responses
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
  };
}

// Estados de Loading
export interface LoadingState {
  isLoading: boolean;
  error: string | null;
}

// Configurações
export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  language: 'pt-BR' | 'en-US' | 'es-ES';
  notifications: {
    push: boolean;
    email: boolean;
    sms: boolean;
    tripRequests: boolean;
    achievements: boolean;
    social: boolean;
  };
  privacy: {
    shareLocation: boolean;
    showOnlineStatus: boolean;
    allowSocialInteractions: boolean;
  };
  map: {
    style: 'default' | 'satellite' | 'terrain';
    showTraffic: boolean;
    autoZoom: boolean;
  };
}

