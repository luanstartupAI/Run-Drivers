import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '../atoms/Button';
import { Input } from '../atoms/Input';
import { Icon } from '../atoms/Icon';
import useAuthStore from '../../stores/authStore';

const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'Email é obrigatório')
    .email('Email inválido'),
  password: z
    .string()
    .min(6, 'Senha deve ter pelo menos 6 caracteres'),
});

const LoginForm = ({ onSuccess }) => {
  const [showPassword, setShowPassword] = useState(false);
  const { login, isLoading, error } = useAuthStore();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const onSubmit = async (data) => {
    try {
      const result = await login(data.email, data.password);
      
      if (result.success) {
        onSuccess?.(result.user);
      } else {
        setError('root', {
          type: 'manual',
          message: result.error || 'Erro ao fazer login'
        });
      }
    } catch (error) {
      setError('root', {
        type: 'manual',
        message: 'Erro inesperado. Tente novamente.'
      });
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Erro geral */}
      {(errors.root || error) && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <Icon name="alert-circle" className="w-5 h-5 text-red-400" />
            <span className="text-red-100 text-sm">
              {errors.root?.message || error}
            </span>
          </div>
        </div>
      )}

      {/* Campo Email */}
      <div className="space-y-2">
        <label htmlFor="email" className="block text-sm font-medium text-white">
          Email
        </label>
        <Input
          id="email"
          type="email"
          placeholder="seu@email.com"
          {...register('email')}
          error={errors.email?.message}
          disabled={isLoading}
          className="w-full"
        />
      </div>

      {/* Campo Senha */}
      <div className="space-y-2">
        <label htmlFor="password" className="block text-sm font-medium text-white">
          Senha
        </label>
        <div className="relative">
          <Input
            id="password"
            type={showPassword ? 'text' : 'password'}
            placeholder="Sua senha"
            {...register('password')}
            error={errors.password?.message}
            disabled={isLoading}
            className="w-full pr-12"
          />
          <button
            type="button"
            onClick={togglePasswordVisibility}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
            disabled={isLoading}
          >
            <Icon 
              name={showPassword ? 'eye-off' : 'eye'} 
              className="w-5 h-5" 
            />
          </button>
        </div>
      </div>

      {/* Botão de Login */}
      <Button
        type="submit"
        className="w-full"
        disabled={isLoading}
        size="lg"
      >
        {isLoading ? (
          <>
            <Icon name="loader" className="w-5 h-5 mr-2 animate-spin" />
            Entrando...
          </>
        ) : (
          <>
            <Icon name="log-in" className="w-5 h-5 mr-2" />
            Entrar
          </>
        )}
      </Button>

      {/* Links auxiliares */}
      <div className="text-center space-y-2">
        <button
          type="button"
          className="text-white/60 hover:text-white text-sm transition-colors"
          disabled={isLoading}
        >
          Esqueceu sua senha?
        </button>
        
        <div className="text-white/60 text-sm">
          Não tem conta?{' '}
          <button
            type="button"
            className="text-white hover:text-white/80 font-medium transition-colors"
            disabled={isLoading}
          >
            Cadastre-se
          </button>
        </div>
      </div>

      {/* Dados de teste */}
      <div className="mt-8 p-4 bg-white/5 rounded-lg border border-white/10">
        <h4 className="text-white font-medium mb-2 text-sm">Dados para teste:</h4>
        <div className="text-white/60 text-xs space-y-1">
          <p><strong>Email:</strong> motorista@exemplo.com</p>
          <p><strong>Senha:</strong> 123456</p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="mt-2 text-xs"
          onClick={() => {
            // Preencher campos automaticamente
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            
            if (emailInput && passwordInput) {
              emailInput.value = 'motorista@exemplo.com';
              passwordInput.value = '123456';
              
              // Disparar eventos para react-hook-form
              emailInput.dispatchEvent(new Event('input', { bubbles: true }));
              passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
            }
          }}
          disabled={isLoading}
        >
          <Icon name="zap" className="w-3 h-3 mr-1" />
          Preencher automaticamente
        </Button>
      </div>
    </form>
  );
};

export { LoginForm };
export default LoginForm;

