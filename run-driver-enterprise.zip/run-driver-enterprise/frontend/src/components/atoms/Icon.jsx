import React from 'react';
import { cn } from '../../utils';
import * as LucideIcons from 'lucide-react';

// Ícones customizados MANUS
const manusIcons = {
  // Logo MANUS
  'manus-logo': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12Z"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M8 12L11 15L16 9"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  
  // Ícone Run Driver
  'run-driver': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M5 17H4C3.44772 17 3 16.5523 3 16V10C3 9.44772 3.44772 9 4 9H5M5 17V19C5 19.5523 5.44772 20 6 20H7C7.55228 20 8 19.5523 8 19V17M5 17H19M19 17H20C20.5523 17 21 16.5523 21 16V10C21 9.44772 20.5523 9 20 9H19M19 17V19C19 19.5523 18.5523 20 18 20H17C16.4477 20 16 19.5523 16 19V17"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M5 9L7 5H17L19 9"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="8" cy="17" r="1" fill="currentColor" />
      <circle cx="16" cy="17" r="1" fill="currentColor" />
    </svg>
  ),
  
  // Ícones de gamificação
  'achievement-badge': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z"
        fill="currentColor"
      />
    </svg>
  ),
  
  'level-up': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M7 14L12 9L17 14"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 9V21"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  
  'xp-points': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <polygon
        points="12,2 15.09,8.26 22,9 17,14 18.18,21 12,17.77 5.82,21 7,14 2,9 8.91,8.26"
        fill="currentColor"
      />
    </svg>
  ),
  
  // Ícones de transporte
  'car-driver': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M5 17H4C3.44772 17 3 16.5523 3 16V10C3 9.44772 3.44772 9 4 9H5M5 17V19C5 19.5523 5.44772 20 6 20H7C7.55228 20 8 19.5523 8 19V17M5 17H19M19 17H20C20.5523 17 21 16.5523 21 16V10C21 9.44772 20.5523 9 20 9H19M19 17V19C19 19.5523 18.5523 20 18 20H17C16.4477 20 16 19.5523 16 19V17"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M5 9L7 5H17L19 9"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  
  'route-map': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M3 6L9 3L15 6L21 3V18L15 21L9 18L3 21V6Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M9 3V18"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15 6V21"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  
  // Ícones financeiros
  'wallet-money': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M21 12V7C21 5.89543 20.1046 5 19 5H5C3.89543 5 3 5.89543 3 7V17C3 18.1046 3.89543 19 5 19H19C20.1046 19 21 18.1046 21 17V16"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M21 12H18C16.8954 12 16 12.8954 16 14C16 15.1046 16.8954 16 18 16H21"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  
  'earnings': (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M12 2V22M17 5H9.5C8.11929 5 7 6.11929 7 7.5C7 8.88071 8.11929 10 9.5 10H14.5C15.8807 10 17 11.1193 17 12.5C17 13.8807 15.8807 15 14.5 15H7"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
};

const Icon = ({
  name,
  size = 'md',
  className,
  color = 'currentColor',
  strokeWidth = 2,
  ...props
}) => {
  const sizeMap = {
    xs: 12,
    sm: 16,
    md: 20,
    lg: 24,
    xl: 32,
    '2xl': 40,
  };

  const iconSize = typeof size === 'number' ? size : sizeMap[size];
  
  // Verificar se é um ícone MANUS customizado
  if (manusIcons[name]) {
    const ManusIcon = manusIcons[name];
    return (
      <ManusIcon
        className={cn('inline-block', className)}
        style={{
          width: iconSize,
          height: iconSize,
          color,
        }}
        {...props}
      />
    );
  }
  
  // Fallback para ícones Lucide
  const LucideIcon = LucideIcons[name] || LucideIcons[name.charAt(0).toUpperCase() + name.slice(1)];
  
  if (LucideIcon) {
    return (
      <LucideIcon
        size={iconSize}
        color={color}
        strokeWidth={strokeWidth}
        className={cn('inline-block', className)}
        {...props}
      />
    );
  }
  
  // Ícone padrão se não encontrado
  return (
    <LucideIcons.HelpCircle
      size={iconSize}
      color={color}
      strokeWidth={strokeWidth}
      className={cn('inline-block', className)}
      {...props}
    />
  );
};

// Catálogo de ícones por categoria
export const iconCatalog = {
  // Navegação e Interface
  navigation: [
    'menu', 'x', 'chevron-left', 'chevron-right', 'chevron-up', 'chevron-down',
    'arrow-left', 'arrow-right', 'home', 'search', 'filter', 'more-horizontal'
  ],
  
  // Transporte e Mapas
  transport: [
    'car-driver', 'route-map', 'map-pin', 'navigation', 'compass', 'map',
    'traffic-cone', 'fuel', 'speedometer', 'road'
  ],
  
  // Usuário e Perfil
  user: [
    'user', 'user-circle', 'users', 'user-plus', 'user-check', 'user-x',
    'settings', 'edit', 'camera'
  ],
  
  // Gamificação
  gamification: [
    'achievement-badge', 'level-up', 'xp-points', 'trophy', 'star', 'award', 
    'target', 'trending-up', 'zap', 'flame', 'crown'
  ],
  
  // Financeiro
  financial: [
    'wallet-money', 'earnings', 'dollar-sign', 'credit-card', 'coins', 
    'trending-up', 'trending-down', 'bar-chart', 'pie-chart'
  ],
  
  // Social
  social: [
    'heart', 'message-circle', 'share', 'thumbs-up', 'thumbs-down', 'bookmark',
    'flag', 'users', 'user-plus', 'message-square'
  ],
  
  // Estados e Feedback
  feedback: [
    'check', 'x', 'alert-circle', 'alert-triangle', 'info', 'help-circle',
    'check-circle', 'x-circle', 'loader', 'refresh-cw'
  ],
};

export { Icon, manusIcons };

