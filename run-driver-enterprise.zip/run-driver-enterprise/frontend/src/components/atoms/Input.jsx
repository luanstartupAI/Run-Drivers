import React, { forwardRef } from 'react';
import { cn } from '../../utils';

const Input = forwardRef(({
  label,
  error,
  helperText,
  leftIcon,
  rightIcon,
  onRightIconClick,
  variant = 'default',
  inputSize = 'md',
  className,
  ...props
}, ref) => {
  const sizeClasses = {
    sm: 'h-8 px-3 text-sm',
    md: 'h-10 px-4 text-base',
    lg: 'h-12 px-5 text-lg',
  };
  
  const variantClasses = {
    default: 'border border-gray-300 bg-white focus:border-[#7CB342] focus:ring-2 focus:ring-[#7CB342]/20',
    filled: 'border-0 bg-gray-100 focus:bg-white focus:ring-2 focus:ring-[#7CB342]/20',
    outlined: 'border-2 border-[#7CB342] bg-transparent focus:bg-[#F0F9E8]/50',
  };

  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          {label}
          {props.required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      
      <div className="relative">
        {leftIcon && (
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <span className="text-gray-400">{leftIcon}</span>
          </div>
        )}
        
        <input
          ref={ref}
          className={cn(
            'w-full rounded-lg transition-all duration-200 placeholder:text-gray-400',
            'dark:bg-gray-800 dark:border-gray-600 dark:text-white dark:placeholder:text-gray-500',
            sizeClasses[inputSize],
            variantClasses[variant],
            leftIcon && 'pl-10',
            rightIcon && 'pr-10',
            error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20',
            className
          )}
          {...props}
        />
        
        {rightIcon && (
          <div 
            className={cn(
              'absolute inset-y-0 right-0 pr-3 flex items-center',
              onRightIconClick ? 'cursor-pointer' : 'pointer-events-none'
            )}
            onClick={onRightIconClick}
          >
            <span className="text-gray-400">{rightIcon}</span>
          </div>
        )}
      </div>
      
      {(error || helperText) && (
        <p className={cn(
          'text-sm',
          error ? 'text-red-500' : 'text-gray-500 dark:text-gray-400'
        )}>
          {error || helperText}
        </p>
      )}
    </div>
  );
});

Input.displayName = 'Input';

export { Input };

