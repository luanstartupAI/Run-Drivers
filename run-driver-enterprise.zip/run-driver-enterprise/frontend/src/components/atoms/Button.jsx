import React from 'react';
import { cva } from 'class-variance-authority';
import { cn } from '../../utils';

const buttonVariants = cva(
  'inline-flex items-center justify-center rounded-lg text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none',
  {
    variants: {
      variant: {
        // Variante principal MANUS
        manus: 'bg-[#7CB342] text-white hover:bg-[#6A9B38] active:bg-[#57832E] shadow-md hover:shadow-lg focus-visible:ring-[#7CB342]',
        
        // Variante outline MANUS
        'manus-outline': 'border-2 border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white active:bg-[#6A9B38]',
        
        // Variante ghost MANUS
        'manus-ghost': 'text-[#7CB342] hover:bg-[#F0F9E8] active:bg-[#E1F3D1]',
        
        // Variantes funcionais
        primary: 'bg-blue-500 text-white hover:bg-blue-600 shadow-md focus-visible:ring-blue-500',
        secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300 focus-visible:ring-gray-500',
        success: 'bg-green-500 text-white hover:bg-green-600 shadow-md focus-visible:ring-green-500',
        warning: 'bg-yellow-500 text-white hover:bg-yellow-600 shadow-md focus-visible:ring-yellow-500',
        error: 'bg-red-500 text-white hover:bg-red-600 shadow-md focus-visible:ring-red-500',
        
        // Variante destrutiva
        destructive: 'bg-red-500 text-white hover:bg-red-600 focus-visible:ring-red-500',
        
        // Variante outline padrão
        outline: 'border border-gray-300 bg-transparent hover:bg-gray-50 focus-visible:ring-gray-500',
        
        // Variante ghost padrão
        ghost: 'hover:bg-gray-100 focus-visible:ring-gray-500',
        
        // Variante link
        link: 'text-blue-500 underline-offset-4 hover:underline focus-visible:ring-blue-500',
      },
      size: {
        sm: 'h-8 px-3 text-xs',
        md: 'h-10 px-4 text-sm',
        lg: 'h-12 px-6 text-base',
        xl: 'h-14 px-8 text-lg',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'manus',
      size: 'md',
    },
  }
);

const Button = React.forwardRef(({ 
  className, 
  variant, 
  size, 
  children, 
  loading, 
  icon, 
  iconPosition = 'left',
  ...props 
}, ref) => {
  return (
    <button
      className={cn(buttonVariants({ variant, size, className }))}
      ref={ref}
      disabled={loading || props.disabled}
      {...props}
    >
      {loading && (
        <svg
          className="mr-2 h-4 w-4 animate-spin"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          />
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          />
        </svg>
      )}
      {icon && iconPosition === 'left' && !loading && (
        <span className="mr-2">{icon}</span>
      )}
      {children}
      {icon && iconPosition === 'right' && !loading && (
        <span className="ml-2">{icon}</span>
      )}
    </button>
  );
});

Button.displayName = 'Button';

export { Button, buttonVariants };

