import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authService, apiUtils } from '../services/api';

const useAuthStore = create(
  persist(
    (set, get) => ({
      // Estado
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      // Ações
      login: async (email, password) => {
        set({ isLoading: true, error: null });
        
        try {
          const response = await authService.login(email, password);
          
          const { token, user } = response;
          
          // Salvar token
          apiUtils.setAuthToken(token);
          
          set({
            user,
            token,
            isAuthenticated: true,
            isLoading: false,
            error: null
          });
          
          return { success: true, user };
        } catch (error) {
          const errorMessage = error.response?.data?.error || 'Erro ao fazer login';
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: errorMessage
          });
          
          return { success: false, error: errorMessage };
        }
      },

      register: async (userData) => {
        set({ isLoading: true, error: null });
        
        try {
          const response = await authService.register(userData);
          
          const { token, user } = response;
          
          // Salvar token
          apiUtils.setAuthToken(token);
          
          set({
            user,
            token,
            isAuthenticated: true,
            isLoading: false,
            error: null
          });
          
          return { success: true, user };
        } catch (error) {
          const errorMessage = error.response?.data?.error || 'Erro ao criar conta';
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: errorMessage
          });
          
          return { success: false, error: errorMessage };
        }
      },

      logout: async () => {
        set({ isLoading: true });
        
        try {
          await authService.logout();
        } catch (error) {
          console.error('Erro ao fazer logout:', error);
        } finally {
          // Limpar dados locais independente do resultado da API
          apiUtils.removeAuthToken();
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: null
          });
        }
      },

      verifyToken: async () => {
        const token = apiUtils.getAuthToken();
        
        if (!token) {
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false
          });
          return false;
        }

        set({ isLoading: true });
        
        try {
          const response = await authService.verifyToken();
          
          set({
            user: response.user,
            token,
            isAuthenticated: true,
            isLoading: false,
            error: null
          });
          
          return true;
        } catch (error) {
          // Token inválido ou expirado
          apiUtils.removeAuthToken();
          
          set({
            user: null,
            token: null,
            isAuthenticated: false,
            isLoading: false,
            error: null
          });
          
          return false;
        }
      },

      refreshToken: async () => {
        try {
          const response = await authService.refreshToken();
          const { token } = response;
          
          apiUtils.setAuthToken(token);
          
          set({
            token,
            error: null
          });
          
          return true;
        } catch (error) {
          // Não foi possível renovar o token
          get().logout();
          return false;
        }
      },

      updateUser: (userData) => {
        set((state) => ({
          user: { ...state.user, ...userData }
        }));
      },

      clearError: () => {
        set({ error: null });
      },

      // Getters
      getUser: () => get().user,
      getToken: () => get().token,
      isDriver: () => get().user?.type === 'driver',
      isPassenger: () => get().user?.type === 'passenger',
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);

export { useAuthStore };
export default useAuthStore;

