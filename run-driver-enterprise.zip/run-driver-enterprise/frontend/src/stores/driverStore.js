import { create } from 'zustand';
import { driverService, tripService, gamificationService } from '../services/api';

const useDriverStore = create((set, get) => ({
  // Estado do perfil
  profile: null,
  dashboard: null,
  isOnline: false,
  isAvailable: false,
  currentLocation: null,
  
  // Estado das viagens
  trips: [],
  availableTrips: [],
  currentTrip: null,
  
  // Estado da gamificação
  achievements: [],
  challenges: [],
  leaderboard: [],
  
  // Estado de carregamento
  isLoading: false,
  error: null,

  // Ações do perfil
  fetchProfile: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await driverService.getProfile();
      
      set({
        profile: response.driver,
        isOnline: response.driver.is_online,
        isAvailable: response.driver.is_available,
        currentLocation: response.driver.current_lat && response.driver.current_lng ? {
          lat: response.driver.current_lat,
          lng: response.driver.current_lng
        } : null,
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao carregar perfil';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  updateProfile: async (profileData) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await driverService.updateProfile(profileData);
      
      set({
        profile: response.driver,
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao atualizar perfil';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  updateLocation: async (lat, lng) => {
    try {
      await driverService.updateLocation(lat, lng);
      
      set({
        currentLocation: { lat, lng },
        profile: {
          ...get().profile,
          current_lat: lat,
          current_lng: lng
        }
      });
    } catch (error) {
      console.error('Erro ao atualizar localização:', error);
    }
  },

  updateStatus: async (status) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await driverService.updateStatus(status);
      
      set({
        isOnline: status.is_online ?? get().isOnline,
        isAvailable: status.is_available ?? get().isAvailable,
        profile: {
          ...get().profile,
          is_online: status.is_online ?? get().profile?.is_online,
          is_available: status.is_available ?? get().profile?.is_available
        },
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao atualizar status';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  // Ações do dashboard
  fetchDashboard: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await driverService.getDashboard();
      
      set({
        dashboard: response,
        profile: response.driver,
        isOnline: response.status.is_online,
        isAvailable: response.status.is_available,
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao carregar dashboard';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  // Ações das viagens
  fetchTrips: async (page = 1, status = null) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await tripService.getTrips(page, 10, status);
      
      set({
        trips: response.trips,
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao carregar viagens';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  fetchAvailableTrips: async (radius = 10) => {
    try {
      const response = await tripService.getAvailableTrips(radius);
      
      set({
        availableTrips: response.trips
      });
      
      return response;
    } catch (error) {
      console.error('Erro ao carregar viagens disponíveis:', error);
      return { trips: [] };
    }
  },

  acceptTrip: async (tripId) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await tripService.acceptTrip(tripId);
      
      // Atualizar viagem atual e remover das disponíveis
      set({
        currentTrip: response.trip,
        availableTrips: get().availableTrips.filter(trip => trip.id !== tripId),
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao aceitar viagem';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  startTrip: async (tripId) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await tripService.startTrip(tripId);
      
      set({
        currentTrip: response.trip,
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao iniciar viagem';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  completeTrip: async (tripId) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await tripService.completeTrip(tripId);
      
      // Atualizar estatísticas do perfil
      const currentProfile = get().profile;
      if (currentProfile) {
        set({
          profile: {
            ...currentProfile,
            total_trips: currentProfile.total_trips + 1,
            total_earnings: currentProfile.total_earnings + response.earnings,
            earnings_today: currentProfile.earnings_today + response.earnings,
            xp: currentProfile.xp + response.xp_earned,
            level: response.new_level
          }
        });
      }
      
      set({
        currentTrip: null,
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao finalizar viagem';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  cancelTrip: async (tripId) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await tripService.cancelTrip(tripId);
      
      set({
        currentTrip: null,
        isLoading: false
      });
      
      return response;
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Erro ao cancelar viagem';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  // Ações da gamificação
  fetchAchievements: async () => {
    try {
      const response = await gamificationService.getAchievements();
      
      set({
        achievements: response.unlocked_achievements
      });
      
      return response;
    } catch (error) {
      console.error('Erro ao carregar conquistas:', error);
      return { unlocked_achievements: [] };
    }
  },

  fetchChallenges: async () => {
    try {
      const response = await gamificationService.getChallenges();
      
      set({
        challenges: response
      });
      
      return response;
    } catch (error) {
      console.error('Erro ao carregar desafios:', error);
      return { daily_challenges: [], weekly_challenges: [] };
    }
  },

  fetchLeaderboard: async (period = 'week') => {
    try {
      const response = await gamificationService.getLeaderboard(period);
      
      set({
        leaderboard: response.leaderboard
      });
      
      return response;
    } catch (error) {
      console.error('Erro ao carregar ranking:', error);
      return { leaderboard: [] };
    }
  },

  // Utilitários
  clearError: () => {
    set({ error: null });
  },

  reset: () => {
    set({
      profile: null,
      dashboard: null,
      isOnline: false,
      isAvailable: false,
      currentLocation: null,
      trips: [],
      availableTrips: [],
      currentTrip: null,
      achievements: [],
      challenges: [],
      leaderboard: [],
      isLoading: false,
      error: null
    });
  },

  // Getters
  getEarningsToday: () => get().profile?.earnings_today || 0,
  getEarningsWeek: () => get().profile?.earnings_week || 0,
  getEarningsMonth: () => get().profile?.earnings_month || 0,
  getTotalTrips: () => get().profile?.total_trips || 0,
  getRating: () => get().profile?.rating || 5.0,
  getLevel: () => get().profile?.level || 1,
  getXP: () => get().profile?.xp || 0,
  hasCurrentTrip: () => !!get().currentTrip,
  getCurrentTripStatus: () => get().currentTrip?.status || null,
}));

export default useDriverStore;

