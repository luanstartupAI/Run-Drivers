import React, { useEffect, useState } from 'react';
import { Card } from '../../components/atoms/Card';
import { Button } from '../../components/atoms/Button';
import { Icon } from '../../components/atoms/Icon';
import useAuthStore from '../../stores/authStore';
import useDriverStore from '../../stores/driverStore';
import { useTheme } from '../../contexts/ThemeContext';

const DashboardPage = () => {
  const { user } = useAuthStore();
  const { 
    dashboard, 
    profile, 
    isOnline, 
    isAvailable, 
    currentTrip,
    availableTrips,
    achievements,
    challenges,
    isLoading,
    error,
    fetchDashboard,
    fetchAvailableTrips,
    fetchAchievements,
    fetchChallenges,
    updateStatus,
    acceptTrip,
    startTrip,
    completeTrip,
    clearError
  } = useDriverStore();
  
  const { theme } = useTheme();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      await Promise.all([
        fetchDashboard(),
        fetchAvailableTrips(),
        fetchAchievements(),
        fetchChallenges()
      ]);
    } catch (error) {
      console.error('Erro ao carregar dados do dashboard:', error);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const handleToggleOnline = async () => {
    try {
      await updateStatus({ is_online: !isOnline });
      
      if (!isOnline) {
        // Se ficou online, buscar viagens disponíveis
        await fetchAvailableTrips();
      }
    } catch (error) {
      console.error('Erro ao alterar status:', error);
    }
  };

  const handleToggleAvailable = async () => {
    try {
      await updateStatus({ is_available: !isAvailable });
    } catch (error) {
      console.error('Erro ao alterar disponibilidade:', error);
    }
  };

  const handleAcceptTrip = async (tripId) => {
    try {
      await acceptTrip(tripId);
    } catch (error) {
      console.error('Erro ao aceitar viagem:', error);
    }
  };

  const handleStartTrip = async () => {
    if (!currentTrip) return;
    
    try {
      await startTrip(currentTrip.id);
    } catch (error) {
      console.error('Erro ao iniciar viagem:', error);
    }
  };

  const handleCompleteTrip = async () => {
    if (!currentTrip) return;
    
    try {
      await completeTrip(currentTrip.id);
    } catch (error) {
      console.error('Erro ao finalizar viagem:', error);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value || 0);
  };

  const getStatusColor = () => {
    if (!isOnline) return 'bg-gray-500';
    if (!isAvailable) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getStatusText = () => {
    if (!isOnline) return 'Offline';
    if (!isAvailable) return 'Ocupado';
    return 'Disponível';
  };

  if (isLoading && !dashboard) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-manus-primary to-manus-secondary flex items-center justify-center">
        <div className="text-white text-center">
          <Icon name="loader" className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p>Carregando dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark' 
        ? 'bg-gradient-to-br from-gray-900 to-gray-800' 
        : 'bg-gradient-to-br from-manus-primary to-manus-secondary'
    }`}>
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${getStatusColor()}`}></div>
                <span className="text-white font-medium">{getStatusText()}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant={isOnline ? "secondary" : "primary"}
                  size="sm"
                  onClick={handleToggleOnline}
                  disabled={isLoading}
                >
                  <Icon name={isOnline ? "power" : "play"} className="w-4 h-4 mr-2" />
                  {isOnline ? 'Ficar Offline' : 'Ficar Online'}
                </Button>
                
                {isOnline && (
                  <Button
                    variant={isAvailable ? "secondary" : "primary"}
                    size="sm"
                    onClick={handleToggleAvailable}
                    disabled={isLoading}
                  >
                    <Icon name={isAvailable ? "pause" : "play"} className="w-4 h-4 mr-2" />
                    {isAvailable ? 'Pausar' : 'Disponível'}
                  </Button>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRefresh}
                disabled={refreshing}
              >
                <Icon name={refreshing ? "loader" : "refresh-cw"} 
                      className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
              </Button>
              
              <div className="text-white text-right">
                <p className="text-sm opacity-80">Olá, {user?.name}</p>
                <p className="text-xs opacity-60">Nível {profile?.level || 1}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Erro */}
        {error && (
          <div className="mb-6 bg-red-500/20 border border-red-500/30 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Icon name="alert-circle" className="w-5 h-5 text-red-400" />
                <span className="text-red-100">{error}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={clearError}>
                <Icon name="x" className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}

        {/* Viagem Atual */}
        {currentTrip && (
          <div className="mb-8">
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-white">Viagem Atual</h2>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    currentTrip.status === 'accepted' ? 'bg-yellow-500/20 text-yellow-100' :
                    currentTrip.status === 'in_progress' ? 'bg-blue-500/20 text-blue-100' :
                    'bg-gray-500/20 text-gray-100'
                  }`}>
                    {currentTrip.status === 'accepted' ? 'Aceita' :
                     currentTrip.status === 'in_progress' ? 'Em Andamento' :
                     currentTrip.status}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <p className="text-white/60 text-sm">Origem</p>
                    <p className="text-white">{currentTrip.origin_address}</p>
                  </div>
                  <div>
                    <p className="text-white/60 text-sm">Destino</p>
                    <p className="text-white">{currentTrip.destination_address}</p>
                  </div>
                  <div>
                    <p className="text-white/60 text-sm">Distância</p>
                    <p className="text-white">{currentTrip.distance} km</p>
                  </div>
                  <div>
                    <p className="text-white/60 text-sm">Valor</p>
                    <p className="text-white font-bold">{formatCurrency(currentTrip.price)}</p>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  {currentTrip.status === 'accepted' && (
                    <Button onClick={handleStartTrip} disabled={isLoading}>
                      <Icon name="play" className="w-4 h-4 mr-2" />
                      Iniciar Viagem
                    </Button>
                  )}
                  
                  {currentTrip.status === 'in_progress' && (
                    <Button onClick={handleCompleteTrip} disabled={isLoading}>
                      <Icon name="check" className="w-4 h-4 mr-2" />
                      Finalizar Viagem
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/60 text-sm">Hoje</p>
                  <p className="text-2xl font-bold text-white">
                    {formatCurrency(dashboard?.stats?.earnings_today)}
                  </p>
                </div>
                <Icon name="dollar-sign" className="w-8 h-8 text-green-400" />
              </div>
            </div>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/60 text-sm">Esta Semana</p>
                  <p className="text-2xl font-bold text-white">
                    {formatCurrency(dashboard?.stats?.earnings_week)}
                  </p>
                </div>
                <Icon name="trending-up" className="w-8 h-8 text-blue-400" />
              </div>
            </div>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/60 text-sm">Total de Viagens</p>
                  <p className="text-2xl font-bold text-white">
                    {dashboard?.stats?.total_trips || 0}
                  </p>
                </div>
                <Icon name="map-pin" className="w-8 h-8 text-purple-400" />
              </div>
            </div>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/60 text-sm">Avaliação</p>
                  <p className="text-2xl font-bold text-white">
                    {dashboard?.stats?.rating?.toFixed(1) || '5.0'}
                  </p>
                </div>
                <Icon name="star" className="w-8 h-8 text-yellow-400" />
              </div>
            </div>
          </Card>
        </div>

        {/* Viagens Disponíveis */}
        {isOnline && isAvailable && !currentTrip && (
          <div className="mb-8">
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-white">Viagens Disponíveis</h2>
                  <span className="text-white/60 text-sm">
                    {availableTrips.length} viagem(ns) próxima(s)
                  </span>
                </div>
                
                {availableTrips.length === 0 ? (
                  <div className="text-center py-8">
                    <Icon name="map" className="w-12 h-12 text-white/40 mx-auto mb-4" />
                    <p className="text-white/60">Nenhuma viagem disponível no momento</p>
                    <p className="text-white/40 text-sm">Aguarde novas solicitações...</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {availableTrips.slice(0, 3).map((trip) => (
                      <div key={trip.id} className="bg-white/5 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <span className="text-white font-medium">{formatCurrency(trip.price)}</span>
                            <span className="text-white/60">•</span>
                            <span className="text-white/60">{trip.distance} km</span>
                            <span className="text-white/60">•</span>
                            <span className="text-white/60">{trip.distance_to_pickup} km de você</span>
                          </div>
                          <Button 
                            size="sm" 
                            onClick={() => handleAcceptTrip(trip.id)}
                            disabled={isLoading}
                          >
                            Aceitar
                          </Button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                          <div>
                            <span className="text-white/60">De: </span>
                            <span className="text-white">{trip.origin_address}</span>
                          </div>
                          <div>
                            <span className="text-white/60">Para: </span>
                            <span className="text-white">{trip.destination_address}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}

        {/* Gamificação */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Conquistas Recentes */}
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-6">
              <h3 className="text-lg font-bold text-white mb-4">Conquistas Recentes</h3>
              
              {achievements.length === 0 ? (
                <div className="text-center py-4">
                  <Icon name="award" className="w-8 h-8 text-white/40 mx-auto mb-2" />
                  <p className="text-white/60 text-sm">Nenhuma conquista ainda</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {achievements.slice(0, 3).map((achievement) => (
                    <div key={achievement.id} className="flex items-center space-x-3">
                      <Icon name={achievement.icon} className="w-6 h-6 text-yellow-400" />
                      <div>
                        <p className="text-white font-medium">{achievement.name}</p>
                        <p className="text-white/60 text-sm">{achievement.description}</p>
                      </div>
                      <span className="text-yellow-400 text-sm">+{achievement.xp_reward} XP</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>

          {/* Desafios Diários */}
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-6">
              <h3 className="text-lg font-bold text-white mb-4">Desafios de Hoje</h3>
              
              {challenges.daily_challenges?.length === 0 ? (
                <div className="text-center py-4">
                  <Icon name="target" className="w-8 h-8 text-white/40 mx-auto mb-2" />
                  <p className="text-white/60 text-sm">Nenhum desafio disponível</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {challenges.daily_challenges?.slice(0, 3).map((challenge) => (
                    <div key={challenge.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="text-white font-medium">{challenge.name}</p>
                        <span className="text-yellow-400 text-sm">+{challenge.xp_reward} XP</span>
                      </div>
                      <p className="text-white/60 text-sm">{challenge.description}</p>
                      
                      <div className="w-full bg-white/10 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-manus-primary to-manus-secondary h-2 rounded-full transition-all duration-300"
                          style={{ 
                            width: `${Math.min(100, (challenge.progress / challenge.target) * 100)}%` 
                          }}
                        ></div>
                      </div>
                      
                      <div className="flex justify-between text-xs text-white/60">
                        <span>{challenge.progress}/{challenge.target}</span>
                        <span>{Math.round((challenge.progress / challenge.target) * 100)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;

