  // Supabase Keys


Project name:
admrundrivers's Project

Project ID:
jevaycxfcszepxuybxel

Project URL:
https://jevaycxfcszepxuybxel.supabase.co

Database key:
H@cker99813044

API Keys
anon/public:
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpldmF5Y3hmY3N6ZXB4dXlieGVsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA1MzY3NTgsImV4cCI6MjA2NjExMjc1OH0.s3RHm6XVWr9UCi57fGNpB4MSa5cDLYAgvNcaf9MjUqs

service_role/secret:
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpldmF5Y3hmY3N6ZXB4dXlieGVsIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MDUzNjc1OCwiZXhwIjoyMDY2MTEyNzU4fQ.qzVBewy9zwmXZXtBS25lH_HWAqShBQ5sUeES8tyDW4g

JWT Keys
JWT Secret:
GsFzEwqKgnx6asUskJG8oJelqUJ2zIRai14D3WiVjGoXzD1kJhvayr+Dyp0qdHbVPcTUMsDRiShOAPlWGPqzqg==

S3 Connection:
Endpoint:
https://jevaycxfcszepxuybxel.supabase.co/storage/v1/s3
Region:
us-west-1


  // Token Railway
 
 Name:
 adm-rundrivers
 API Token:
 99451426-65a7-42fc-963e-5b13fd084cf4


  // Stripe Keys

Account Name:
Run Drivers

Chave Publicavel
pk_live_51RcZo5FfEayUxbc0SJw7XD3DbxP2JgDoghoe066DHh82wwBAs4iwOGwiUvVmUAHnc4tCd1TZq7eWpuFM3Pz8cx0W005HiMr0D7

Chave Secreta:
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

Linguagem do SDK:
Python

