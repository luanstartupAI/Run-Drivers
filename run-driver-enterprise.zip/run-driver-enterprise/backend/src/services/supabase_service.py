import os
from supabase import create_client, Client
from typing import Dict, List, Any, Optional
import json

class SupabaseService:
    def __init__(self):
        url = os.getenv('SUPABASE_URL')
        key = os.getenv('SUPABASE_KEY')
        
        if not url or not key:
            raise ValueError("SUPABASE_URL e SUPABASE_KEY devem estar configuradas")
        
        self.supabase: Client = create_client(url, key)
    
    # Métodos de autenticação
    
    def sign_up(self, email: str, password: str, metadata: Dict = None) -> Dict:
        """Criar nova conta no Supabase"""
        try:
            response = self.supabase.auth.sign_up({
                "email": email,
                "password": password,
                "options": {
                    "data": metadata or {}
                }
            })
            return {
                "success": True,
                "user": response.user,
                "session": response.session
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def sign_in(self, email: str, password: str) -> Dict:
        """Fazer login no Supabase"""
        try:
            response = self.supabase.auth.sign_in_with_password({
                "email": email,
                "password": password
            })
            return {
                "success": True,
                "user": response.user,
                "session": response.session
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def sign_out(self) -> Dict:
        """Fazer logout no Supabase"""
        try:
            self.supabase.auth.sign_out()
            return {"success": True}
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_user(self, access_token: str) -> Dict:
        """Obter dados do usuário pelo token"""
        try:
            response = self.supabase.auth.get_user(access_token)
            return {
                "success": True,
                "user": response.user
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    # Métodos de banco de dados
    
    def create_driver_profile(self, user_id: str, driver_data: Dict) -> Dict:
        """Criar perfil de motorista no Supabase"""
        try:
            response = self.supabase.table('drivers').insert({
                'user_id': user_id,
                'name': driver_data.get('name'),
                'phone': driver_data.get('phone'),
                'cpf': driver_data.get('cpf'),
                'vehicle_type': driver_data.get('vehicle_type'),
                'vehicle_plate': driver_data.get('vehicle_plate'),
                'vehicle_model': driver_data.get('vehicle_model'),
                'vehicle_year': driver_data.get('vehicle_year'),
                'license_number': driver_data.get('license_number'),
                'is_verified': False,
                'is_online': False,
                'is_available': False,
                'rating': 5.0,
                'total_trips': 0,
                'total_earnings': 0.0,
                'earnings_today': 0.0,
                'earnings_week': 0.0,
                'earnings_month': 0.0,
                'level': 1,
                'xp': 0
            }).execute()
            
            return {
                "success": True,
                "driver": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_driver_profile(self, user_id: str) -> Dict:
        """Obter perfil do motorista"""
        try:
            response = self.supabase.table('drivers').select('*').eq('user_id', user_id).execute()
            
            return {
                "success": True,
                "driver": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def update_driver_profile(self, user_id: str, updates: Dict) -> Dict:
        """Atualizar perfil do motorista"""
        try:
            response = self.supabase.table('drivers').update(updates).eq('user_id', user_id).execute()
            
            return {
                "success": True,
                "driver": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def update_driver_location(self, user_id: str, lat: float, lng: float) -> Dict:
        """Atualizar localização do motorista"""
        try:
            response = self.supabase.table('drivers').update({
                'current_lat': lat,
                'current_lng': lng,
                'last_location_update': 'now()'
            }).eq('user_id', user_id).execute()
            
            return {
                "success": True,
                "driver": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_nearby_drivers(self, lat: float, lng: float, radius_km: float = 10) -> Dict:
        """Buscar motoristas próximos"""
        try:
            # Usar função SQL para calcular distância
            response = self.supabase.rpc('get_nearby_drivers', {
                'lat': lat,
                'lng': lng,
                'radius_km': radius_km
            }).execute()
            
            return {
                "success": True,
                "drivers": response.data or []
            }
        except Exception as e:
            # Fallback: buscar todos os motoristas online
            try:
                response = self.supabase.table('drivers').select('*').eq('is_online', True).eq('is_available', True).execute()
                return {
                    "success": True,
                    "drivers": response.data or []
                }
            except:
                return {
                    "success": False,
                    "error": str(e)
                }
    
    # Métodos de viagens
    
    def create_trip(self, trip_data: Dict) -> Dict:
        """Criar nova viagem"""
        try:
            response = self.supabase.table('trips').insert(trip_data).execute()
            
            return {
                "success": True,
                "trip": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_driver_trips(self, driver_id: str, limit: int = 10, offset: int = 0) -> Dict:
        """Obter viagens do motorista"""
        try:
            response = self.supabase.table('trips').select('*').eq('driver_id', driver_id).order('created_at', desc=True).limit(limit).offset(offset).execute()
            
            return {
                "success": True,
                "trips": response.data or []
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def update_trip_status(self, trip_id: str, status: str, updates: Dict = None) -> Dict:
        """Atualizar status da viagem"""
        try:
            update_data = {'status': status}
            if updates:
                update_data.update(updates)
            
            response = self.supabase.table('trips').update(update_data).eq('id', trip_id).execute()
            
            return {
                "success": True,
                "trip": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    # Métodos de storage
    
    def upload_document(self, bucket: str, file_path: str, file_data: bytes, content_type: str = None) -> Dict:
        """Upload de documento para Supabase Storage"""
        try:
            response = self.supabase.storage.from_(bucket).upload(
                file_path, 
                file_data,
                file_options={
                    "content-type": content_type or "application/octet-stream"
                }
            )
            
            # Obter URL pública
            public_url = self.supabase.storage.from_(bucket).get_public_url(file_path)
            
            return {
                "success": True,
                "path": response.path if hasattr(response, 'path') else file_path,
                "public_url": public_url
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def delete_file(self, bucket: str, file_path: str) -> Dict:
        """Deletar arquivo do storage"""
        try:
            response = self.supabase.storage.from_(bucket).remove([file_path])
            
            return {
                "success": True,
                "response": response
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    # Métodos de gamificação
    
    def get_driver_achievements(self, driver_id: str) -> Dict:
        """Obter conquistas do motorista"""
        try:
            response = self.supabase.table('driver_achievements').select('*, achievements(*)').eq('driver_id', driver_id).execute()
            
            return {
                "success": True,
                "achievements": response.data or []
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def unlock_achievement(self, driver_id: str, achievement_id: str) -> Dict:
        """Desbloquear conquista para motorista"""
        try:
            response = self.supabase.table('driver_achievements').insert({
                'driver_id': driver_id,
                'achievement_id': achievement_id,
                'unlocked_at': 'now()'
            }).execute()
            
            return {
                "success": True,
                "achievement": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_leaderboard(self, period: str = 'week', limit: int = 10) -> Dict:
        """Obter ranking de motoristas"""
        try:
            # Determinar campo baseado no período
            field_map = {
                'day': 'earnings_today',
                'week': 'earnings_week',
                'month': 'earnings_month',
                'all': 'total_earnings'
            }
            
            field = field_map.get(period, 'earnings_week')
            
            response = self.supabase.table('drivers').select('user_id, name, rating, total_trips, ' + field).order(field, desc=True).limit(limit).execute()
            
            return {
                "success": True,
                "leaderboard": response.data or []
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    # Métodos de rede social
    
    def create_social_post(self, author_id: str, content: str, image_url: str = None, location: Dict = None) -> Dict:
        """Criar post na rede social"""
        try:
            post_data = {
                'author_id': author_id,
                'content': content,
                'image_url': image_url,
                'likes_count': 0,
                'comments_count': 0
            }
            
            if location:
                post_data.update({
                    'location_lat': location.get('lat'),
                    'location_lng': location.get('lng'),
                    'location_name': location.get('name')
                })
            
            response = self.supabase.table('social_posts').insert(post_data).execute()
            
            return {
                "success": True,
                "post": response.data[0] if response.data else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_social_feed(self, limit: int = 10, offset: int = 0) -> Dict:
        """Obter feed da rede social"""
        try:
            response = self.supabase.table('social_posts').select('*, drivers(name, rating)').order('created_at', desc=True).limit(limit).offset(offset).execute()
            
            return {
                "success": True,
                "posts": response.data or []
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def like_post(self, post_id: str, user_id: str) -> Dict:
        """Curtir/descurtir post"""
        try:
            # Verificar se já curtiu
            existing_like = self.supabase.table('social_likes').select('*').eq('post_id', post_id).eq('user_id', user_id).execute()
            
            if existing_like.data:
                # Remover curtida
                self.supabase.table('social_likes').delete().eq('post_id', post_id).eq('user_id', user_id).execute()
                
                # Decrementar contador
                self.supabase.rpc('decrement_post_likes', {'post_id': post_id}).execute()
                
                return {
                    "success": True,
                    "action": "unliked"
                }
            else:
                # Adicionar curtida
                self.supabase.table('social_likes').insert({
                    'post_id': post_id,
                    'user_id': user_id
                }).execute()
                
                # Incrementar contador
                self.supabase.rpc('increment_post_likes', {'post_id': post_id}).execute()
                
                return {
                    "success": True,
                    "action": "liked"
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    # Métodos de realtime
    
    def subscribe_to_driver_updates(self, driver_id: str, callback):
        """Inscrever-se em atualizações do motorista em tempo real"""
        try:
            channel = self.supabase.channel(f'driver_{driver_id}')
            channel.on('postgres_changes', {
                'event': '*',
                'schema': 'public',
                'table': 'drivers',
                'filter': f'user_id=eq.{driver_id}'
            }, callback)
            channel.subscribe()
            
            return {
                "success": True,
                "channel": channel
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def subscribe_to_trip_updates(self, trip_id: str, callback):
        """Inscrever-se em atualizações da viagem em tempo real"""
        try:
            channel = self.supabase.channel(f'trip_{trip_id}')
            channel.on('postgres_changes', {
                'event': '*',
                'schema': 'public',
                'table': 'trips',
                'filter': f'id=eq.{trip_id}'
            }, callback)
            channel.subscribe()
            
            return {
                "success": True,
                "channel": channel
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

# Instância global do serviço Supabase
supabase_service = SupabaseService()

