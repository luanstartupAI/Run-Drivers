import os
import google.generativeai as genai
import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

class AIService:
    def __init__(self):
        # Configurar Gemini
        api_key = os.getenv('GEMINI_API_KEY')
        if not api_key:
            raise ValueError("GEMINI_API_KEY não encontrada nas variáveis de ambiente")
        
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-pro')
        
    async def get_location_recommendations(self, driver_data: Dict) -> Dict:
        """Gera recomendações de localização usando IA"""
        try:
            # Preparar contexto do motorista
            current_time = datetime.now().strftime('%H:%M')
            current_day = datetime.now().strftime('%A')
            current_lat = driver_data.get('current_lat', 0)
            current_lng = driver_data.get('current_lng', 0)
            total_trips = driver_data.get('total_trips', 0)
            rating = driver_data.get('rating', 5.0)
            earnings_today = driver_data.get('earnings_today', 0)
            
            context = f"""
            Dados do motorista:
            - Localização atual: {current_lat}, {current_lng}
            - Histórico de viagens: {total_trips} viagens
            - Avaliação: {rating}/5.0
            - Horário atual: {current_time}
            - Dia da semana: {current_day}
            - Ganhos hoje: R$ {earnings_today}
            
            Com base nesses dados, sugira 3 localizações estratégicas onde o motorista 
            deveria se posicionar para maximizar suas chances de conseguir viagens.
            
            Responda em formato JSON com esta estrutura:
            {{
                "recommendations": [
                    {{
                        "location": "Nome do local",
                        "reason": "Motivo da recomendação",
                        "demand_level": "alta|média|baixa",
                        "estimated_wait_time": "tempo em minutos",
                        "potential_earnings": "valor estimado por hora"
                    }}
                ]
            }}
            """
            
            response = self.model.generate_content(context)
            
            # Tentar parsear resposta JSON
            try:
                ai_response = json.loads(response.text)
                return ai_response
            except json.JSONDecodeError:
                # Fallback se a IA não retornar JSON válido
                return self._get_fallback_location_recommendations()
                
        except Exception as e:
            print(f"Erro na IA de localização: {e}")
            return self._get_fallback_location_recommendations()
    
    async def get_schedule_recommendations(self, driver_data: Dict) -> Dict:
        """Gera recomendações de horário usando IA"""
        try:
            earnings_week = driver_data.get('earnings_week', 0)
            hours_today = driver_data.get('hours_today', 0)
            work_pattern = driver_data.get('work_pattern', 'manhã e tarde')
            city = driver_data.get('city', 'São Paulo')
            
            context = f"""
            Dados do motorista:
            - Ganhos esta semana: R$ {earnings_week}
            - Meta semanal: R$ 1500
            - Horas trabalhadas hoje: {hours_today}
            - Padrão de trabalho: {work_pattern}
            - Localização: {city}
            
            Analise os dados e sugira os melhores horários para trabalhar nos próximos 3 dias
            para maximizar os ganhos. Considere padrões de demanda, trânsito e eventos locais.
            
            Responda em formato JSON:
            {{
                "schedule_recommendations": [
                    {{
                        "day": "hoje|amanhã|depois de amanhã",
                        "time_slots": [
                            {{
                                "start_time": "HH:MM",
                                "end_time": "HH:MM",
                                "demand_level": "alta|média|baixa",
                                "reason": "motivo",
                                "estimated_earnings": "valor por hora"
                            }}
                        ]
                    }}
                ]
            }}
            """
            
            response = self.model.generate_content(context)
            
            try:
                ai_response = json.loads(response.text)
                return ai_response
            except json.JSONDecodeError:
                return self._get_fallback_schedule_recommendations()
                
        except Exception as e:
            print(f"Erro na IA de horário: {e}")
            return self._get_fallback_schedule_recommendations()
    
    async def get_personalization_profile(self, driver_data: Dict) -> Dict:
        """Cria perfil de personalização usando IA"""
        try:
            name = driver_data.get('name', 'Motorista')
            total_trips = driver_data.get('total_trips', 0)
            rating = driver_data.get('rating', 5.0)
            vehicle_type = driver_data.get('vehicle_type', 'Carro')
            preferred_hours = driver_data.get('preferred_hours', 'Flexível')
            average_earnings = driver_data.get('average_earnings', 0)
            
            context = f"""
            Analise o perfil do motorista e crie recomendações personalizadas:
            
            Dados do motorista:
            - Nome: {name}
            - Experiência: {total_trips} viagens
            - Avaliação média: {rating}
            - Tipo de veículo: {vehicle_type}
            - Horários preferidos: {preferred_hours}
            - Ganhos médios: R$ {average_earnings}/dia
            
            Com base nesses dados, crie um perfil de personalização que inclua:
            1. Tipo de motorista (iniciante, experiente, especialista)
            2. Pontos fortes
            3. Áreas de melhoria
            4. Recomendações específicas
            5. Metas sugeridas
            
            Responda em formato JSON:
            {{
                "profile": {{
                    "driver_type": "tipo",
                    "experience_level": "iniciante|intermediário|avançado|especialista",
                    "strengths": ["ponto forte 1", "ponto forte 2"],
                    "improvement_areas": ["área 1", "área 2"],
                    "recommendations": ["recomendação 1", "recomendação 2"],
                    "suggested_goals": {{
                        "daily_trips": 10,
                        "daily_earnings": 200,
                        "rating_target": 4.8
                    }}
                }}
            }}
            """
            
            response = self.model.generate_content(context)
            
            try:
                ai_response = json.loads(response.text)
                return ai_response
            except json.JSONDecodeError:
                return self._get_fallback_personalization_profile(driver_data)
                
        except Exception as e:
            print(f"Erro na IA de personalização: {e}")
            return self._get_fallback_personalization_profile(driver_data)
    
    async def optimize_trip_matching(self, trip_data: Dict, available_drivers: List[Dict]) -> Dict:
        """Otimiza matching de viagens usando IA"""
        try:
            origin = trip_data.get('origin_address')
            destination = trip_data.get('destination_address')
            distance = trip_data.get('distance')
            price = trip_data.get('price')
            requested_time = trip_data.get('requested_time')
            num_drivers = len(available_drivers)
            
            context = f"""
            Dados da viagem:
            - Origem: {origin}
            - Destino: {destination}
            - Distância: {distance} km
            - Valor: R$ {price}
            - Horário: {requested_time}
            
            Motoristas disponíveis: {num_drivers} motoristas
            
            Analise e sugira o melhor matching considerando:
            - Proximidade do motorista
            - Avaliação do motorista
            - Histórico de cancelamentos
            - Eficiência da rota
            - Satisfação do passageiro
            
            Responda em formato JSON:
            {{
                "best_matches": [
                    {{
                        "driver_id": "id",
                        "match_score": 0.95,
                        "reasons": ["motivo 1", "motivo 2"],
                        "estimated_arrival": "tempo em minutos"
                    }}
                ]
            }}
            """
            
            response = self.model.generate_content(context)
            
            try:
                ai_response = json.loads(response.text)
                return ai_response
            except json.JSONDecodeError:
                return self._get_fallback_trip_matching(available_drivers)
                
        except Exception as e:
            print(f"Erro na IA de matching: {e}")
            return self._get_fallback_trip_matching(available_drivers)
    
    async def predict_demand(self, location_data: Dict) -> Dict:
        """Prediz demanda usando IA"""
        try:
            lat = location_data.get('lat')
            lng = location_data.get('lng')
            current_time = datetime.now().strftime('%H:%M')
            current_day = datetime.now().strftime('%A')
            historical_demand = location_data.get('historical_demand', 'médio')
            
            context = f"""
            Dados da localização:
            - Latitude: {lat}
            - Longitude: {lng}
            - Horário atual: {current_time}
            - Dia da semana: {current_day}
            - Histórico de demanda: {historical_demand}
            
            Analise e prediga a demanda por viagens nesta localização para as próximas 2 horas.
            Considere fatores como:
            - Padrões históricos
            - Eventos locais
            - Condições climáticas
            - Horário de pico
            - Proximidade de pontos de interesse
            
            Responda em formato JSON:
            {{
                "demand_prediction": {{
                    "current_demand": "alta|média|baixa",
                    "next_hour_demand": "alta|média|baixa",
                    "peak_times": ["HH:MM", "HH:MM"],
                    "demand_factors": ["fator 1", "fator 2"],
                    "confidence_level": 0.85
                }}
            }}
            """
            
            response = self.model.generate_content(context)
            
            try:
                ai_response = json.loads(response.text)
                return ai_response
            except json.JSONDecodeError:
                return self._get_fallback_demand_prediction()
                
        except Exception as e:
            print(f"Erro na IA de demanda: {e}")
            return self._get_fallback_demand_prediction()
    
    async def get_performance_analytics(self, driver_data: Dict) -> Dict:
        """Gera analytics de performance usando IA"""
        try:
            total_trips = driver_data.get('total_trips', 0)
            rating = driver_data.get('rating', 5.0)
            cancellation_rate = driver_data.get('cancellation_rate', 0)
            total_earnings = driver_data.get('total_earnings', 0)
            avg_trip_time = driver_data.get('avg_trip_time', 0)
            avg_distance = driver_data.get('avg_distance', 0)
            
            context = f"""
            Dados de performance do motorista:
            - Total de viagens: {total_trips}
            - Avaliação média: {rating}
            - Taxa de cancelamento: {cancellation_rate}%
            - Ganhos totais: R$ {total_earnings}
            - Tempo médio por viagem: {avg_trip_time} min
            - Distância média: {avg_distance} km
            
            Analise a performance e forneça insights detalhados sobre:
            1. Pontos fortes do motorista
            2. Áreas que precisam melhorar
            3. Comparação com outros motoristas
            4. Sugestões específicas de melhoria
            5. Metas realistas
            
            Responda em formato JSON:
            {{
                "analytics": {{
                    "overall_score": 8.5,
                    "performance_areas": {{
                        "punctuality": 9.0,
                        "customer_service": 8.5,
                        "efficiency": 7.8,
                        "reliability": 9.2
                    }},
                    "insights": ["insight 1", "insight 2"],
                    "improvement_suggestions": ["sugestão 1", "sugestão 2"],
                    "benchmarks": {{
                        "vs_average": "+15%",
                        "ranking": "Top 20%"
                    }}
                }}
            }}
            """
            
            response = self.model.generate_content(context)
            
            try:
                ai_response = json.loads(response.text)
                return ai_response
            except json.JSONDecodeError:
                return self._get_fallback_performance_analytics(driver_data)
                
        except Exception as e:
            print(f"Erro na IA de analytics: {e}")
            return self._get_fallback_performance_analytics(driver_data)
    
    async def process_chatbot_message(self, message: str, context: Dict) -> Dict:
        """Processa mensagem do chatbot usando IA"""
        try:
            driver_name = context.get('driver_name', 'Motorista')
            trips_today = context.get('trips_today', 0)
            earnings_today = context.get('earnings_today', 0)
            status = context.get('status', 'offline')
            
            system_context = f"""
            Você é um assistente virtual especializado em ajudar motoristas de aplicativo.
            
            Contexto do motorista:
            - Nome: {driver_name}
            - Viagens hoje: {trips_today}
            - Ganhos hoje: R$ {earnings_today}
            - Status: {status}
            
            Mensagem do motorista: "{message}"
            
            Responda de forma útil, amigável e profissional. Forneça informações práticas
            e actionáveis. Se for uma pergunta sobre o app, explique claramente.
            
            Responda em formato JSON:
            {{
                "response": "sua resposta aqui",
                "suggestions": ["sugestão 1", "sugestão 2"],
                "quick_actions": ["ação 1", "ação 2"]
            }}
            """
            
            response = self.model.generate_content(system_context)
            
            try:
                ai_response = json.loads(response.text)
                return ai_response
            except json.JSONDecodeError:
                return {
                    "response": response.text,
                    "suggestions": [],
                    "quick_actions": []
                }
                
        except Exception as e:
            print(f"Erro no chatbot: {e}")
            return {
                "response": "Desculpe, estou com dificuldades técnicas no momento. Tente novamente em alguns instantes.",
                "suggestions": ["Verificar conexão", "Tentar novamente"],
                "quick_actions": []
            }
    
    # Métodos de fallback para quando a IA falha
    
    def _get_fallback_location_recommendations(self) -> Dict:
        return {
            "recommendations": [
                {
                    "location": "Centro da cidade",
                    "reason": "Alta demanda durante horário comercial",
                    "demand_level": "alta",
                    "estimated_wait_time": "5-10 minutos",
                    "potential_earnings": "R$ 25-35/hora"
                },
                {
                    "location": "Aeroporto",
                    "reason": "Viagens longas e bem remuneradas",
                    "demand_level": "média",
                    "estimated_wait_time": "15-20 minutos",
                    "potential_earnings": "R$ 30-45/hora"
                },
                {
                    "location": "Shopping centers",
                    "reason": "Movimento constante de passageiros",
                    "demand_level": "média",
                    "estimated_wait_time": "8-12 minutos",
                    "potential_earnings": "R$ 20-30/hora"
                }
            ]
        }
    
    def _get_fallback_schedule_recommendations(self) -> Dict:
        return {
            "schedule_recommendations": [
                {
                    "day": "hoje",
                    "time_slots": [
                        {
                            "start_time": "07:00",
                            "end_time": "09:00",
                            "demand_level": "alta",
                            "reason": "Horário de pico matinal",
                            "estimated_earnings": "R$ 35/hora"
                        },
                        {
                            "start_time": "17:00",
                            "end_time": "19:00",
                            "demand_level": "alta",
                            "reason": "Horário de pico vespertino",
                            "estimated_earnings": "R$ 40/hora"
                        }
                    ]
                }
            ]
        }
    
    def _get_fallback_personalization_profile(self, driver_data: Dict) -> Dict:
        trips = driver_data.get('total_trips', 0)
        rating = driver_data.get('rating', 5.0)
        
        if trips < 50:
            experience = "iniciante"
            driver_type = "Motorista em desenvolvimento"
        elif trips < 200:
            experience = "intermediário"
            driver_type = "Motorista experiente"
        else:
            experience = "avançado"
            driver_type = "Motorista especialista"
        
        return {
            "profile": {
                "driver_type": driver_type,
                "experience_level": experience,
                "strengths": ["Pontualidade", "Atendimento cordial"],
                "improvement_areas": ["Eficiência de rotas", "Conhecimento da cidade"],
                "recommendations": ["Usar GPS otimizado", "Estudar rotas alternativas"],
                "suggested_goals": {
                    "daily_trips": min(15, trips // 10 + 5),
                    "daily_earnings": 200,
                    "rating_target": min(5.0, rating + 0.1)
                }
            }
        }
    
    def _get_fallback_trip_matching(self, available_drivers: List[Dict]) -> Dict:
        # Simular matching baseado em proximidade
        matches = []
        for i, driver in enumerate(available_drivers[:3]):
            matches.append({
                "driver_id": driver.get('id', f'driver_{i}'),
                "match_score": random.uniform(0.8, 0.95),
                "reasons": ["Proximidade", "Boa avaliação"],
                "estimated_arrival": f"{random.randint(3, 8)} minutos"
            })
        
        return {"best_matches": matches}
    
    def _get_fallback_demand_prediction(self) -> Dict:
        current_hour = datetime.now().hour
        
        if 7 <= current_hour <= 9 or 17 <= current_hour <= 19:
            demand = "alta"
        elif 10 <= current_hour <= 16 or 20 <= current_hour <= 22:
            demand = "média"
        else:
            demand = "baixa"
        
        return {
            "demand_prediction": {
                "current_demand": demand,
                "next_hour_demand": demand,
                "peak_times": ["07:30", "18:00"],
                "demand_factors": ["Horário de pico", "Movimento urbano"],
                "confidence_level": 0.75
            }
        }
    
    def _get_fallback_performance_analytics(self, driver_data: Dict) -> Dict:
        rating = driver_data.get('rating', 5.0)
        trips = driver_data.get('total_trips', 0)
        
        overall_score = min(10, (rating * 2) + (min(trips, 100) / 20))
        
        return {
            "analytics": {
                "overall_score": round(overall_score, 1),
                "performance_areas": {
                    "punctuality": rating * 2,
                    "customer_service": rating * 2,
                    "efficiency": rating * 1.8,
                    "reliability": rating * 1.9
                },
                "insights": [
                    "Performance acima da média",
                    "Boa avaliação dos passageiros"
                ],
                "improvement_suggestions": [
                    "Manter qualidade do atendimento",
                    "Otimizar rotas para maior eficiência"
                ],
                "benchmarks": {
                    "vs_average": "+10%",
                    "ranking": "Top 30%"
                }
            }
        }

# Instância global do serviço de IA
ai_service = AIService()

