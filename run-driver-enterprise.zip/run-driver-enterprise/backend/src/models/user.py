from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    type = db.Column(db.String(20), nullable=False, default='driver')  # 'driver' ou 'passenger'
    verified = db.Column(db.Boolean, default=False)
    onboarding_completed = db.Column(db.Boolean, default=False)
    biometric_verified = db.Column(db.Boolean, default=False)
    supabase_user_id = db.Column(db.String(100), nullable=True, index=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Relacionamentos
    driver_profile = db.relationship('Driver', backref='user', uselist=False, cascade='all, delete-orphan')
    documents = db.relationship('Document', backref='user', cascade='all, delete-orphan')
    social_posts = db.relationship('SocialPost', backref='author', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<User {self.email}>'

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'name': self.name,
            'phone': self.phone,
            'type': self.type,
            'verified': self.verified,
            'onboarding_completed': self.onboarding_completed,
            'biometric_verified': self.biometric_verified,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }

class Driver(db.Model):
    __tablename__ = 'drivers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    
    # Documentos e verificação
    license_number = db.Column(db.String(50), nullable=True)
    license_category = db.Column(db.String(10), nullable=True)
    license_expiry = db.Column(db.Date, nullable=True)
    
    # Veículo
    vehicle_model = db.Column(db.String(100), nullable=True)
    vehicle_plate = db.Column(db.String(20), nullable=True)
    vehicle_year = db.Column(db.Integer, nullable=True)
    vehicle_color = db.Column(db.String(30), nullable=True)
    
    # Métricas
    rating = db.Column(db.Float, default=5.0)
    total_trips = db.Column(db.Integer, default=0)
    total_earnings = db.Column(db.Float, default=0.0)
    
    # Gamificação
    level = db.Column(db.Integer, default=1)
    xp = db.Column(db.Integer, default=0)
    
    # Ganhos
    earnings_today = db.Column(db.Float, default=0.0)
    earnings_week = db.Column(db.Float, default=0.0)
    earnings_month = db.Column(db.Float, default=0.0)
    
    # Status e localização
    is_online = db.Column(db.Boolean, default=False)
    is_available = db.Column(db.Boolean, default=True)
    current_lat = db.Column(db.Float, nullable=True)
    current_lng = db.Column(db.Float, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    trips = db.relationship('Trip', backref='driver', cascade='all, delete-orphan')
    achievements = db.relationship('Achievement', backref='driver', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Driver {self.user.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'license_number': self.license_number,
            'license_category': self.license_category,
            'license_expiry': self.license_expiry.isoformat() if self.license_expiry else None,
            'vehicle_model': self.vehicle_model,
            'vehicle_plate': self.vehicle_plate,
            'vehicle_year': self.vehicle_year,
            'vehicle_color': self.vehicle_color,
            'rating': self.rating,
            'total_trips': self.total_trips,
            'total_earnings': self.total_earnings,
            'level': self.level,
            'xp': self.xp,
            'earnings_today': self.earnings_today,
            'earnings_week': self.earnings_week,
            'earnings_month': self.earnings_month,
            'is_online': self.is_online,
            'is_available': self.is_available,
            'current_lat': self.current_lat,
            'current_lng': self.current_lng,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Trip(db.Model):
    __tablename__ = 'trips'
    
    id = db.Column(db.Integer, primary_key=True)
    driver_id = db.Column(db.Integer, db.ForeignKey('drivers.id'), nullable=False)
    passenger_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # Origem e destino
    origin_lat = db.Column(db.Float, nullable=False)
    origin_lng = db.Column(db.Float, nullable=False)
    origin_address = db.Column(db.Text, nullable=False)
    destination_lat = db.Column(db.Float, nullable=False)
    destination_lng = db.Column(db.Float, nullable=False)
    destination_address = db.Column(db.Text, nullable=False)
    
    # Detalhes da viagem
    distance = db.Column(db.Float, nullable=False)  # em km
    duration = db.Column(db.Integer, nullable=False)  # em minutos
    price = db.Column(db.Float, nullable=False)
    
    # Status
    status = db.Column(db.String(20), default='pending')  # pending, accepted, in_progress, completed, cancelled
    
    # Avaliações
    driver_rating = db.Column(db.Integer, nullable=True)  # 1-5
    passenger_rating = db.Column(db.Integer, nullable=True)  # 1-5
    driver_comment = db.Column(db.Text, nullable=True)
    passenger_comment = db.Column(db.Text, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_at = db.Column(db.DateTime, nullable=True)
    started_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Trip {self.id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'driver_id': self.driver_id,
            'passenger_id': self.passenger_id,
            'origin_lat': self.origin_lat,
            'origin_lng': self.origin_lng,
            'origin_address': self.origin_address,
            'destination_lat': self.destination_lat,
            'destination_lng': self.destination_lng,
            'destination_address': self.destination_address,
            'distance': self.distance,
            'duration': self.duration,
            'price': self.price,
            'status': self.status,
            'driver_rating': self.driver_rating,
            'passenger_rating': self.passenger_rating,
            'driver_comment': self.driver_comment,
            'passenger_comment': self.passenger_comment,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'accepted_at': self.accepted_at.isoformat() if self.accepted_at else None,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Achievement(db.Model):
    __tablename__ = 'achievements'
    
    id = db.Column(db.Integer, primary_key=True)
    driver_id = db.Column(db.Integer, db.ForeignKey('drivers.id'), nullable=False)
    
    type = db.Column(db.String(50), nullable=False)  # trips, rating, earnings, etc.
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    icon = db.Column(db.String(50), nullable=False)
    xp_reward = db.Column(db.Integer, default=0)
    
    unlocked_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Achievement {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'driver_id': self.driver_id,
            'type': self.type,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            'xp_reward': self.xp_reward,
            'unlocked_at': self.unlocked_at.isoformat() if self.unlocked_at else None
        }

class Document(db.Model):
    __tablename__ = 'documents'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    type = db.Column(db.String(50), nullable=False)  # driver_license, vehicle_registration, etc.
    url = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    
    # Dados extraídos por OCR
    extracted_data = db.Column(db.JSON, nullable=True)
    
    # Timestamps
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f'<Document {self.type}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'type': self.type,
            'url': self.url,
            'status': self.status,
            'extracted_data': self.extracted_data,
            'uploaded_at': self.uploaded_at.isoformat() if self.uploaded_at else None,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None
        }

class SocialPost(db.Model):
    __tablename__ = 'social_posts'
    
    id = db.Column(db.Integer, primary_key=True)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    content = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(500), nullable=True)
    location_lat = db.Column(db.Float, nullable=True)
    location_lng = db.Column(db.Float, nullable=True)
    location_name = db.Column(db.String(200), nullable=True)
    
    # Métricas
    likes_count = db.Column(db.Integer, default=0)
    comments_count = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    likes = db.relationship('SocialLike', backref='post', cascade='all, delete-orphan')
    comments = db.relationship('SocialComment', backref='post', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<SocialPost {self.id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'author_id': self.author_id,
            'author_name': self.author.name,
            'content': self.content,
            'image_url': self.image_url,
            'location_lat': self.location_lat,
            'location_lng': self.location_lng,
            'location_name': self.location_name,
            'likes_count': self.likes_count,
            'comments_count': self.comments_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class SocialLike(db.Model):
    __tablename__ = 'social_likes'
    
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('social_posts.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    __table_args__ = (db.UniqueConstraint('post_id', 'user_id', name='unique_post_like'),)

class SocialComment(db.Model):
    __tablename__ = 'social_comments'
    
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('social_posts.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamento
    author = db.relationship('User', backref='comments')

    def to_dict(self):
        return {
            'id': self.id,
            'post_id': self.post_id,
            'author_id': self.author_id,
            'author_name': self.author.name,
            'content': self.content,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

