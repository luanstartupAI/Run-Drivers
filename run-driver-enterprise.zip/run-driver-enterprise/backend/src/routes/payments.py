from flask import Blueprint, request, jsonify, current_app
from src.models.user import Driver, User, db
from src.routes.auth import require_auth
import datetime
import random
import stripe

payments_bp = Blueprint('payments', __name__)

@payments_bp.route('/wallet', methods=['GET'])
@require_auth
def get_wallet():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas têm carteira'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Calcular saldo disponível (total - saques pendentes)
        pending_withdrawals = 0  # TODO: Implementar tabela de saques
        available_balance = driver.total_earnings - pending_withdrawals
        
        wallet_data = {
            'total_balance': driver.total_earnings,
            'available_balance': available_balance,
            'pending_withdrawals': pending_withdrawals,
            'earnings_today': driver.earnings_today,
            'earnings_week': driver.earnings_week,
            'earnings_month': driver.earnings_month,
            'transactions': generate_recent_transactions(driver.id),
            'payment_methods': get_payment_methods(user_id)
        }
        
        return jsonify(wallet_data), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@payments_bp.route('/withdraw', methods=['POST'])
@require_auth
def request_withdrawal():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem sacar'}), 403
        
        user_id = request.current_user_id
        data = request.get_json()
        
        amount = data.get('amount')
        payment_method = data.get('payment_method')
        
        if not amount or amount <= 0:
            return jsonify({'error': 'Valor inválido'}), 400
        
        if not payment_method:
            return jsonify({'error': 'Método de pagamento é obrigatório'}), 400
        
        driver = Driver.query.filter_by(user_id=user_id).first()
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Verificar saldo disponível
        if amount > driver.total_earnings:
            return jsonify({'error': 'Saldo insuficiente'}), 400
        
        # Calcular taxa (1% para PIX, 2% para TED)
        fee_rate = 0.01 if payment_method == 'pix' else 0.02
        fee = amount * fee_rate
        net_amount = amount - fee
        
        # Simular processamento do saque
        withdrawal_data = {
            'id': f"wd_{random.randint(100000, 999999)}",
            'amount': amount,
            'fee': fee,
            'net_amount': net_amount,
            'payment_method': payment_method,
            'status': 'processing',
            'estimated_arrival': '1-2 dias úteis' if payment_method == 'ted' else 'Até 30 minutos',
            'created_at': datetime.datetime.now().isoformat()
        }
        
        # TODO: Salvar no banco de dados
        # TODO: Integrar com Stripe ou outro processador
        
        return jsonify({
            'message': 'Solicitação de saque processada com sucesso',
            'withdrawal': withdrawal_data
        }), 201
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@payments_bp.route('/payment-methods', methods=['GET'])
@require_auth
def get_payment_methods_route():
    try:
        user_id = request.current_user_id
        payment_methods = get_payment_methods(user_id)
        
        return jsonify({
            'payment_methods': payment_methods
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@payments_bp.route('/payment-methods', methods=['POST'])
@require_auth
def add_payment_method():
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        method_type = data.get('type')  # 'pix', 'bank_account'
        
        if method_type not in ['pix', 'bank_account']:
            return jsonify({'error': 'Tipo de método inválido'}), 400
        
        # Validar dados baseado no tipo
        if method_type == 'pix':
            if not data.get('pix_key'):
                return jsonify({'error': 'Chave PIX é obrigatória'}), 400
        elif method_type == 'bank_account':
            required_fields = ['bank_code', 'agency', 'account', 'account_type']
            for field in required_fields:
                if not data.get(field):
                    return jsonify({'error': f'{field} é obrigatório'}), 400
        
        # TODO: Salvar no banco de dados
        # TODO: Validar com APIs bancárias
        
        payment_method = {
            'id': f"pm_{random.randint(100000, 999999)}",
            'type': method_type,
            'data': data,
            'verified': False,
            'created_at': datetime.datetime.now().isoformat()
        }
        
        return jsonify({
            'message': 'Método de pagamento adicionado com sucesso',
            'payment_method': payment_method
        }), 201
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@payments_bp.route('/transactions', methods=['GET'])
@require_auth
def get_transactions():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas têm transações'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Parâmetros de paginação
        page = request.args.get('page', default=1, type=int)
        per_page = request.args.get('per_page', default=20, type=int)
        transaction_type = request.args.get('type')  # 'earning', 'withdrawal', 'bonus'
        
        # Gerar transações simuladas
        all_transactions = generate_all_transactions(driver.id)
        
        # Filtrar por tipo se especificado
        if transaction_type:
            all_transactions = [t for t in all_transactions if t['type'] == transaction_type]
        
        # Paginação manual (em produção, usar banco de dados)
        start = (page - 1) * per_page
        end = start + per_page
        transactions = all_transactions[start:end]
        
        return jsonify({
            'transactions': transactions,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': len(all_transactions),
                'pages': (len(all_transactions) + per_page - 1) // per_page
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@payments_bp.route('/earnings/summary', methods=['GET'])
@require_auth
def get_earnings_summary():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas têm resumo de ganhos'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Calcular estatísticas detalhadas
        summary = {
            'total_earnings': driver.total_earnings,
            'earnings_today': driver.earnings_today,
            'earnings_week': driver.earnings_week,
            'earnings_month': driver.earnings_month,
            'average_per_trip': driver.total_earnings / max(1, driver.total_trips),
            'total_trips': driver.total_trips,
            'platform_fee': driver.total_earnings * 0.04,  # 4% de taxa
            'net_earnings': driver.total_earnings * 0.96,
            'growth': {
                'daily': random.uniform(-10, 25),  # % crescimento
                'weekly': random.uniform(-5, 15),
                'monthly': random.uniform(0, 30)
            },
            'projections': {
                'week': driver.earnings_week * 1.2,
                'month': driver.earnings_month * 1.15
            }
        }
        
        return jsonify(summary), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@payments_bp.route('/stripe/setup-intent', methods=['POST'])
@require_auth
def create_setup_intent():
    """Criar Setup Intent para adicionar método de pagamento via Stripe"""
    try:
        # TODO: Configurar Stripe
        # stripe.api_key = current_app.config.get('STRIPE_SECRET_KEY')
        
        # Simular resposta do Stripe
        setup_intent = {
            'id': f"seti_{random.randint(100000000000000000000000, 999999999999999999999999)}",
            'client_secret': f"seti_secret_{random.randint(100000, 999999)}",
            'status': 'requires_payment_method'
        }
        
        return jsonify(setup_intent), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

# Funções auxiliares

def get_payment_methods(user_id):
    """Retorna métodos de pagamento do usuário"""
    # TODO: Buscar do banco de dados
    return [
        {
            'id': 'pm_123456',
            'type': 'pix',
            'data': {
                'pix_key': '***@email.com',
                'pix_type': 'email'
            },
            'verified': True,
            'default': True
        },
        {
            'id': 'pm_789012',
            'type': 'bank_account',
            'data': {
                'bank_name': 'Banco do Brasil',
                'agency': '1234-5',
                'account': '***67-8',
                'account_type': 'corrente'
            },
            'verified': False,
            'default': False
        }
    ]

def generate_recent_transactions(driver_id):
    """Gera transações recentes simuladas"""
    transactions = []
    
    for i in range(5):
        transaction_type = random.choice(['trip_earning', 'bonus', 'withdrawal'])
        
        if transaction_type == 'trip_earning':
            amount = random.uniform(15, 45)
            description = f"Viagem #{random.randint(1000, 9999)}"
        elif transaction_type == 'bonus':
            amount = random.uniform(5, 20)
            description = "Bônus de performance"
        else:
            amount = -random.uniform(50, 200)
            description = "Saque para conta"
        
        transactions.append({
            'id': f"txn_{random.randint(100000, 999999)}",
            'type': transaction_type,
            'amount': round(amount, 2),
            'description': description,
            'date': (datetime.datetime.now() - datetime.timedelta(hours=i*6)).isoformat(),
            'status': 'completed'
        })
    
    return transactions

def generate_all_transactions(driver_id):
    """Gera todas as transações simuladas"""
    transactions = []
    
    for i in range(50):  # 50 transações simuladas
        transaction_type = random.choice(['trip_earning', 'bonus', 'withdrawal', 'fee'])
        
        if transaction_type == 'trip_earning':
            amount = random.uniform(10, 50)
            description = f"Viagem #{random.randint(1000, 9999)}"
        elif transaction_type == 'bonus':
            amount = random.uniform(5, 25)
            description = random.choice([
                "Bônus de performance",
                "Bônus de horário de pico",
                "Bônus de avaliação"
            ])
        elif transaction_type == 'withdrawal':
            amount = -random.uniform(50, 300)
            description = "Saque para conta"
        else:  # fee
            amount = -random.uniform(1, 5)
            description = "Taxa da plataforma"
        
        transactions.append({
            'id': f"txn_{random.randint(100000, 999999)}",
            'type': transaction_type,
            'amount': round(amount, 2),
            'description': description,
            'date': (datetime.datetime.now() - datetime.timedelta(days=i)).isoformat(),
            'status': random.choice(['completed', 'pending', 'failed']) if transaction_type == 'withdrawal' else 'completed'
        })
    
    return sorted(transactions, key=lambda x: x['date'], reverse=True)

