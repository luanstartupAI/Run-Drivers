from flask import Blueprint, request, jsonify, current_app
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
import os
from supabase import create_client, Client
from src.models.user import User, db

auth_bp = Blueprint('auth', __name__)

# Inicializar cliente Supabase
def get_supabase_client():
    url = current_app.config.get('SUPABASE_URL')
    key = current_app.config.get('SUPABASE_KEY')
    if url and key:
        return create_client(url, key)
    return None

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['email', 'password', 'name', 'phone', 'type']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} é obrigatório'}), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        name = data['name'].strip()
        phone = data['phone'].strip()
        user_type = data['type']  # 'driver' ou 'passenger'
        
        # Validar tipo de usuário
        if user_type not in ['driver', 'passenger']:
            return jsonify({'error': 'Tipo de usuário inválido'}), 400
        
        # Verificar se usuário já existe
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return jsonify({'error': 'Email já cadastrado'}), 409
        
        # Criar usuário no Supabase Auth
        supabase = get_supabase_client()
        if supabase:
            try:
                auth_response = supabase.auth.sign_up({
                    'email': email,
                    'password': password,
                    'options': {
                        'data': {
                            'name': name,
                            'phone': phone,
                            'type': user_type
                        }
                    }
                })
                
                if auth_response.user:
                    supabase_user_id = auth_response.user.id
                else:
                    return jsonify({'error': 'Erro ao criar usuário no Supabase'}), 500
                    
            except Exception as e:
                return jsonify({'error': f'Erro no Supabase: {str(e)}'}), 500
        else:
            # Fallback para desenvolvimento local
            supabase_user_id = None
        
        # Criar usuário local
        password_hash = generate_password_hash(password)
        
        new_user = User(
            email=email,
            password_hash=password_hash,
            name=name,
            phone=phone,
            type=user_type,
            supabase_user_id=supabase_user_id
        )
        
        db.session.add(new_user)
        db.session.commit()
        
        # Gerar token JWT
        token = jwt.encode({
            'user_id': new_user.id,
            'email': email,
            'type': user_type,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=7)
        }, current_app.config['SECRET_KEY'], algorithm='HS256')
        
        return jsonify({
            'message': 'Usuário criado com sucesso',
            'token': token,
            'user': {
                'id': new_user.id,
                'email': new_user.email,
                'name': new_user.name,
                'phone': new_user.phone,
                'type': new_user.type,
                'verified': new_user.verified,
                'onboarding_completed': new_user.onboarding_completed
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email e senha são obrigatórios'}), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        
        # Buscar usuário
        user = User.query.filter_by(email=email).first()
        
        if not user or not check_password_hash(user.password_hash, password):
            return jsonify({'error': 'Credenciais inválidas'}), 401
        
        # Fazer login no Supabase também
        supabase = get_supabase_client()
        if supabase and user.supabase_user_id:
            try:
                supabase.auth.sign_in_with_password({
                    'email': email,
                    'password': password
                })
            except Exception as e:
                print(f"Erro no login Supabase: {e}")
        
        # Gerar token JWT
        token = jwt.encode({
            'user_id': user.id,
            'email': user.email,
            'type': user.type,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=7)
        }, current_app.config['SECRET_KEY'], algorithm='HS256')
        
        # Atualizar último login
        user.last_login = datetime.datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Login realizado com sucesso',
            'token': token,
            'user': {
                'id': user.id,
                'email': user.email,
                'name': user.name,
                'phone': user.phone,
                'type': user.type,
                'verified': user.verified,
                'onboarding_completed': user.onboarding_completed,
                'last_login': user.last_login.isoformat() if user.last_login else None
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    try:
        # Logout do Supabase
        supabase = get_supabase_client()
        if supabase:
            try:
                supabase.auth.sign_out()
            except Exception as e:
                print(f"Erro no logout Supabase: {e}")
        
        return jsonify({'message': 'Logout realizado com sucesso'}), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/verify-token', methods=['POST'])
def verify_token():
    try:
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'error': 'Token não fornecido'}), 401
        
        # Remover 'Bearer ' se presente
        if token.startswith('Bearer '):
            token = token[7:]
        
        try:
            payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            user_id = payload['user_id']
            
            # Buscar usuário
            user = User.query.get(user_id)
            if not user:
                return jsonify({'error': 'Usuário não encontrado'}), 404
            
            return jsonify({
                'valid': True,
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'name': user.name,
                    'phone': user.phone,
                    'type': user.type,
                    'verified': user.verified,
                    'onboarding_completed': user.onboarding_completed
                }
            }), 200
            
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expirado'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token inválido'}), 401
            
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/refresh-token', methods=['POST'])
def refresh_token():
    try:
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'error': 'Token não fornecido'}), 401
        
        if token.startswith('Bearer '):
            token = token[7:]
        
        try:
            # Decodificar token mesmo se expirado
            payload = jwt.decode(token, current_app.config['SECRET_KEY'], 
                              algorithms=['HS256'], options={"verify_exp": False})
            user_id = payload['user_id']
            
            # Buscar usuário
            user = User.query.get(user_id)
            if not user:
                return jsonify({'error': 'Usuário não encontrado'}), 404
            
            # Gerar novo token
            new_token = jwt.encode({
                'user_id': user.id,
                'email': user.email,
                'type': user.type,
                'exp': datetime.datetime.utcnow() + datetime.timedelta(days=7)
            }, current_app.config['SECRET_KEY'], algorithm='HS256')
            
            return jsonify({
                'message': 'Token renovado com sucesso',
                'token': new_token
            }), 200
            
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token inválido'}), 401
            
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

# Middleware para verificar autenticação
def require_auth(f):
    from functools import wraps
    
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'error': 'Token não fornecido'}), 401
        
        if token.startswith('Bearer '):
            token = token[7:]
        
        try:
            payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            request.current_user_id = payload['user_id']
            request.current_user_email = payload['email']
            request.current_user_type = payload['type']
            
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expirado'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token inválido'}), 401
        
        return f(*args, **kwargs)
    
    return decorated_function

