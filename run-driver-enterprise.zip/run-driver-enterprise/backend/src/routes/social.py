from flask import Blueprint, request, jsonify, current_app
from src.models.user import SocialPost, SocialLike, SocialComment, User, db
from src.routes.auth import require_auth
import datetime

social_bp = Blueprint('social', __name__)

@social_bp.route('/feed', methods=['GET'])
@require_auth
def get_feed():
    try:
        page = request.args.get('page', default=1, type=int)
        per_page = request.args.get('per_page', default=10, type=int)
        
        posts = SocialPost.query.order_by(
            SocialPost.created_at.desc()
        ).paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        posts_data = []
        for post in posts.items:
            post_data = post.to_dict()
            
            # Verificar se o usuário atual curtiu o post
            user_id = request.current_user_id
            liked = SocialLike.query.filter_by(
                post_id=post.id,
                user_id=user_id
            ).first() is not None
            
            post_data['liked_by_user'] = liked
            posts_data.append(post_data)
        
        return jsonify({
            'posts': posts_data,
            'pagination': {
                'page': posts.page,
                'pages': posts.pages,
                'total': posts.total,
                'has_next': posts.has_next,
                'has_prev': posts.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@social_bp.route('/posts', methods=['POST'])
@require_auth
def create_post():
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        if not data.get('content'):
            return jsonify({'error': 'Conteúdo é obrigatório'}), 400
        
        post = SocialPost(
            author_id=user_id,
            content=data['content'],
            image_url=data.get('image_url'),
            location_lat=data.get('location_lat'),
            location_lng=data.get('location_lng'),
            location_name=data.get('location_name')
        )
        
        db.session.add(post)
        db.session.commit()
        
        return jsonify({
            'message': 'Post criado com sucesso',
            'post': post.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@social_bp.route('/posts/<int:post_id>/like', methods=['POST'])
@require_auth
def like_post(post_id):
    try:
        user_id = request.current_user_id
        
        # Verificar se o post existe
        post = SocialPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Post não encontrado'}), 404
        
        # Verificar se já curtiu
        existing_like = SocialLike.query.filter_by(
            post_id=post_id,
            user_id=user_id
        ).first()
        
        if existing_like:
            # Remover curtida
            db.session.delete(existing_like)
            post.likes_count = max(0, post.likes_count - 1)
            action = 'unliked'
        else:
            # Adicionar curtida
            like = SocialLike(post_id=post_id, user_id=user_id)
            db.session.add(like)
            post.likes_count += 1
            action = 'liked'
        
        db.session.commit()
        
        return jsonify({
            'message': f'Post {action}',
            'likes_count': post.likes_count,
            'action': action
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@social_bp.route('/posts/<int:post_id>/comments', methods=['GET'])
@require_auth
def get_comments(post_id):
    try:
        # Verificar se o post existe
        post = SocialPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Post não encontrado'}), 404
        
        comments = SocialComment.query.filter_by(post_id=post_id).order_by(
            SocialComment.created_at.asc()
        ).all()
        
        comments_data = [comment.to_dict() for comment in comments]
        
        return jsonify({
            'comments': comments_data,
            'total': len(comments_data)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@social_bp.route('/posts/<int:post_id>/comments', methods=['POST'])
@require_auth
def create_comment(post_id):
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        if not data.get('content'):
            return jsonify({'error': 'Conteúdo é obrigatório'}), 400
        
        # Verificar se o post existe
        post = SocialPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Post não encontrado'}), 404
        
        comment = SocialComment(
            post_id=post_id,
            author_id=user_id,
            content=data['content']
        )
        
        db.session.add(comment)
        
        # Atualizar contador de comentários
        post.comments_count += 1
        
        db.session.commit()
        
        return jsonify({
            'message': 'Comentário criado com sucesso',
            'comment': comment.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@social_bp.route('/posts/<int:post_id>', methods=['DELETE'])
@require_auth
def delete_post(post_id):
    try:
        user_id = request.current_user_id
        
        # Buscar post
        post = SocialPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Post não encontrado'}), 404
        
        # Verificar se é o autor
        if post.author_id != user_id:
            return jsonify({'error': 'Apenas o autor pode deletar o post'}), 403
        
        # Deletar post (cascade deleta likes e comments)
        db.session.delete(post)
        db.session.commit()
        
        return jsonify({'message': 'Post deletado com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@social_bp.route('/trending', methods=['GET'])
@require_auth
def get_trending():
    try:
        # Posts mais curtidos das últimas 24 horas
        yesterday = datetime.datetime.now() - datetime.timedelta(days=1)
        
        trending_posts = SocialPost.query.filter(
            SocialPost.created_at >= yesterday
        ).order_by(
            SocialPost.likes_count.desc(),
            SocialPost.comments_count.desc()
        ).limit(10).all()
        
        posts_data = [post.to_dict() for post in trending_posts]
        
        return jsonify({
            'trending_posts': posts_data,
            'period': '24h'
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

