# Documents Route
from flask import Blueprint, request, jsonify, current_app
from src.models.user import Document, User, db
from src.routes.auth import require_auth
import datetime
import os
import uuid

documents_bp = Blueprint('documents', __name__)

@documents_bp.route('/', methods=['GET'])
@require_auth
def get_documents():
    try:
        user_id = request.current_user_id
        
        documents = Document.query.filter_by(user_id=user_id).order_by(
            Document.uploaded_at.desc()
        ).all()
        
        documents_data = [doc.to_dict() for doc in documents]
        
        return jsonify({
            'documents': documents_data,
            'total': len(documents_data)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@documents_bp.route('/upload', methods=['POST'])
@require_auth
def upload_document():
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        if not data.get('type') or not data.get('url'):
            return jsonify({'error': 'Tipo e URL do documento são obrigatórios'}), 400
        
        # Simular processamento OCR
        extracted_data = simulate_ocr_processing(data['type'], data.get('url'))
        
        document = Document(
            user_id=user_id,
            type=data['type'],
            url=data['url'],
            extracted_data=extracted_data
        )
        
        db.session.add(document)
        db.session.commit()
        
        return jsonify({
            'message': 'Documento enviado com sucesso',
            'document': document.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

def simulate_ocr_processing(doc_type, url):
    """Simula processamento OCR de documentos"""
    if doc_type == 'driver_license':
        return {
            'license_number': f"SP{random.randint(100000000, 999999999)}",
            'category': 'B',
            'expiry_date': '2027-12-31',
            'name': 'João Silva',
            'birth_date': '1985-03-15'
        }
    elif doc_type == 'vehicle_registration':
        return {
            'plate': f"ABC{random.randint(1000, 9999)}",
            'model': 'Honda Civic',
            'year': 2020,
            'color': 'Branco'
        }
    return {}

# Social Route
social_bp = Blueprint('social', __name__)

@social_bp.route('/feed', methods=['GET'])
@require_auth
def get_feed():
    try:
        page = request.args.get('page', default=1, type=int)
        per_page = request.args.get('per_page', default=10, type=int)
        
        from src.models.user import SocialPost
        
        posts = SocialPost.query.order_by(
            SocialPost.created_at.desc()
        ).paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        posts_data = [post.to_dict() for post in posts.items]
        
        return jsonify({
            'posts': posts_data,
            'pagination': {
                'page': posts.page,
                'pages': posts.pages,
                'total': posts.total
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@social_bp.route('/posts', methods=['POST'])
@require_auth
def create_post():
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        if not data.get('content'):
            return jsonify({'error': 'Conteúdo é obrigatório'}), 400
        
        from src.models.user import SocialPost
        
        post = SocialPost(
            author_id=user_id,
            content=data['content'],
            image_url=data.get('image_url'),
            location_lat=data.get('location_lat'),
            location_lng=data.get('location_lng'),
            location_name=data.get('location_name')
        )
        
        db.session.add(post)
        db.session.commit()
        
        return jsonify({
            'message': 'Post criado com sucesso',
            'post': post.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

# Payments Route
payments_bp = Blueprint('payments', __name__)

@payments_bp.route('/wallet', methods=['GET'])
@require_auth
def get_wallet():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas têm carteira'}), 403
        
        user_id = request.current_user_id
        from src.models.user import Driver
        
        driver = Driver.query.filter_by(user_id=user_id).first()
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        wallet_data = {
            'balance': driver.total_earnings,
            'earnings_today': driver.earnings_today,
            'earnings_week': driver.earnings_week,
            'earnings_month': driver.earnings_month,
            'pending_withdrawals': 0,
            'available_for_withdrawal': driver.total_earnings,
            'transactions': generate_mock_transactions(driver.id)
        }
        
        return jsonify(wallet_data), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@payments_bp.route('/withdraw', methods=['POST'])
@require_auth
def request_withdrawal():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem sacar'}), 403
        
        data = request.get_json()
        amount = data.get('amount')
        
        if not amount or amount <= 0:
            return jsonify({'error': 'Valor inválido'}), 400
        
        # Simular processamento de saque
        return jsonify({
            'message': 'Solicitação de saque processada',
            'amount': amount,
            'estimated_arrival': '1-2 dias úteis',
            'fee': amount * 0.01  # 1% de taxa
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

def generate_mock_transactions(driver_id):
    """Gera transações simuladas"""
    import random
    transactions = []
    
    for i in range(10):
        transactions.append({
            'id': f"txn_{random.randint(100000, 999999)}",
            'type': random.choice(['trip_earning', 'bonus', 'withdrawal']),
            'amount': random.uniform(10, 50),
            'description': random.choice([
                'Viagem completada',
                'Bônus de performance',
                'Saque para conta'
            ]),
            'date': (datetime.datetime.now() - datetime.timedelta(days=i)).isoformat(),
            'status': 'completed'
        })
    
    return transactions

import random

