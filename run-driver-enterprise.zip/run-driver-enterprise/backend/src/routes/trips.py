from flask import Blueprint, request, jsonify, current_app
from src.models.user import Trip, Driver, User, db
from src.routes.auth import require_auth
import datetime
import random

trips_bp = Blueprint('trips', __name__)

@trips_bp.route('/', methods=['GET'])
@require_auth
def get_trips():
    try:
        user_id = request.current_user_id
        user_type = request.current_user_type
        
        # Parâmetros de paginação
        page = request.args.get('page', default=1, type=int)
        per_page = request.args.get('per_page', default=10, type=int)
        status = request.args.get('status')
        
        # Buscar viagens baseado no tipo de usuário
        if user_type == 'driver':
            driver = Driver.query.filter_by(user_id=user_id).first()
            if not driver:
                return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
            
            query = Trip.query.filter_by(driver_id=driver.id)
        else:
            query = Trip.query.filter_by(passenger_id=user_id)
        
        # Filtrar por status se especificado
        if status:
            query = query.filter_by(status=status)
        
        # Ordenar por data de criação (mais recentes primeiro)
        query = query.order_by(Trip.created_at.desc())
        
        # Paginação
        trips = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        trips_data = []
        for trip in trips.items:
            trip_data = trip.to_dict()
            
            # Adicionar informações do motorista e passageiro
            if trip.driver:
                trip_data['driver_name'] = trip.driver.user.name
                trip_data['driver_rating'] = trip.driver.rating
                trip_data['driver_vehicle'] = f"{trip.driver.vehicle_model} - {trip.driver.vehicle_plate}"
            
            if trip.passenger_id:
                passenger = User.query.get(trip.passenger_id)
                if passenger:
                    trip_data['passenger_name'] = passenger.name
            
            trips_data.append(trip_data)
        
        return jsonify({
            'trips': trips_data,
            'pagination': {
                'page': trips.page,
                'pages': trips.pages,
                'per_page': trips.per_page,
                'total': trips.total,
                'has_next': trips.has_next,
                'has_prev': trips.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/<int:trip_id>', methods=['GET'])
@require_auth
def get_trip(trip_id):
    try:
        user_id = request.current_user_id
        user_type = request.current_user_type
        
        trip = Trip.query.get(trip_id)
        if not trip:
            return jsonify({'error': 'Viagem não encontrada'}), 404
        
        # Verificar se o usuário tem acesso a esta viagem
        if user_type == 'driver':
            driver = Driver.query.filter_by(user_id=user_id).first()
            if not driver or trip.driver_id != driver.id:
                return jsonify({'error': 'Acesso negado'}), 403
        else:
            if trip.passenger_id != user_id:
                return jsonify({'error': 'Acesso negado'}), 403
        
        trip_data = trip.to_dict()
        
        # Adicionar informações detalhadas
        if trip.driver:
            trip_data['driver'] = {
                'name': trip.driver.user.name,
                'phone': trip.driver.user.phone,
                'rating': trip.driver.rating,
                'vehicle_model': trip.driver.vehicle_model,
                'vehicle_plate': trip.driver.vehicle_plate,
                'vehicle_color': trip.driver.vehicle_color
            }
        
        if trip.passenger_id:
            passenger = User.query.get(trip.passenger_id)
            if passenger:
                trip_data['passenger'] = {
                    'name': passenger.name,
                    'phone': passenger.phone
                }
        
        return jsonify({'trip': trip_data}), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/', methods=['POST'])
@require_auth
def create_trip():
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = [
            'origin_lat', 'origin_lng', 'origin_address',
            'destination_lat', 'destination_lng', 'destination_address'
        ]
        
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'{field} é obrigatório'}), 400
        
        # Calcular distância e duração (simulado)
        lat_diff = abs(data['destination_lat'] - data['origin_lat'])
        lng_diff = abs(data['destination_lng'] - data['origin_lng'])
        distance = ((lat_diff ** 2) + (lng_diff ** 2)) ** 0.5 * 111  # km aproximado
        duration = max(10, int(distance * 3))  # minutos aproximados
        
        # Calcular preço (R$ 2,50 base + R$ 1,80 por km)
        price = 2.50 + (distance * 1.80)
        
        # Criar viagem
        trip = Trip(
            origin_lat=data['origin_lat'],
            origin_lng=data['origin_lng'],
            origin_address=data['origin_address'],
            destination_lat=data['destination_lat'],
            destination_lng=data['destination_lng'],
            destination_address=data['destination_address'],
            distance=round(distance, 2),
            duration=duration,
            price=round(price, 2),
            passenger_id=request.current_user_id if request.current_user_type == 'passenger' else None
        )
        
        db.session.add(trip)
        db.session.commit()
        
        return jsonify({
            'message': 'Viagem criada com sucesso',
            'trip': trip.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/<int:trip_id>/accept', methods=['POST'])
@require_auth
def accept_trip(trip_id):
    try:
        user_id = request.current_user_id
        
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem aceitar viagens'}), 403
        
        # Buscar motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Buscar viagem
        trip = Trip.query.get(trip_id)
        if not trip:
            return jsonify({'error': 'Viagem não encontrada'}), 404
        
        if trip.status != 'pending':
            return jsonify({'error': 'Viagem não está disponível'}), 400
        
        # Aceitar viagem
        trip.driver_id = driver.id
        trip.status = 'accepted'
        trip.accepted_at = datetime.datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Viagem aceita com sucesso',
            'trip': trip.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/<int:trip_id>/start', methods=['POST'])
@require_auth
def start_trip(trip_id):
    try:
        user_id = request.current_user_id
        
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem iniciar viagens'}), 403
        
        # Buscar motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Buscar viagem
        trip = Trip.query.get(trip_id)
        if not trip:
            return jsonify({'error': 'Viagem não encontrada'}), 404
        
        if trip.driver_id != driver.id:
            return jsonify({'error': 'Acesso negado'}), 403
        
        if trip.status != 'accepted':
            return jsonify({'error': 'Viagem não pode ser iniciada'}), 400
        
        # Iniciar viagem
        trip.status = 'in_progress'
        trip.started_at = datetime.datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Viagem iniciada com sucesso',
            'trip': trip.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/<int:trip_id>/complete', methods=['POST'])
@require_auth
def complete_trip(trip_id):
    try:
        user_id = request.current_user_id
        
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem finalizar viagens'}), 403
        
        # Buscar motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Buscar viagem
        trip = Trip.query.get(trip_id)
        if not trip:
            return jsonify({'error': 'Viagem não encontrada'}), 404
        
        if trip.driver_id != driver.id:
            return jsonify({'error': 'Acesso negado'}), 403
        
        if trip.status != 'in_progress':
            return jsonify({'error': 'Viagem não pode ser finalizada'}), 400
        
        # Finalizar viagem
        trip.status = 'completed'
        trip.completed_at = datetime.datetime.utcnow()
        
        # Atualizar estatísticas do motorista
        driver.total_trips += 1
        driver.total_earnings += trip.price
        driver.earnings_today += trip.price
        driver.earnings_week += trip.price
        driver.earnings_month += trip.price
        
        # Adicionar XP (10 XP por viagem + bônus por distância)
        xp_earned = 10 + int(trip.distance * 2)
        driver.xp += xp_earned
        
        # Verificar se subiu de nível
        new_level = (driver.xp // 1000) + 1
        if new_level > driver.level:
            driver.level = new_level
            # TODO: Criar conquista de novo nível
        
        db.session.commit()
        
        return jsonify({
            'message': 'Viagem finalizada com sucesso',
            'trip': trip.to_dict(),
            'earnings': trip.price,
            'xp_earned': xp_earned,
            'new_level': driver.level
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/<int:trip_id>/cancel', methods=['POST'])
@require_auth
def cancel_trip(trip_id):
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        # Buscar viagem
        trip = Trip.query.get(trip_id)
        if not trip:
            return jsonify({'error': 'Viagem não encontrada'}), 404
        
        # Verificar permissão
        can_cancel = False
        if request.current_user_type == 'driver':
            driver = Driver.query.filter_by(user_id=user_id).first()
            if driver and trip.driver_id == driver.id:
                can_cancel = True
        elif trip.passenger_id == user_id:
            can_cancel = True
        
        if not can_cancel:
            return jsonify({'error': 'Acesso negado'}), 403
        
        if trip.status in ['completed', 'cancelled']:
            return jsonify({'error': 'Viagem não pode ser cancelada'}), 400
        
        # Cancelar viagem
        trip.status = 'cancelled'
        trip.updated_at = datetime.datetime.utcnow()
        
        # Se foi o motorista que cancelou, liberar para outros
        if request.current_user_type == 'driver':
            trip.driver_id = None
            trip.accepted_at = None
        
        db.session.commit()
        
        return jsonify({
            'message': 'Viagem cancelada com sucesso',
            'trip': trip.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/<int:trip_id>/rate', methods=['POST'])
@require_auth
def rate_trip(trip_id):
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        if not data.get('rating') or not (1 <= data['rating'] <= 5):
            return jsonify({'error': 'Avaliação deve ser entre 1 e 5'}), 400
        
        # Buscar viagem
        trip = Trip.query.get(trip_id)
        if not trip:
            return jsonify({'error': 'Viagem não encontrada'}), 404
        
        if trip.status != 'completed':
            return jsonify({'error': 'Apenas viagens finalizadas podem ser avaliadas'}), 400
        
        # Verificar permissão e aplicar avaliação
        if request.current_user_type == 'driver':
            driver = Driver.query.filter_by(user_id=user_id).first()
            if not driver or trip.driver_id != driver.id:
                return jsonify({'error': 'Acesso negado'}), 403
            
            trip.driver_rating = data['rating']
            trip.driver_comment = data.get('comment', '')
            
        elif trip.passenger_id == user_id:
            trip.passenger_rating = data['rating']
            trip.passenger_comment = data.get('comment', '')
            
            # Atualizar rating médio do motorista
            if trip.driver:
                completed_trips = Trip.query.filter_by(
                    driver_id=trip.driver_id,
                    status='completed'
                ).filter(Trip.passenger_rating.isnot(None)).all()
                
                if completed_trips:
                    total_rating = sum(t.passenger_rating for t in completed_trips)
                    trip.driver.rating = round(total_rating / len(completed_trips), 1)
        else:
            return jsonify({'error': 'Acesso negado'}), 403
        
        db.session.commit()
        
        return jsonify({
            'message': 'Avaliação registrada com sucesso',
            'trip': trip.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@trips_bp.route('/available', methods=['GET'])
@require_auth
def get_available_trips():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem ver viagens disponíveis'}), 403
        
        user_id = request.current_user_id
        
        # Buscar motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        if not driver.is_online or not driver.is_available:
            return jsonify({'error': 'Motorista deve estar online e disponível'}), 400
        
        # Buscar viagens pendentes próximas
        radius = request.args.get('radius', default=10, type=float)  # km
        
        available_trips = Trip.query.filter_by(status='pending').all()
        
        nearby_trips = []
        for trip in available_trips:
            if driver.current_lat and driver.current_lng:
                # Calcular distância até a origem da viagem
                lat_diff = abs(trip.origin_lat - driver.current_lat)
                lng_diff = abs(trip.origin_lng - driver.current_lng)
                distance = ((lat_diff ** 2) + (lng_diff ** 2)) ** 0.5 * 111
                
                if distance <= radius:
                    trip_data = trip.to_dict()
                    trip_data['distance_to_pickup'] = round(distance, 2)
                    nearby_trips.append(trip_data)
        
        # Ordenar por distância
        nearby_trips.sort(key=lambda x: x['distance_to_pickup'])
        
        return jsonify({
            'trips': nearby_trips,
            'count': len(nearby_trips)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

