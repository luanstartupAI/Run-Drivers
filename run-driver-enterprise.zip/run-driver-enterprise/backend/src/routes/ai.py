from flask import Blueprint, request, jsonify, current_app
from src.models.user import Driver, User, db
from src.routes.auth import require_auth
from src.services.ai_service import ai_service
import asyncio
import datetime

ai_bp = Blueprint('ai', __name__)

@ai_bp.route('/recommendations/locations', methods=['GET'])
@require_auth
async def get_location_recommendations():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem acessar recomendações'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Preparar dados do motorista para a IA
        driver_data = {
            'current_lat': driver.current_lat,
            'current_lng': driver.current_lng,
            'total_trips': driver.total_trips,
            'rating': driver.rating,
            'earnings_today': driver.earnings_today,
            'city': 'São Paulo'  # TODO: Detectar cidade baseada na localização
        }
        
        # Chamar serviço de IA
        recommendations = await ai_service.get_location_recommendations(driver_data)
        
        return jsonify(recommendations), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@ai_bp.route('/recommendations/schedule', methods=['GET'])
@require_auth
async def get_schedule_recommendations():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem acessar recomendações'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Preparar dados do motorista para a IA
        driver_data = {
            'earnings_week': driver.earnings_week,
            'hours_today': 8,  # TODO: Calcular horas reais trabalhadas
            'work_pattern': 'manhã e tarde',  # TODO: Detectar padrão do motorista
            'city': 'São Paulo'
        }
        
        # Chamar serviço de IA
        recommendations = await ai_service.get_schedule_recommendations(driver_data)
        
        return jsonify(recommendations), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@ai_bp.route('/personalization/profile', methods=['GET'])
@require_auth
async def get_personalization_profile():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem acessar personalização'}), 403
        
        user_id = request.current_user_id
        user = User.query.get(user_id)
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Preparar dados do motorista para a IA
        driver_data = {
            'name': user.name,
            'total_trips': driver.total_trips,
            'rating': driver.rating,
            'vehicle_type': driver.vehicle_type,
            'preferred_hours': 'Flexível',  # TODO: Detectar horários preferidos
            'average_earnings': driver.total_earnings / max(1, driver.total_trips) if driver.total_trips > 0 else 0
        }
        
        # Chamar serviço de IA
        profile = await ai_service.get_personalization_profile(driver_data)
        
        return jsonify(profile), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@ai_bp.route('/matching/optimize', methods=['POST'])
@require_auth
async def optimize_trip_matching():
    try:
        data = request.get_json()
        trip_id = data.get('trip_id')
        
        if not trip_id:
            return jsonify({'error': 'ID da viagem é obrigatório'}), 400
        
        # TODO: Buscar dados reais da viagem e motoristas disponíveis
        trip_data = {
            'origin_address': 'Av. Paulista, 1000',
            'destination_address': 'Shopping Ibirapuera',
            'distance': 5.2,
            'price': 18.50,
            'requested_time': datetime.datetime.now().isoformat()
        }
        
        available_drivers = [
            {'id': 'driver_1', 'distance': 0.8, 'rating': 4.9},
            {'id': 'driver_2', 'distance': 1.2, 'rating': 4.7},
            {'id': 'driver_3', 'distance': 0.5, 'rating': 4.8}
        ]
        
        # Chamar serviço de IA
        matching_result = await ai_service.optimize_trip_matching(trip_data, available_drivers)
        
        return jsonify(matching_result), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@ai_bp.route('/predictions/demand', methods=['GET'])
@require_auth
async def predict_demand():
    try:
        lat = request.args.get('lat', type=float)
        lng = request.args.get('lng', type=float)
        hours = request.args.get('hours', default=2, type=int)
        
        if not lat or not lng:
            return jsonify({'error': 'Latitude e longitude são obrigatórias'}), 400
        
        # Preparar dados da localização
        location_data = {
            'lat': lat,
            'lng': lng,
            'historical_demand': 'médio'  # TODO: Buscar dados históricos reais
        }
        
        # Chamar serviço de IA
        prediction = await ai_service.predict_demand(location_data)
        
        return jsonify(prediction), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@ai_bp.route('/analytics/performance', methods=['GET'])
@require_auth
async def get_performance_analytics():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas podem acessar analytics'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Preparar dados do motorista para a IA
        driver_data = {
            'total_trips': driver.total_trips,
            'rating': driver.rating,
            'cancellation_rate': 2.5,  # TODO: Calcular taxa real de cancelamento
            'total_earnings': driver.total_earnings,
            'avg_trip_time': 25,  # TODO: Calcular tempo médio real
            'avg_distance': 8.5   # TODO: Calcular distância média real
        }
        
        # Chamar serviço de IA
        analytics = await ai_service.get_performance_analytics(driver_data)
        
        return jsonify(analytics), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@ai_bp.route('/chatbot/message', methods=['POST'])
@require_auth
async def send_chatbot_message():
    try:
        data = request.get_json()
        message = data.get('message')
        
        if not message:
            return jsonify({'error': 'Mensagem é obrigatória'}), 400
        
        user_id = request.current_user_id
        user = User.query.get(user_id)
        
        # Preparar contexto do motorista
        context = {
            'driver_name': user.name if user else 'Motorista',
            'trips_today': 0,  # TODO: Calcular viagens de hoje
            'earnings_today': 0,  # TODO: Calcular ganhos de hoje
            'status': 'offline'  # TODO: Buscar status real
        }
        
        if request.current_user_type == 'driver':
            driver = Driver.query.filter_by(user_id=user_id).first()
            if driver:
                context.update({
                    'trips_today': 5,  # TODO: Calcular viagens reais de hoje
                    'earnings_today': driver.earnings_today,
                    'status': 'online' if driver.is_online else 'offline'
                })
        
        # Chamar serviço de IA
        response = await ai_service.process_chatbot_message(message, context)
        
        return jsonify(response), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

# Função auxiliar para executar funções async em rotas Flask
def run_async(coro):
    """Executa uma corrotina em um loop de eventos"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(coro)

# Wrapper para tornar as rotas síncronas
@ai_bp.route('/recommendations/locations', methods=['GET'])
@require_auth
def get_location_recommendations_sync():
    return run_async(get_location_recommendations())

@ai_bp.route('/recommendations/schedule', methods=['GET'])
@require_auth
def get_schedule_recommendations_sync():
    return run_async(get_schedule_recommendations())

@ai_bp.route('/personalization/profile', methods=['GET'])
@require_auth
def get_personalization_profile_sync():
    return run_async(get_personalization_profile())

@ai_bp.route('/matching/optimize', methods=['POST'])
@require_auth
def optimize_trip_matching_sync():
    return run_async(optimize_trip_matching())

@ai_bp.route('/predictions/demand', methods=['GET'])
@require_auth
def predict_demand_sync():
    return run_async(predict_demand())

@ai_bp.route('/analytics/performance', methods=['GET'])
@require_auth
def get_performance_analytics_sync():
    return run_async(get_performance_analytics())

@ai_bp.route('/chatbot/message', methods=['POST'])
@require_auth
def send_chatbot_message_sync():
    return run_async(send_chatbot_message())

