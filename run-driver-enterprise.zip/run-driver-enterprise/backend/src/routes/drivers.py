from flask import Blueprint, request, jsonify, current_app
from src.models.user import Driver, User, db
from src.routes.auth import require_auth
import datetime

drivers_bp = Blueprint('drivers', __name__)

@drivers_bp.route('/profile', methods=['GET'])
@require_auth
def get_driver_profile():
    try:
        user_id = request.current_user_id
        
        # Buscar perfil do motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            # Criar perfil se não existir
            driver = Driver(user_id=user_id)
            db.session.add(driver)
            db.session.commit()
        
        return jsonify({
            'driver': driver.to_dict(),
            'user': driver.user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@drivers_bp.route('/profile', methods=['PUT'])
@require_auth
def update_driver_profile():
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        # Buscar perfil do motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            driver = Driver(user_id=user_id)
            db.session.add(driver)
        
        # Atualizar campos permitidos
        allowed_fields = [
            'license_number', 'license_category', 'license_expiry',
            'vehicle_model', 'vehicle_plate', 'vehicle_year', 'vehicle_color'
        ]
        
        for field in allowed_fields:
            if field in data:
                if field == 'license_expiry' and data[field]:
                    # Converter string para date
                    try:
                        setattr(driver, field, datetime.datetime.strptime(data[field], '%Y-%m-%d').date())
                    except ValueError:
                        return jsonify({'error': f'Formato de data inválido para {field}'}), 400
                else:
                    setattr(driver, field, data[field])
        
        driver.updated_at = datetime.datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Perfil atualizado com sucesso',
            'driver': driver.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@drivers_bp.route('/location', methods=['PUT'])
@require_auth
def update_location():
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        if not data.get('lat') or not data.get('lng'):
            return jsonify({'error': 'Latitude e longitude são obrigatórias'}), 400
        
        # Buscar perfil do motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Atualizar localização
        driver.current_lat = float(data['lat'])
        driver.current_lng = float(data['lng'])
        driver.updated_at = datetime.datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Localização atualizada com sucesso',
            'location': {
                'lat': driver.current_lat,
                'lng': driver.current_lng
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@drivers_bp.route('/status', methods=['PUT'])
@require_auth
def update_status():
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        # Buscar perfil do motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Atualizar status
        if 'is_online' in data:
            driver.is_online = bool(data['is_online'])
        
        if 'is_available' in data:
            driver.is_available = bool(data['is_available'])
        
        driver.updated_at = datetime.datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Status atualizado com sucesso',
            'status': {
                'is_online': driver.is_online,
                'is_available': driver.is_available
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@drivers_bp.route('/dashboard', methods=['GET'])
@require_auth
def get_dashboard():
    try:
        user_id = request.current_user_id
        
        # Buscar perfil do motorista
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Calcular estatísticas
        today = datetime.date.today()
        week_start = today - datetime.timedelta(days=today.weekday())
        month_start = today.replace(day=1)
        
        # Viagens recentes
        recent_trips = []
        for trip in driver.trips[-5:]:  # Últimas 5 viagens
            recent_trips.append(trip.to_dict())
        
        # Conquistas recentes
        recent_achievements = []
        for achievement in driver.achievements[-3:]:  # Últimas 3 conquistas
            recent_achievements.append(achievement.to_dict())
        
        # Calcular próximo nível
        xp_for_next_level = driver.level * 1000  # 1000 XP por nível
        xp_progress = (driver.xp % 1000) / 1000 * 100
        
        dashboard_data = {
            'driver': driver.to_dict(),
            'stats': {
                'earnings_today': driver.earnings_today,
                'earnings_week': driver.earnings_week,
                'earnings_month': driver.earnings_month,
                'total_trips': driver.total_trips,
                'rating': driver.rating,
                'level': driver.level,
                'xp': driver.xp,
                'xp_for_next_level': xp_for_next_level,
                'xp_progress': xp_progress
            },
            'recent_trips': recent_trips,
            'recent_achievements': recent_achievements,
            'status': {
                'is_online': driver.is_online,
                'is_available': driver.is_available
            }
        }
        
        return jsonify(dashboard_data), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@drivers_bp.route('/nearby', methods=['GET'])
@require_auth
def get_nearby_drivers():
    try:
        # Parâmetros de localização
        lat = request.args.get('lat', type=float)
        lng = request.args.get('lng', type=float)
        radius = request.args.get('radius', default=10, type=float)  # km
        
        if not lat or not lng:
            return jsonify({'error': 'Latitude e longitude são obrigatórias'}), 400
        
        # Buscar motoristas online próximos
        # Fórmula simples de distância (para produção, usar PostGIS)
        drivers = Driver.query.filter(
            Driver.is_online == True,
            Driver.is_available == True,
            Driver.current_lat.isnot(None),
            Driver.current_lng.isnot(None)
        ).all()
        
        nearby_drivers = []
        for driver in drivers:
            # Calcular distância aproximada
            lat_diff = abs(driver.current_lat - lat)
            lng_diff = abs(driver.current_lng - lng)
            distance = ((lat_diff ** 2) + (lng_diff ** 2)) ** 0.5 * 111  # Aproximação em km
            
            if distance <= radius:
                driver_data = driver.to_dict()
                driver_data['distance'] = round(distance, 2)
                driver_data['user_name'] = driver.user.name
                nearby_drivers.append(driver_data)
        
        # Ordenar por distância
        nearby_drivers.sort(key=lambda x: x['distance'])
        
        return jsonify({
            'drivers': nearby_drivers,
            'count': len(nearby_drivers)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@drivers_bp.route('/leaderboard', methods=['GET'])
@require_auth
def get_leaderboard():
    try:
        # Parâmetros
        period = request.args.get('period', default='week')  # week, month, all
        limit = request.args.get('limit', default=10, type=int)
        
        # Determinar campo de ordenação
        if period == 'week':
            order_field = Driver.earnings_week
        elif period == 'month':
            order_field = Driver.earnings_month
        else:
            order_field = Driver.total_earnings
        
        # Buscar top motoristas
        top_drivers = Driver.query.join(User).order_by(
            order_field.desc()
        ).limit(limit).all()
        
        leaderboard = []
        for i, driver in enumerate(top_drivers, 1):
            driver_data = {
                'position': i,
                'name': driver.user.name,
                'level': driver.level,
                'rating': driver.rating,
                'total_trips': driver.total_trips
            }
            
            if period == 'week':
                driver_data['earnings'] = driver.earnings_week
            elif period == 'month':
                driver_data['earnings'] = driver.earnings_month
            else:
                driver_data['earnings'] = driver.total_earnings
            
            leaderboard.append(driver_data)
        
        return jsonify({
            'leaderboard': leaderboard,
            'period': period
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

