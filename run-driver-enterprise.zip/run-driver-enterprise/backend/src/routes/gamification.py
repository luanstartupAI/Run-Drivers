from flask import Blueprint, request, jsonify, current_app
from src.models.user import Achievement, Driver, User, db
from src.routes.auth import require_auth
import datetime
import random

gamification_bp = Blueprint('gamification', __name__)

@gamification_bp.route('/achievements', methods=['GET'])
@require_auth
def get_achievements():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas têm conquistas'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        achievements = Achievement.query.filter_by(driver_id=driver.id).order_by(
            Achievement.unlocked_at.desc()
        ).all()
        
        achievements_data = [achievement.to_dict() for achievement in achievements]
        
        # Conquistas disponíveis para desbloquear
        available_achievements = get_available_achievements(driver)
        
        return jsonify({
            'unlocked_achievements': achievements_data,
            'available_achievements': available_achievements,
            'total_unlocked': len(achievements_data),
            'total_xp': sum(a['xp_reward'] for a in achievements_data)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@gamification_bp.route('/leaderboard', methods=['GET'])
@require_auth
def get_leaderboard():
    try:
        period = request.args.get('period', default='week')
        limit = request.args.get('limit', default=10, type=int)
        
        if period == 'week':
            order_field = Driver.earnings_week
        elif period == 'month':
            order_field = Driver.earnings_month
        elif period == 'xp':
            order_field = Driver.xp
        else:
            order_field = Driver.total_earnings
        
        top_drivers = Driver.query.join(User).order_by(
            order_field.desc()
        ).limit(limit).all()
        
        leaderboard = []
        for i, driver in enumerate(top_drivers, 1):
            driver_data = {
                'position': i,
                'name': driver.user.name,
                'level': driver.level,
                'xp': driver.xp,
                'rating': driver.rating,
                'total_trips': driver.total_trips
            }
            
            if period == 'week':
                driver_data['value'] = driver.earnings_week
                driver_data['metric'] = 'earnings_week'
            elif period == 'month':
                driver_data['value'] = driver.earnings_month
                driver_data['metric'] = 'earnings_month'
            elif period == 'xp':
                driver_data['value'] = driver.xp
                driver_data['metric'] = 'xp'
            else:
                driver_data['value'] = driver.total_earnings
                driver_data['metric'] = 'total_earnings'
            
            leaderboard.append(driver_data)
        
        return jsonify({
            'leaderboard': leaderboard,
            'period': period
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@gamification_bp.route('/challenges', methods=['GET'])
@require_auth
def get_challenges():
    try:
        if request.current_user_type != 'driver':
            return jsonify({'error': 'Apenas motoristas têm desafios'}), 403
        
        user_id = request.current_user_id
        driver = Driver.query.filter_by(user_id=user_id).first()
        
        if not driver:
            return jsonify({'error': 'Perfil de motorista não encontrado'}), 404
        
        # Gerar desafios personalizados
        challenges = generate_daily_challenges(driver)
        
        return jsonify({
            'daily_challenges': challenges,
            'driver_level': driver.level,
            'current_xp': driver.xp
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

def get_available_achievements(driver):
    """Retorna conquistas disponíveis para desbloquear"""
    unlocked_ids = [a.type for a in driver.achievements]
    
    all_achievements = [
        {
            'type': 'first_trip',
            'name': 'Primeira Viagem',
            'description': 'Complete sua primeira viagem',
            'icon': 'car',
            'xp_reward': 50,
            'requirement': 'trips >= 1',
            'unlocked': driver.total_trips >= 1 and 'first_trip' not in unlocked_ids
        },
        {
            'type': 'trip_master_10',
            'name': 'Mestre das Viagens',
            'description': 'Complete 10 viagens',
            'icon': 'trophy',
            'xp_reward': 100,
            'requirement': 'trips >= 10',
            'unlocked': driver.total_trips >= 10 and 'trip_master_10' not in unlocked_ids
        },
        {
            'type': 'rating_star',
            'name': 'Estrela do Atendimento',
            'description': 'Mantenha avaliação 4.8+',
            'icon': 'star',
            'xp_reward': 150,
            'requirement': 'rating >= 4.8',
            'unlocked': driver.rating >= 4.8 and 'rating_star' not in unlocked_ids
        },
        {
            'type': 'earnings_1000',
            'name': 'Primeiro Mil',
            'description': 'Ganhe R$ 1.000',
            'icon': 'money',
            'xp_reward': 200,
            'requirement': 'earnings >= 1000',
            'unlocked': driver.total_earnings >= 1000 and 'earnings_1000' not in unlocked_ids
        },
        {
            'type': 'level_5',
            'name': 'Veterano',
            'description': 'Alcance o nível 5',
            'icon': 'medal',
            'xp_reward': 250,
            'requirement': 'level >= 5',
            'unlocked': driver.level >= 5 and 'level_5' not in unlocked_ids
        }
    ]
    
    return [a for a in all_achievements if a['unlocked']]

def generate_daily_challenges(driver):
    """Gera desafios diários personalizados"""
    challenges = [
        {
            'id': 'daily_trips',
            'name': 'Viagens do Dia',
            'description': 'Complete 5 viagens hoje',
            'progress': min(5, random.randint(0, 3)),
            'target': 5,
            'xp_reward': 50,
            'type': 'daily',
            'expires_at': (datetime.datetime.now() + datetime.timedelta(days=1)).isoformat()
        },
        {
            'id': 'peak_hours',
            'name': 'Horário de Pico',
            'description': 'Trabalhe 2 horas em horário de pico',
            'progress': random.randint(0, 120),
            'target': 120,  # minutos
            'xp_reward': 75,
            'type': 'daily',
            'expires_at': (datetime.datetime.now() + datetime.timedelta(days=1)).isoformat()
        },
        {
            'id': 'high_rating',
            'name': 'Excelência',
            'description': 'Mantenha avaliação 5.0 em todas as viagens de hoje',
            'progress': random.randint(0, 1),
            'target': 1,
            'xp_reward': 100,
            'type': 'daily',
            'expires_at': (datetime.datetime.now() + datetime.timedelta(days=1)).isoformat()
        }
    ]
    
    # Desafios semanais
    weekly_challenges = [
        {
            'id': 'weekly_earnings',
            'name': 'Meta Semanal',
            'description': 'Ganhe R$ 500 esta semana',
            'progress': driver.earnings_week,
            'target': 500,
            'xp_reward': 200,
            'type': 'weekly',
            'expires_at': (datetime.datetime.now() + datetime.timedelta(days=7)).isoformat()
        }
    ]
    
    return {
        'daily': challenges,
        'weekly': weekly_challenges
    }

