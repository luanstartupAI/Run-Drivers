# 🚗 Run Driver Enterprise

> O melhor aplicativo para motoristas do mundo inteiro

[![Deploy Status](https://img.shields.io/badge/deploy-success-brightgreen)](https://leoujccj.manus.space)
[![Backend](https://img.shields.io/badge/backend-railway-purple)](https://railway.app)
[![Frontend](https://img.shields.io/badge/frontend-vercel-black)](https://vercel.com)
[![Database](https://img.shields.io/badge/database-supabase-green)](https://supabase.com)

## 🌟 Visão Geral

O Run Driver é uma plataforma revolucionária que conecta motoristas e passageiros com tecnologia de ponta, IA avançada e gamificação inovadora. Nossa missão é maximizar os ganhos dos motoristas enquanto oferecemos a melhor experiência de transporte.

### 🎯 Diferenciais Únicos

- **Taxa de apenas 4%** (vs 20-30% dos concorrentes)
- **IA de personalização** com Google Gemini
- **Gamificação avançada** com níveis e conquistas
- **Rede social integrada** para motoristas
- **Carteira digital** com múltiplas fontes de renda
- **Design premium** baseado no MANUS.IM

## 🚀 Demo Online

**🌐 Aplicação:** https://leoujccj.manus.space

**Credenciais de teste:**
- Email: `motorista@exemplo.com`
- Senha: `123456`

## 🏗️ Arquitetura Enterprise

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │    Backend      │    │   Database      │
│   (Vercel)      │◄──►│   (Railway)     │◄──►│  (Supabase)     │
│                 │    │                 │    │                 │
│ • React 19      │    │ • Flask + IA    │    │ • PostgreSQL    │
│ • PWA           │    │ • Docker        │    │ • Realtime      │
│ • Stripe UI     │    │ • Gemini AI     │    │ • Storage       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### 🛠️ Stack Tecnológico

**Frontend:**
- ⚛️ React 19 + Vite
- 🎨 Tailwind CSS + Shadcn/UI
- 📱 PWA (Progressive Web App)
- 💳 Stripe Elements
- 🗺️ React Leaflet
- 🔄 Zustand (State Management)

**Backend:**
- 🐍 Python + Flask
- 🧠 Google Gemini AI
- 💰 Stripe API
- 🗄️ Supabase SDK
- 🐳 Docker
- 🚂 Railway Deploy

**Banco de Dados:**
- 🐘 PostgreSQL (Supabase)
- 📍 PostGIS (Geolocalização)
- ⚡ Realtime subscriptions
- 📁 Storage para documentos

**DevOps:**
- 🔄 GitHub Actions (CI/CD)
- 🐳 Docker containers
- 📊 Monitoramento automático
- 🔒 Secrets management

## 📁 Estrutura do Projeto

```
run-driver-enterprise/
├── frontend/                 # React Frontend
│   ├── src/
│   │   ├── components/      # Componentes reutilizáveis
│   │   ├── pages/          # Páginas da aplicação
│   │   ├── stores/         # Gerenciamento de estado
│   │   ├── services/       # Integração com APIs
│   │   └── utils/          # Utilitários
│   ├── public/             # Arquivos estáticos
│   └── package.json        # Dependências
├── backend/                  # Flask Backend
│   ├── src/
│   │   ├── routes/         # Rotas da API
│   │   ├── services/       # Lógica de negócio
│   │   ├── models/         # Modelos de dados
│   │   └── utils/          # Utilitários
│   ├── Dockerfile          # Container Docker
│   └── requirements.txt    # Dependências Python
├── docs/                     # Documentação
│   ├── componentizacao_run_driver.md
│   ├── plano_desenvolvimento_run_driver.md
│   └── *.pdf              # Documentos técnicos
├── scripts/                  # Scripts de deploy
│   ├── deploy.sh           # Deploy completo
│   ├── deploy-frontend.sh  # Deploy frontend
│   └── deploy-backend.sh   # Deploy backend
├── .github/                  # GitHub Actions
│   └── workflows/          # CI/CD workflows
├── docker-compose.yml        # Desenvolvimento local
└── README.md                # Este arquivo
```

## 🚀 Quick Start

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/run-driver-enterprise.git
cd run-driver-enterprise
```

### 2. Configure as variáveis de ambiente

**Frontend (.env.local):**
```env
VITE_API_URL=http://localhost:8000
VITE_SUPABASE_URL=sua_supabase_url
VITE_SUPABASE_ANON_KEY=sua_supabase_key
VITE_STRIPE_PUBLISHABLE_KEY=sua_stripe_key
```

**Backend (.env):**
```env
DATABASE_URL=sua_database_url
SUPABASE_URL=sua_supabase_url
SUPABASE_KEY=sua_supabase_key
STRIPE_SECRET_KEY=sua_stripe_secret
GEMINI_API_KEY=sua_gemini_key
```

### 3. Desenvolvimento local

**Com Docker (Recomendado):**
```bash
docker-compose up -d
```

**Manual:**
```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Linux/Mac
pip install -r requirements.txt
python src/main.py

# Frontend (novo terminal)
cd frontend
npm install
npm run dev
```

### 4. Acesse a aplicação
- Frontend: http://localhost:3000
- Backend: http://localhost:8000
- Docs: http://localhost:8000/docs

## 🎮 Funcionalidades Principais

### 🔐 Autenticação e Cadastro
- Login/registro com email e senha
- Verificação biométrica para motoristas
- Upload e validação de documentos (CNH, CPF, etc.)
- Integração com Supabase Auth

### 🧠 IA e Personalização
- Recomendações inteligentes de localização
- Otimização de rotas com IA
- Análise comportamental de motoristas
- Chatbot com processamento natural
- Matching inteligente motorista-passageiro

### 💰 Sistema Financeiro
- Carteira digital integrada
- Pagamentos via Stripe (cartão, PIX)
- Sistema de saques automatizado
- Múltiplas fontes de renda
- Recompensas por anúncios e jogos

### 🎮 Gamificação
- Sistema de níveis e XP
- Conquistas e desafios
- Ranking competitivo
- Recompensas por performance
- Badges e troféus

### 🤝 Rede Social
- Feed de posts dos motoristas
- Sistema de likes e comentários
- Compartilhamento de experiências
- Grupos por região
- Eventos e meetups

### 📱 Recursos Mobile
- PWA (funciona offline)
- Notificações push
- Geolocalização em tempo real
- Interface responsiva
- Suporte a gestos touch

## 🔧 Deploy

### Deploy Automático (CI/CD)
```bash
# Fazer push para main dispara deploy automático
git push origin main
```

### Deploy Manual
```bash
# Deploy completo
./scripts/deploy.sh

# Deploy apenas frontend
./scripts/deploy-frontend.sh

# Deploy apenas backend
./scripts/deploy-backend.sh
```

### Configuração de Secrets

No GitHub, configure os seguintes secrets:

```
# Vercel
VERCEL_TOKEN=
VERCEL_ORG_ID=
VERCEL_PROJECT_ID=

# Railway
RAILWAY_TOKEN=

# Supabase
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_KEY=

# Stripe
VITE_STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=

# APIs
GEMINI_API_KEY=
MAPBOX_ACCESS_TOKEN=
```

## 📊 Monitoramento

### Health Checks
- **Frontend:** https://leoujccj.manus.space
- **Backend:** https://run-driver-backend.railway.app/health
- **API:** https://run-driver-backend.railway.app/api/health

### Métricas
- Uptime monitoring
- Performance metrics
- Error tracking
- User analytics

## 🧪 Testes

```bash
# Testes frontend
cd frontend
npm run test
npm run test:e2e

# Testes backend
cd backend
python -m pytest tests/
python -m pytest tests/ --cov=src

# Testes de integração
./scripts/test-integration.sh
```

## 📚 Documentação

- **[Componentização Completa](docs/componentizacao_run_driver.md)** - Arquitetura de componentes
- **[Plano de Desenvolvimento](docs/plano_desenvolvimento_run_driver.md)** - Roadmap detalhado
- **[API Documentation](backend/docs/api.md)** - Documentação da API
- **[Deployment Guide](docs/deployment.md)** - Guia de deploy

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

### Padrões de Código

- **Frontend:** ESLint + Prettier
- **Backend:** Black + Flake8
- **Commits:** Conventional Commits
- **Branches:** GitFlow

## 📄 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🏆 Equipe

- **Desenvolvimento:** Run Driver Team
- **Design:** Baseado no MANUS.IM
- **IA:** Google Gemini
- **Infraestrutura:** Vercel + Railway + Supabase

## 📞 Suporte

- **Email:** dev@rundriver.com
- **Discord:** [Run Driver Community](https://discord.gg/rundriver)
- **Issues:** [GitHub Issues](https://github.com/seu-usuario/run-driver-enterprise/issues)

---

<div align="center">

**🚗 Run Driver - Revolucionando o transporte mundial 🌍**

[![Deploy](https://img.shields.io/badge/🚀-Deploy%20Now-success)](https://leoujccj.manus.space)
[![Docs](https://img.shields.io/badge/📚-Documentation-blue)](docs/)
[![Community](https://img.shields.io/badge/💬-Community-purple)](https://discord.gg/rundriver)

</div>

